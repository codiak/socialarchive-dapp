window.YTD.account.part0 = [
  {
    "account" : {
      "email" : "cody@doglover.com",
      "createdVia" : "oauth:3033300",
      "username" : "SocialArchiveCo",
      "accountId" : "1448793710905290770",
      "createdAt" : "2021-10-14T23:33:50.031Z",
      "accountDisplayName" : "SocialArchive"
    }
  }
]