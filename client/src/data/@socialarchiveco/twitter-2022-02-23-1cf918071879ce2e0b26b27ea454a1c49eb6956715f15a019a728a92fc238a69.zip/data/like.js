window.YTD.like.part0 = [
  {
    "like" : {
      "tweetId" : "1474183295852187651",
      "fullText" : "⟠ Latest Week in Ethereum News!\n\n⭐ @icebearhww PoW switch off consensus upgrade named Bellatrix\n💼 @SAP joins @EntEthAlliance / @baselineproto\n🎉 @Ethereum teams Q4 achievements\n\nhttps://t.co/zMF41qIpnD\n\nThanks to @kwenta_io &amp; @synthetix_io for making this issue possible 🙏",
      "expandedUrl" : "https://twitter.com/i/web/status/1474183295852187651"
    }
  },
  {
    "like" : {
      "tweetId" : "1496079235341070339",
      "fullText" : "(8/8) #WeAreMillions will be an open space for reflection and exploration of #Web3's potential. \n\nFrom 1–21 March artists, developers, activists and gamers are invited to come together in an online collaborative discovery at WAM.\n\nSign up now: https://t.co/rVnIcSOR1c",
      "expandedUrl" : "https://twitter.com/i/web/status/1496079235341070339"
    }
  },
  {
    "like" : {
      "tweetId" : "1495767105509236744",
      "fullText" : "🎉We are excited to announce the We Are Millions hackathon. This hackathon is about creating a fair and ethical Web3. Sponsored by @FairDataSociety, @ethswarm, &amp; @NordicGame.\n📅Starts March 1st!\n👇Sign up here👇\nhttps://t.co/dhTnNyCRCI\n👀Watch the promo:\nhttps://t.co/c5zxcX1okw",
      "expandedUrl" : "https://twitter.com/i/web/status/1495767105509236744"
    }
  },
  {
    "like" : {
      "tweetId" : "1496259854247337984",
      "fullText" : "https://t.co/Wlxj8hfnGW",
      "expandedUrl" : "https://twitter.com/i/web/status/1496259854247337984"
    }
  },
  {
    "like" : {
      "tweetId" : "1451676767391989765",
      "fullText" : "@SocialArchiveCo https://t.co/8o8L9ARpe2",
      "expandedUrl" : "https://twitter.com/i/web/status/1451676767391989765"
    }
  },
  {
    "like" : {
      "tweetId" : "1474372496631676949",
      "fullText" : "Here's some good holiday news 🎉\n\nThe #ethswarm have reached their first milestone \n\nYou can now host unstoppable content on Swarm 🐝\n\nThis is the beginning of true unstoppable content on Swarm \n\nHappy unstoppable holidays 🎄",
      "expandedUrl" : "https://twitter.com/i/web/status/1474372496631676949"
    }
  },
  {
    "like" : {
      "tweetId" : "1474322188710916100",
      "fullText" : "The Swarm network is starting to fill up, and the price of storage is thus increasing.\nTop up your postage stamps to ensure your content is retained by Swarm! \nFind out how in the Bee Docs: https://t.co/Pf0tICDBbI",
      "expandedUrl" : "https://twitter.com/i/web/status/1474322188710916100"
    }
  },
  {
    "like" : {
      "tweetId" : "1496079193242755073",
      "fullText" : "Can we take NFTs beyond overpriced pixels?\n\nGenerative art, blockchain and NFTs are redefining the confines of art. \n\nBut is this a good thing? What value do they have? \n\nLet's dig deeper. Going beyond capital vs values 👇\nhttps://t.co/tk8y4lCPYs",
      "expandedUrl" : "https://twitter.com/i/web/status/1496079193242755073"
    }
  },
  {
    "like" : {
      "tweetId" : "1474372498343010315",
      "fullText" : "To host your unstoppable content, you can use https://t.co/lt99pUy6xY for uploads up to 10MB. And if you want unlimited uploads/downloads, you can install your own Bee node.",
      "expandedUrl" : "https://twitter.com/i/web/status/1474372498343010315"
    }
  },
  {
    "like" : {
      "tweetId" : "1470332887832616963",
      "fullText" : "Swarm Foundation is proud to share its tech team’s internal agenda for the next 12 months. Get to know the first milestones on https://t.co/lhupYV9yIu and join our Discord server to stay in the know for future milestones.\n\n#ethereum #swarm",
      "expandedUrl" : "https://twitter.com/i/web/status/1470332887832616963"
    }
  }
]