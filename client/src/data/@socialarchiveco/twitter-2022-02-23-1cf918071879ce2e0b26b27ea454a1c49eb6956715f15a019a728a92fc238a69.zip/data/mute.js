window.YTD.mute.part0 = [
  {
    "muting" : {
      "accountId" : "84150343",
      "userLink" : "https://twitter.com/intent/user?user_id=84150343"
    }
  },
  {
    "muting" : {
      "accountId" : "1270725831086665729",
      "userLink" : "https://twitter.com/intent/user?user_id=1270725831086665729"
    }
  },
  {
    "muting" : {
      "accountId" : "3069284711",
      "userLink" : "https://twitter.com/intent/user?user_id=3069284711"
    }
  }
]