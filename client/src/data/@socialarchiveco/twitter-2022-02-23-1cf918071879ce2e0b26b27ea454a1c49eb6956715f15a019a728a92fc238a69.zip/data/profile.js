window.YTD.profile.part0 = [
  {
    "profile" : {
      "description" : {
        "bio" : "Reclaim your digital identity\n+ Preserve your Twitter +\nEth Swarm Grant Project",
        "website" : "https://t.co/NxfoDqXOTo",
        "location" : ""
      },
      "avatarMediaUrl" : "https://pbs.twimg.com/profile_images/1495521126771953664/sxRXdnos.jpg",
      "headerMediaUrl" : "https://pbs.twimg.com/profile_banners/1448793710905290770/1645394997"
    }
  }
]