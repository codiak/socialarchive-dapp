window.YTD.following.part0 = [
  {
    "following" : {
      "accountId" : "315490964",
      "userLink" : "https://twitter.com/intent/user?user_id=315490964"
    }
  },
  {
    "following" : {
      "accountId" : "18957805",
      "userLink" : "https://twitter.com/intent/user?user_id=18957805"
    }
  },
  {
    "following" : {
      "accountId" : "1254192452522696705",
      "userLink" : "https://twitter.com/intent/user?user_id=1254192452522696705"
    }
  },
  {
    "following" : {
      "accountId" : "2024211",
      "userLink" : "https://twitter.com/intent/user?user_id=2024211"
    }
  },
  {
    "following" : {
      "accountId" : "8705962",
      "userLink" : "https://twitter.com/intent/user?user_id=8705962"
    }
  },
  {
    "following" : {
      "accountId" : "856446453157376003",
      "userLink" : "https://twitter.com/intent/user?user_id=856446453157376003"
    }
  },
  {
    "following" : {
      "accountId" : "1459045400556441600",
      "userLink" : "https://twitter.com/intent/user?user_id=1459045400556441600"
    }
  },
  {
    "following" : {
      "accountId" : "1245432330640072710",
      "userLink" : "https://twitter.com/intent/user?user_id=1245432330640072710"
    }
  },
  {
    "following" : {
      "accountId" : "43527072",
      "userLink" : "https://twitter.com/intent/user?user_id=43527072"
    }
  },
  {
    "following" : {
      "accountId" : "47107914",
      "userLink" : "https://twitter.com/intent/user?user_id=47107914"
    }
  },
  {
    "following" : {
      "accountId" : "1442476876593696782",
      "userLink" : "https://twitter.com/intent/user?user_id=1442476876593696782"
    }
  },
  {
    "following" : {
      "accountId" : "17703833",
      "userLink" : "https://twitter.com/intent/user?user_id=17703833"
    }
  },
  {
    "following" : {
      "accountId" : "2312333412",
      "userLink" : "https://twitter.com/intent/user?user_id=2312333412"
    }
  },
  {
    "following" : {
      "accountId" : "1324574383806009345",
      "userLink" : "https://twitter.com/intent/user?user_id=1324574383806009345"
    }
  },
  {
    "following" : {
      "accountId" : "1385231003745234944",
      "userLink" : "https://twitter.com/intent/user?user_id=1385231003745234944"
    }
  },
  {
    "following" : {
      "accountId" : "879945922540646400",
      "userLink" : "https://twitter.com/intent/user?user_id=879945922540646400"
    }
  },
  {
    "following" : {
      "accountId" : "1021693481906003968",
      "userLink" : "https://twitter.com/intent/user?user_id=1021693481906003968"
    }
  }
]