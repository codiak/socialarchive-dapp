window.YTD.tweet.part0 = [
  {
    "tweet" : {
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Ethereum Swarm",
            "screen_name" : "ethswarm",
            "indices" : [
              "3",
              "12"
            ],
            "id_str" : "1021693481906003968",
            "id" : "1021693481906003968"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "id_str" : "1496512542373519361",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1496512542373519361",
      "created_at" : "Wed Feb 23 15:49:28 +0000 2022",
      "favorited" : false,
      "full_text" : "RT @ethswarm: With the Ethereum blockchain as the CPU of the world computer, Swarm is best thought of as its \"\"hard disk\"\". - Viktor Trón (…",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "136"
      ],
      "favorite_count" : "0",
      "id_str" : "1496166106561941506",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1496166106561941506",
      "created_at" : "Tue Feb 22 16:52:51 +0000 2022",
      "favorited" : false,
      "full_text" : "“There’s so much going on in the crypto space that it’s hard to zoom out and see the progress. Adoption is happening.”\n- Vitalik Buterin",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "184"
      ],
      "favorite_count" : "1",
      "id_str" : "1478162618984525828",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1478162618984525828",
      "created_at" : "Tue Jan 04 00:33:25 +0000 2022",
      "favorited" : false,
      "full_text" : "Continuing to make progress on Social Archive 💪\n\nWe're excited to see how distributed tweet archives can preserve individual voices, culture, and history. Can't wait to open up access!",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "meeru",
            "screen_name" : "meeru",
            "indices" : [
              "0",
              "6"
            ],
            "id_str" : "17703833",
            "id" : "17703833"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "10"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1451676767391989765",
      "id_str" : "1451678777012940800",
      "in_reply_to_user_id" : "17703833",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1451678777012940800",
      "in_reply_to_status_id" : "1451676767391989765",
      "created_at" : "Fri Oct 22 22:36:05 +0000 2021",
      "favorited" : false,
      "full_text" : "@meeru 😎🚀🤘",
      "lang" : "und",
      "in_reply_to_screen_name" : "meeru",
      "in_reply_to_user_id_str" : "17703833"
    }
  },
  {
    "tweet" : {
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "user_mentions" : [ ],
        "urls" : [ ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://twitter.com/SocialArchiveCo/status/1451676456984010755/photo/1",
            "indices" : [
              "81",
              "104"
            ],
            "url" : "https://t.co/2m1tHy9MZN",
            "media_url" : "http://pbs.twimg.com/tweet_video_thumb/FCVkCXSaUAA_IVN.jpg",
            "id_str" : "1451676446670606336",
            "id" : "1451676446670606336",
            "media_url_https" : "https://pbs.twimg.com/tweet_video_thumb/FCVkCXSaUAA_IVN.jpg",
            "sizes" : {
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "large" : {
                "w" : "480",
                "h" : "360",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "480",
                "h" : "360",
                "resize" : "fit"
              },
              "small" : {
                "w" : "480",
                "h" : "360",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/2m1tHy9MZN"
          }
        ],
        "hashtags" : [ ]
      },
      "display_text_range" : [
        "0",
        "104"
      ],
      "favorite_count" : "1",
      "id_str" : "1451676456984010755",
      "truncated" : false,
      "retweet_count" : "1",
      "id" : "1451676456984010755",
      "possibly_sensitive" : false,
      "created_at" : "Fri Oct 22 22:26:52 +0000 2021",
      "favorited" : false,
      "full_text" : "Public Tweet archival builds on our belief that social media is a public utility https://t.co/2m1tHy9MZN",
      "lang" : "en",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://twitter.com/SocialArchiveCo/status/1451676456984010755/photo/1",
            "indices" : [
              "81",
              "104"
            ],
            "url" : "https://t.co/2m1tHy9MZN",
            "media_url" : "http://pbs.twimg.com/tweet_video_thumb/FCVkCXSaUAA_IVN.jpg",
            "id_str" : "1451676446670606336",
            "video_info" : {
              "aspect_ratio" : [
                "4",
                "3"
              ],
              "variants" : [
                {
                  "bitrate" : "0",
                  "content_type" : "video/mp4",
                  "url" : "https://video.twimg.com/tweet_video/FCVkCXSaUAA_IVN.mp4"
                }
              ]
            },
            "id" : "1451676446670606336",
            "media_url_https" : "https://pbs.twimg.com/tweet_video_thumb/FCVkCXSaUAA_IVN.jpg",
            "sizes" : {
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "large" : {
                "w" : "480",
                "h" : "360",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "480",
                "h" : "360",
                "resize" : "fit"
              },
              "small" : {
                "w" : "480",
                "h" : "360",
                "resize" : "fit"
              }
            },
            "type" : "animated_gif",
            "display_url" : "pic.twitter.com/2m1tHy9MZN"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "186"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1451675222508142592",
      "id_str" : "1451675396110389248",
      "in_reply_to_user_id" : "1448793710905290770",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1451675396110389248",
      "in_reply_to_status_id" : "1451675222508142592",
      "created_at" : "Fri Oct 22 22:22:39 +0000 2021",
      "favorited" : false,
      "full_text" : "Check out our section in the article!\n\n\"SocialArchive will allow users to store their own data, giving them sovereignty to keep from and/or integrate with other services if they so wish\"",
      "lang" : "en",
      "in_reply_to_screen_name" : "SocialArchiveCo",
      "in_reply_to_user_id_str" : "1448793710905290770"
    }
  },
  {
    "tweet" : {
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Ethereum Swarm",
            "screen_name" : "ethswarm",
            "indices" : [
              "0",
              "9"
            ],
            "id_str" : "1021693481906003968",
            "id" : "1021693481906003968"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/h1exOFIv6D",
            "expanded_url" : "https://medium.com/ethereum-swarm/live-long-and-prosper-announcing-the-third-round-of-swarm-grant-recipients-20332fc364a9",
            "display_url" : "medium.com/ethereum-swarm…",
            "indices" : [
              "51",
              "74"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "74"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1451675036780163076",
      "id_str" : "1451675222508142592",
      "in_reply_to_user_id" : "1448793710905290770",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1451675222508142592",
      "in_reply_to_status_id" : "1451675036780163076",
      "possibly_sensitive" : false,
      "created_at" : "Fri Oct 22 22:21:58 +0000 2021",
      "favorited" : false,
      "full_text" : "@ethswarm Learn about other grant recipients here:\nhttps://t.co/h1exOFIv6D",
      "lang" : "en",
      "in_reply_to_screen_name" : "SocialArchiveCo",
      "in_reply_to_user_id_str" : "1448793710905290770"
    }
  },
  {
    "tweet" : {
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Ethereum Swarm",
            "screen_name" : "ethswarm",
            "indices" : [
              "10",
              "19"
            ],
            "id_str" : "1021693481906003968",
            "id" : "1021693481906003968"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "89"
      ],
      "favorite_count" : "0",
      "id_str" : "1451675036780163076",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1451675036780163076",
      "created_at" : "Fri Oct 22 22:21:14 +0000 2021",
      "favorited" : false,
      "full_text" : "Thanks to @ethswarm, we are building a decentralized public archival method for Twitter 📡",
      "lang" : "en"
    }
  }
]