window.YTD.moment.part0 = [
  {
    "moment" : {
      "momentId" : "1478162996975513603",
      "createdAt" : "2022-01-04T00:34:56.076Z",
      "createdBy" : "1448793710905290770",
      "title" : "Excited for Swarm in 2022!",
      "coverMediaUrls" : [ ],
      "tweets" : [
        {
          "momentId" : "1478162996975513603",
          "tweet" : {
            "deviceSource" : {
              "name" : "Twitter Web App",
              "parameter" : "oauth:3033300",
              "url" : "https://mobile.twitter.com",
              "internalName" : "oauth:3033300",
              "id" : "0",
              "clientAppId" : "3033300",
              "display" : "<a href=\"https://mobile.twitter.com\">Twitter Web App</a>"
            },
            "urls" : [
              {
                "url" : "https://t.co/msRcguYdVA",
                "expanded" : "https://bit.ly/3zsepvd",
                "toIndex" : "276",
                "fromIndex" : "253",
                "display" : "bit.ly/3zsepvd"
              }
            ],
            "coreData" : {
              "nsfwUser" : false,
              "createdVia" : "oauth:3033300",
              "nsfwAdmin" : false,
              "createdAtSecs" : "1641221601",
              "text" : "2021 was a huge year for #ethswarm \n\nThe team recapped the year at the Gather! Swarm event     🐝\n\n- Network status update\n- Research team's goal to enable node operators to earn bzz\n- Grants announcements\nAnd much more\n\nBe sure to check out the video 👇\nhttps://t.co/msRcguYdVA",
              "nullcast" : false,
              "conversationId" : "1478016637051674628",
              "userId" : "1442476876593696782",
              "hasTakedown" : false,
              "hasMedia" : false
            },
            "mentions" : [ ],
            "id" : "1478016637051674628",
            "language" : {
              "language" : "en",
              "rightToLeft" : false,
              "confidence" : "0.590994656085968"
            },
            "media" : [ ],
            "counts" : {
              "retweetCount" : "7",
              "replyCount" : "3",
              "favoriteCount" : "14"
            },
            "cashtags" : [ ],
            "hashtags" : [
              {
                "fromIndex" : "25",
                "toIndex" : "34",
                "text" : "ethswarm"
              }
            ]
          }
        }
      ]
    }
  }
]