window.YTD.connected_application.part0 = [
  {
    "connectedApplication" : {
      "organization" : {
        "name" : "Iconscout",
        "url" : "https://iconscout.com",
        "privacyPolicyUrl" : "https://support.iconscout.com/hc/en-us/articles/360006164154-Privacy-Policy",
        "termsAndConditionsUrl" : "https://support.iconscout.com/hc/en-us/articles/360007897294-Terms-of-Use"
      },
      "name" : "Iconscout",
      "description" : "Iconscout - An Icon Dictionary",
      "permissions" : [
        "read",
        "write",
        "emailaddress"
      ],
      "approvedAt" : "2022-02-20T22:35:44.000Z",
      "id" : "12574325"
    }
  }
]