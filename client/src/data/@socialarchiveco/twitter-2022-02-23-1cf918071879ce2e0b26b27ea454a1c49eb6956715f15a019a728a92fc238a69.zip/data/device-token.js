window.YTD.device_token.part0 = [
  {
    "deviceToken" : {
      "clientApplicationId" : "3033300",
      "token" : "cLoUb532ge8TWE0Ol1DuPq4EF3OjVClzaDOJgu84",
      "createdAt" : "2021-10-14T23:33:50.154Z",
      "lastSeenAt" : "2021-10-14T23:33:50.156Z",
      "clientApplicationName" : "Twitter Web App (Twitter. Inc)"
    }
  },
  {
    "deviceToken" : {
      "clientApplicationId" : "3033300",
      "token" : "4OvbG5Fc8g4i6CJlNKlTGVm3LzoSXupGSa9cUQTO",
      "createdAt" : "2022-01-24T05:38:26.559Z",
      "lastSeenAt" : "2022-01-24T05:38:26.560Z",
      "clientApplicationName" : "Twitter Web App (Twitter. Inc)"
    }
  }
]