window.YTD.ad_engagements.part0 = [
  {
    "ad" : {
      "adsUserData" : {
        "adEngagements" : {
          "engagements" : [
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "84769",
                  "name" : "#AmericanUnderdog",
                  "description" : "The incredible true story of Kurt Warner. In theaters Christmas Day."
                },
                "advertiserInfo" : {
                  "advertiserName" : "American Underdog",
                  "screenName" : "@AmericanUnderdg"
                },
                "impressionTime" : "2021-12-21 20:06:05"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2021-12-21 20:06:06",
                  "engagementType" : "TrendView"
                }
              ]
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adEngagements" : {
          "engagements" : [
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Spotlight",
                "promotedTrendInfo" : {
                  "trendId" : "83587",
                  "name" : "#BeElectric",
                  "description" : "Get ready for a thrill."
                },
                "advertiserInfo" : {
                  "advertiserName" : "Nissan",
                  "screenName" : "@NissanUSA"
                },
                "impressionTime" : "2022-01-04 00:26:53"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-01-04 00:26:54",
                  "engagementType" : "SpotlightView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "83587",
                  "name" : "#BeElectric",
                  "description" : "Get ready for a thrill."
                },
                "advertiserInfo" : {
                  "advertiserName" : "Nissan",
                  "screenName" : "@NissanUSA"
                },
                "impressionTime" : "2022-01-04 00:37:38"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-01-04 00:37:38",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "83587",
                  "name" : "#BeElectric",
                  "description" : "Get ready for a thrill."
                },
                "advertiserInfo" : {
                  "advertiserName" : "Nissan",
                  "screenName" : "@NissanUSA"
                },
                "impressionTime" : "2022-01-04 00:26:23"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-01-04 00:26:24",
                  "engagementType" : "TrendView"
                }
              ]
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adEngagements" : {
          "engagements" : [
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "85696",
                  "name" : "#PamAndTommy",
                  "description" : "Now Streaming on Hulu"
                },
                "advertiserInfo" : {
                  "advertiserName" : "Pam & Tommy on Hulu",
                  "screenName" : "@pamandtommy"
                },
                "impressionTime" : "2022-02-03 01:16:54"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-02-03 01:16:55",
                  "engagementType" : "TrendView"
                }
              ]
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adEngagements" : {
          "engagements" : [
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "85727",
                  "name" : "#Moonfall",
                  "description" : "Moonfall In Theaters Everywhere Friday. Get Tickets Now!"
                },
                "advertiserInfo" : {
                  "advertiserName" : "Moonfall",
                  "screenName" : "@MoonfallFilm"
                },
                "impressionTime" : "2022-02-04 07:34:44"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-02-04 07:34:46",
                  "engagementType" : "TrendView"
                }
              ]
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adEngagements" : {
          "engagements" : [
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "85659",
                  "name" : "#ReacherOnPrime",
                  "description" : "New Series – Now Streaming"
                },
                "advertiserInfo" : {
                  "advertiserName" : "Prime Video",
                  "screenName" : "@PrimeVideo"
                },
                "impressionTime" : "2022-02-05 16:27:34"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-02-05 16:27:35",
                  "engagementType" : "TrendView"
                }
              ]
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adEngagements" : {
          "engagements" : [
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "85740",
                  "name" : "#IONIQ5",
                  "description" : "Fully Electric Hyundai #IONIQ5"
                },
                "advertiserInfo" : {
                  "advertiserName" : "Hyundai USA",
                  "screenName" : "@Hyundai"
                },
                "impressionTime" : "2022-02-06 21:36:24"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-02-06 21:36:26",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "85740",
                  "name" : "#IONIQ5",
                  "description" : "Fully Electric Hyundai #IONIQ5"
                },
                "advertiserInfo" : {
                  "advertiserName" : "Hyundai USA",
                  "screenName" : "@Hyundai"
                },
                "impressionTime" : "2022-02-06 21:33:07"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-02-06 21:33:07",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1488593648073814018",
                  "tweetText" : "We are confident, we are strong, we are loved because of those who were always there. With her father’s support, Olympic Gold Medalist Chloe Kim knows she is prepared to stand on her own during life’s biggest moments. Be inspired by their story.",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "promotedTrendInfo" : {
                  "trendId" : "85348",
                  "name" : "#pggoodeveryday20220206",
                  "description" : ""
                },
                "advertiserInfo" : {
                  "advertiserName" : "P&G Good Everyday",
                  "screenName" : "@pggoodeveryday"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "United States"
                  }
                ],
                "impressionTime" : "2022-02-06 21:33:06"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-02-06 21:33:15",
                  "engagementType" : "VideoContent6secView"
                },
                {
                  "engagementTime" : "2022-02-06 21:33:10",
                  "engagementType" : "VideoContent1secView"
                },
                {
                  "engagementTime" : "2022-02-06 21:50:00",
                  "engagementType" : "VideoContentShortFormComplete"
                },
                {
                  "engagementTime" : "2022-02-06 21:33:15",
                  "engagementType" : "VideoContentPlayback25"
                },
                {
                  "engagementTime" : "2022-02-06 21:49:42",
                  "engagementType" : "VideoContentViewV2"
                },
                {
                  "engagementTime" : "2022-02-06 21:49:59",
                  "engagementType" : "VideoContentPlayback50"
                },
                {
                  "engagementTime" : "2022-02-06 21:33:12",
                  "engagementType" : "VideoContentViewV2"
                },
                {
                  "engagementTime" : "2022-02-06 21:33:12",
                  "engagementType" : "VideoContentViewThreshold"
                },
                {
                  "engagementTime" : "2022-02-06 21:50:07",
                  "engagementType" : "VideoContentPlayback75"
                },
                {
                  "engagementTime" : "2022-02-06 21:33:09",
                  "engagementType" : "VideoContentPlaybackStart"
                },
                {
                  "engagementTime" : "2022-02-06 21:50:17",
                  "engagementType" : "VideoSession"
                },
                {
                  "engagementTime" : "2022-02-06 21:50:12",
                  "engagementType" : "VideoContentPlayback95"
                },
                {
                  "engagementTime" : "2022-02-06 21:50:14",
                  "engagementType" : "VideoContentPlaybackComplete"
                },
                {
                  "engagementTime" : "2022-02-06 21:33:11",
                  "engagementType" : "VideoContentMrcView"
                },
                {
                  "engagementTime" : "2022-02-06 21:33:19",
                  "engagementType" : "VideoSession"
                }
              ]
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adEngagements" : {
          "engagements" : [
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "85740",
                  "name" : "#IONIQ5",
                  "description" : "Fully Electric Hyundai #IONIQ5"
                },
                "advertiserInfo" : {
                  "advertiserName" : "Hyundai USA",
                  "screenName" : "@Hyundai"
                },
                "impressionTime" : "2022-02-07 04:01:53"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-02-07 04:01:54",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "85740",
                  "name" : "#IONIQ5",
                  "description" : "Fully Electric Hyundai #IONIQ5"
                },
                "advertiserInfo" : {
                  "advertiserName" : "Hyundai USA",
                  "screenName" : "@Hyundai"
                },
                "impressionTime" : "2022-02-07 04:01:28"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-02-07 04:01:29",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "TimelineHome",
                "advertiserInfo" : {
                  "advertiserName" : "The Fast Track™",
                  "screenName" : "@ByUplifter"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "18 and up"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "United States"
                  },
                  {
                    "targetingType" : "Languages",
                    "targetingValue" : "English"
                  }
                ],
                "impressionTime" : "2022-02-07 04:01:28"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-02-07 04:01:34",
                  "engagementType" : "VideoContentMrcView"
                },
                {
                  "engagementTime" : "2022-02-07 04:01:38",
                  "engagementType" : "VideoSession"
                },
                {
                  "engagementTime" : "2022-02-07 04:01:33",
                  "engagementType" : "VideoContentPlayback25"
                },
                {
                  "engagementTime" : "2022-02-07 04:01:30",
                  "engagementType" : "VideoContentPlaybackStart"
                },
                {
                  "engagementTime" : "2022-02-07 04:01:37",
                  "engagementType" : "VideoContentPlayback50"
                }
              ]
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adEngagements" : {
          "engagements" : [
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "83175",
                  "name" : "#TeamofTomorrow",
                  "description" : "Bringing inspiration home"
                },
                "advertiserInfo" : {
                  "advertiserName" : "Comcast",
                  "screenName" : "@comcast"
                },
                "impressionTime" : "2022-02-08 01:24:48"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-02-08 01:24:49",
                  "engagementType" : "TrendView"
                }
              ]
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adEngagements" : {
          "engagements" : [
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "86136",
                  "name" : "#PS5TREATCODES",
                  "description" : "Spot Treat Codes to Enter"
                },
                "advertiserInfo" : {
                  "advertiserName" : "PlayStation",
                  "screenName" : "@PlayStation"
                },
                "impressionTime" : "2022-02-20 23:52:27"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-02-20 23:52:28",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "86136",
                  "name" : "#PS5TREATCODES",
                  "description" : "Spot Treat Codes to Enter"
                },
                "advertiserInfo" : {
                  "advertiserName" : "PlayStation",
                  "screenName" : "@PlayStation"
                },
                "impressionTime" : "2022-02-20 22:09:29"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-02-20 22:09:30",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "86136",
                  "name" : "#PS5TREATCODES",
                  "description" : "Spot Treat Codes to Enter"
                },
                "advertiserInfo" : {
                  "advertiserName" : "PlayStation",
                  "screenName" : "@PlayStation"
                },
                "impressionTime" : "2022-02-20 22:10:17"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-02-20 22:10:18",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "86136",
                  "name" : "#PS5TREATCODES",
                  "description" : "Spot Treat Codes to Enter"
                },
                "advertiserInfo" : {
                  "advertiserName" : "PlayStation",
                  "screenName" : "@PlayStation"
                },
                "impressionTime" : "2022-02-20 22:34:05"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-02-20 22:34:06",
                  "engagementType" : "TrendView"
                }
              ]
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adEngagements" : {
          "engagements" : [
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "84964",
                  "name" : "#The355",
                  "description" : "Only in Theaters Friday"
                },
                "advertiserInfo" : {
                  "advertiserName" : "The 355",
                  "screenName" : "@the355movie"
                },
                "impressionTime" : "2022-01-04 15:54:09"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-01-04 15:54:11",
                  "engagementType" : "TrendView"
                }
              ]
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adEngagements" : {
          "engagements" : [
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "84964",
                  "name" : "#The355",
                  "description" : "Only in Theaters Friday"
                },
                "advertiserInfo" : {
                  "advertiserName" : "The 355",
                  "screenName" : "@the355movie"
                },
                "impressionTime" : "2022-01-04 23:45:50"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-01-04 23:45:51",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1478450800477286403",
                  "tweetText" : "Streaming, gaming, sports, music, small biz and home internet are going Ultra! See what you missed on the 5G #UltraShow, hosted by Elizabeth Banks. Watch now! 🔥\n\nhttps://t.co/X3p9Tq5XqV",
                  "urls" : [
                    "https://t.co/X3p9Tq5XqV"
                  ],
                  "mediaUrls" : [ ]
                },
                "promotedTrendInfo" : {
                  "trendId" : "85030",
                  "name" : "#Verizon20220104",
                  "description" : ""
                },
                "advertiserInfo" : {
                  "advertiserName" : "Verizon",
                  "screenName" : "@Verizon"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "United States"
                  }
                ],
                "impressionTime" : "2022-01-04 23:58:35"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-01-04 23:58:38",
                  "engagementType" : "VideoContentPlaybackStart"
                },
                {
                  "engagementTime" : "2022-01-04 23:58:39",
                  "engagementType" : "VideoContent1secView"
                },
                {
                  "engagementTime" : "2022-01-04 23:58:40",
                  "engagementType" : "VideoSession"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "84964",
                  "name" : "#The355",
                  "description" : "Only in Theaters Friday"
                },
                "advertiserInfo" : {
                  "advertiserName" : "The 355",
                  "screenName" : "@the355movie"
                },
                "impressionTime" : "2022-01-04 23:58:35"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-01-04 23:58:35",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "84964",
                  "name" : "#The355",
                  "description" : "Only in Theaters Friday"
                },
                "advertiserInfo" : {
                  "advertiserName" : "The 355",
                  "screenName" : "@the355movie"
                },
                "impressionTime" : "2022-01-04 23:45:54"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-01-04 23:45:55",
                  "engagementType" : "TrendView"
                }
              ]
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adEngagements" : {
          "engagements" : [
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "85134",
                  "name" : "#GMUltiumEffect",
                  "description" : "Check out the GM Ultium effect"
                },
                "advertiserInfo" : {
                  "advertiserName" : "General Motors",
                  "screenName" : "@GM"
                },
                "impressionTime" : "2022-01-05 16:04:01"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-01-05 16:04:02",
                  "engagementType" : "TrendView"
                }
              ]
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adEngagements" : {
          "engagements" : [
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "85166",
                  "name" : "#SilveradoEV",
                  "description" : "A new standard for pickups"
                },
                "advertiserInfo" : {
                  "advertiserName" : "Chevrolet",
                  "screenName" : "@chevrolet"
                },
                "impressionTime" : "2022-01-06 14:52:24"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-01-06 14:52:24",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "85166",
                  "name" : "#SilveradoEV",
                  "description" : "A new standard for pickups"
                },
                "advertiserInfo" : {
                  "advertiserName" : "Chevrolet",
                  "screenName" : "@chevrolet"
                },
                "impressionTime" : "2022-01-06 14:53:51"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-01-06 14:53:52",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "85166",
                  "name" : "#SilveradoEV",
                  "description" : "A new standard for pickups"
                },
                "advertiserInfo" : {
                  "advertiserName" : "Chevrolet",
                  "screenName" : "@chevrolet"
                },
                "impressionTime" : "2022-01-06 14:56:33"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-01-06 14:56:34",
                  "engagementType" : "TrendView"
                }
              ]
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adEngagements" : {
          "engagements" : [
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "85166",
                  "name" : "#SilveradoEV",
                  "description" : "A new standard for pickups"
                },
                "advertiserInfo" : {
                  "advertiserName" : "Chevrolet",
                  "screenName" : "@chevrolet"
                },
                "impressionTime" : "2022-01-06 17:34:39"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-01-06 17:34:39",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "85166",
                  "name" : "#SilveradoEV",
                  "description" : "A new standard for pickups"
                },
                "advertiserInfo" : {
                  "advertiserName" : "Chevrolet",
                  "screenName" : "@chevrolet"
                },
                "impressionTime" : "2022-01-06 19:00:24"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-01-06 19:00:26",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1479093665503105026",
                  "tweetText" : "A pickup truck with a revolutionary mix of capability, performance and design. Plus, zero tailpipe emissions. #SilveradoEV",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "promotedTrendInfo" : {
                  "trendId" : "85166",
                  "name" : "#SilveradoEV",
                  "description" : "A new standard for pickups"
                },
                "advertiserInfo" : {
                  "advertiserName" : "Chevrolet",
                  "screenName" : "@chevrolet"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "United States"
                  }
                ],
                "impressionTime" : "2022-01-06 19:00:24"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-01-06 19:05:53",
                  "engagementType" : "VideoContentPlayback25"
                },
                {
                  "engagementTime" : "2022-01-06 19:05:50",
                  "engagementType" : "VideoContentPlaybackStart"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "85166",
                  "name" : "#SilveradoEV",
                  "description" : "A new standard for pickups"
                },
                "advertiserInfo" : {
                  "advertiserName" : "Chevrolet",
                  "screenName" : "@chevrolet"
                },
                "impressionTime" : "2022-01-06 23:53:51"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-01-06 23:53:51",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "85166",
                  "name" : "#SilveradoEV",
                  "description" : "A new standard for pickups"
                },
                "advertiserInfo" : {
                  "advertiserName" : "Chevrolet",
                  "screenName" : "@chevrolet"
                },
                "impressionTime" : "2022-01-06 23:56:09"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-01-06 23:56:11",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "85166",
                  "name" : "#SilveradoEV",
                  "description" : "A new standard for pickups"
                },
                "advertiserInfo" : {
                  "advertiserName" : "Chevrolet",
                  "screenName" : "@chevrolet"
                },
                "impressionTime" : "2022-01-06 23:53:39"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-01-06 23:53:40",
                  "engagementType" : "TrendView"
                }
              ]
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adEngagements" : {
          "engagements" : [
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "85223",
                  "name" : "#DisneyPlus",
                  "description" : "Stream The Book of Boba Fett, Eternals, & more."
                },
                "advertiserInfo" : {
                  "advertiserName" : "Disney+",
                  "screenName" : "@disneyplus"
                },
                "impressionTime" : "2022-01-07 15:55:19"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-01-07 15:55:20",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "85223",
                  "name" : "#DisneyPlus",
                  "description" : "Stream The Book of Boba Fett, Eternals, & more."
                },
                "advertiserInfo" : {
                  "advertiserName" : "Disney+",
                  "screenName" : "@disneyplus"
                },
                "impressionTime" : "2022-01-07 15:59:30"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-01-07 15:59:31",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1478514180311240710",
                  "tweetText" : "Directed by George Clooney and starring Ben Affleck, #TheTenderBar is streaming now on Amazon Prime Video.",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "promotedTrendInfo" : {
                  "trendId" : "85017",
                  "name" : "#PrimeVideo20220107",
                  "description" : ""
                },
                "advertiserInfo" : {
                  "advertiserName" : "Prime Video",
                  "screenName" : "@PrimeVideo"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "United States"
                  }
                ],
                "impressionTime" : "2022-01-07 15:59:29"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-01-07 15:59:47",
                  "engagementType" : "VideoContentPlaybackComplete"
                },
                {
                  "engagementTime" : "2022-01-07 15:59:33",
                  "engagementType" : "VideoContentPlaybackStart"
                },
                {
                  "engagementTime" : "2022-01-07 15:59:43",
                  "engagementType" : "VideoContentPlayback75"
                },
                {
                  "engagementTime" : "2022-01-07 15:59:47",
                  "engagementType" : "VideoContentShortFormComplete"
                },
                {
                  "engagementTime" : "2022-01-07 15:59:36",
                  "engagementType" : "VideoContentPlayback25"
                },
                {
                  "engagementTime" : "2022-01-07 15:59:46",
                  "engagementType" : "VideoContentPlayback95"
                },
                {
                  "engagementTime" : "2022-01-07 15:59:39",
                  "engagementType" : "VideoContentPlayback50"
                }
              ]
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adEngagements" : {
          "engagements" : [
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1479271757513117700",
                  "tweetText" : "The first #F150Lightning trucks are nearing production and they’re history in the making. #BuiltFordProud #LetThereBeLIGHTNING",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "promotedTrendInfo" : {
                  "trendId" : "85216",
                  "name" : "#Ford20220109",
                  "description" : ""
                },
                "advertiserInfo" : {
                  "advertiserName" : "Ford Motor Company",
                  "screenName" : "@Ford"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "United States"
                  }
                ],
                "impressionTime" : "2022-01-10 02:58:48"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-01-10 02:58:51",
                  "engagementType" : "VideoContentPlaybackStart"
                },
                {
                  "engagementTime" : "2022-01-10 02:58:51",
                  "engagementType" : "VideoContentPlayback25"
                },
                {
                  "engagementTime" : "2022-01-10 02:58:52",
                  "engagementType" : "VideoContentPlayback50"
                }
              ]
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adEngagements" : {
          "engagements" : [
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "85470",
                  "name" : "#PlantersAllorOne",
                  "description" : "How do you eat Deluxe Mixed Nuts? "
                },
                "advertiserInfo" : {
                  "advertiserName" : "Mr. Peanut",
                  "screenName" : "@MrPeanut"
                },
                "impressionTime" : "2022-01-24 05:38:28"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-01-24 05:38:31",
                  "engagementType" : "TrendView"
                }
              ]
            }
          ]
        }
      }
    }
  }
]