window.YTD.ad_impressions.part0 = [
  {
    "ad" : {
      "adsUserData" : {
        "adImpressions" : {
          "impressions" : [
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "WtfSidebar",
              "advertiserInfo" : {
                "advertiserName" : "Bank of America",
                "screenName" : "@BankofAmerica"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Science news"
                },
                {
                  "targetingType" : "List",
                  "targetingValue" : "EHL_20211213"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Minnesota"
                }
              ],
              "impressionTime" : "2021-12-21 20:06:06"
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adImpressions" : {
          "impressions" : [
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "ProfileAccountsSidebar",
              "advertiserInfo" : {
                "advertiserName" : "1inch Network",
                "screenName" : "@1inch"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@bitfinex"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@cryptomanran"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@BinanceResearch"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@BinanceChain"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@TheBinanceNFT"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@dapp_com"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@CoinMarketCap"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@Poloniex"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@CoinDesk"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@CurveFinance"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@TheCryptoDog"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@TheBlock__"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@defipulse"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@0xPolygon"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@haydenzadams"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@PancakeSwap"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@MMCrypto"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@cz_binance"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@avalancheavax"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@gate_io"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@0xProject"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@cryptocom"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@okx"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@crypto_birb"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@coinbase"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@VitalikButerin"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@MetaMask"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@ForbesCrypto"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@BinanceUS"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@krakenfx"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@coingecko"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@opensea"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@BittrexExchange"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@TrustWallet"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@HuobiGlobal"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@Gemini"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@Bybit_Official"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@myetherwallet"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@dogecoin"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@harmonyprotocol"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "United States"
                }
              ],
              "impressionTime" : "2022-01-04 00:26:26"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "ProfileAccountsSidebar",
              "advertiserInfo" : {
                "advertiserName" : "1inch Network",
                "screenName" : "@1inch"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@bitfinex"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@cryptomanran"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@BinanceResearch"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@BinanceChain"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@TheBinanceNFT"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@dapp_com"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@CoinMarketCap"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@Poloniex"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@CoinDesk"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@CurveFinance"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@TheCryptoDog"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@TheBlock__"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@defipulse"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@0xPolygon"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@haydenzadams"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@PancakeSwap"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@MMCrypto"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@cz_binance"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@avalancheavax"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@gate_io"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@0xProject"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@cryptocom"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@okx"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@crypto_birb"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@coinbase"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@VitalikButerin"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@MetaMask"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@ForbesCrypto"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@BinanceUS"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@krakenfx"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@coingecko"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@opensea"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@BittrexExchange"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@TrustWallet"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@HuobiGlobal"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@Gemini"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@Bybit_Official"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@myetherwallet"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@dogecoin"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@harmonyprotocol"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "United States"
                }
              ],
              "impressionTime" : "2022-01-04 00:28:06"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "WtfSidebar",
              "advertiserInfo" : {
                "advertiserName" : "1inch Network",
                "screenName" : "@1inch"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@bitfinex"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@cryptomanran"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@BinanceResearch"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@BinanceChain"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@TheBinanceNFT"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@dapp_com"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@CoinMarketCap"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@Poloniex"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@CoinDesk"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@CurveFinance"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@TheCryptoDog"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@TheBlock__"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@defipulse"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@0xPolygon"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@haydenzadams"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@PancakeSwap"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@MMCrypto"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@cz_binance"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@avalancheavax"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@gate_io"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@0xProject"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@cryptocom"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@okx"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@crypto_birb"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@coinbase"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@VitalikButerin"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@MetaMask"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@ForbesCrypto"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@BinanceUS"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@krakenfx"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@coingecko"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@opensea"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@BittrexExchange"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@TrustWallet"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@HuobiGlobal"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@Gemini"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@Bybit_Official"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@myetherwallet"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@dogecoin"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@harmonyprotocol"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "United States"
                }
              ],
              "impressionTime" : "2022-01-04 00:26:25"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "WtfSidebar",
              "advertiserInfo" : {
                "advertiserName" : "1inch Network",
                "screenName" : "@1inch"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@bitfinex"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@cryptomanran"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@BinanceResearch"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@BinanceChain"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@TheBinanceNFT"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@dapp_com"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@CoinMarketCap"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@Poloniex"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@CoinDesk"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@CurveFinance"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@TheCryptoDog"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@TheBlock__"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@defipulse"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@0xPolygon"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@haydenzadams"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@PancakeSwap"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@MMCrypto"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@cz_binance"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@avalancheavax"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@gate_io"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@0xProject"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@cryptocom"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@okx"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@crypto_birb"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@coinbase"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@VitalikButerin"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@MetaMask"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@ForbesCrypto"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@BinanceUS"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@krakenfx"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@coingecko"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@opensea"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@BittrexExchange"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@TrustWallet"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@HuobiGlobal"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@Gemini"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@Bybit_Official"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@myetherwallet"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@dogecoin"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@harmonyprotocol"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "United States"
                }
              ],
              "impressionTime" : "2022-01-04 00:26:24"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "ProfileAccountsSidebar",
              "advertiserInfo" : {
                "advertiserName" : "1inch Network",
                "screenName" : "@1inch"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@bitfinex"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@cryptomanran"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@BinanceResearch"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@BinanceChain"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@TheBinanceNFT"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@dapp_com"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@CoinMarketCap"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@Poloniex"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@CoinDesk"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@CurveFinance"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@TheCryptoDog"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@TheBlock__"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@defipulse"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@0xPolygon"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@haydenzadams"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@PancakeSwap"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@MMCrypto"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@cz_binance"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@avalancheavax"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@gate_io"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@0xProject"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@cryptocom"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@okx"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@crypto_birb"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@coinbase"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@VitalikButerin"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@MetaMask"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@ForbesCrypto"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@BinanceUS"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@krakenfx"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@coingecko"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@opensea"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@BittrexExchange"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@TrustWallet"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@HuobiGlobal"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@Gemini"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@Bybit_Official"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@myetherwallet"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@dogecoin"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@harmonyprotocol"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "United States"
                }
              ],
              "impressionTime" : "2022-01-04 00:28:05"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "ProfileAccountsSidebar",
              "advertiserInfo" : {
                "advertiserName" : "1inch Network",
                "screenName" : "@1inch"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@bitfinex"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@cryptomanran"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@BinanceResearch"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@BinanceChain"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@TheBinanceNFT"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@dapp_com"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@CoinMarketCap"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@Poloniex"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@CoinDesk"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@CurveFinance"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@TheCryptoDog"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@TheBlock__"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@defipulse"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@0xPolygon"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@haydenzadams"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@PancakeSwap"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@MMCrypto"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@cz_binance"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@avalancheavax"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@gate_io"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@0xProject"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@cryptocom"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@okx"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@crypto_birb"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@coinbase"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@VitalikButerin"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@MetaMask"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@ForbesCrypto"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@BinanceUS"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@krakenfx"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@coingecko"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@opensea"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@BittrexExchange"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@TrustWallet"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@HuobiGlobal"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@Gemini"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@Bybit_Official"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@myetherwallet"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@dogecoin"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@harmonyprotocol"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "United States"
                }
              ],
              "impressionTime" : "2022-01-04 00:30:27"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "WtfSidebar",
              "advertiserInfo" : {
                "advertiserName" : "1inch Network",
                "screenName" : "@1inch"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@bitfinex"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@cryptomanran"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@BinanceResearch"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@BinanceChain"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@TheBinanceNFT"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@dapp_com"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@CoinMarketCap"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@Poloniex"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@CoinDesk"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@CurveFinance"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@TheCryptoDog"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@TheBlock__"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@defipulse"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@0xPolygon"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@haydenzadams"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@PancakeSwap"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@MMCrypto"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@cz_binance"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@avalancheavax"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@gate_io"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@0xProject"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@cryptocom"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@okx"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@crypto_birb"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@coinbase"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@VitalikButerin"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@MetaMask"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@ForbesCrypto"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@BinanceUS"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@krakenfx"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@coingecko"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@opensea"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@BittrexExchange"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@TrustWallet"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@HuobiGlobal"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@Gemini"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@Bybit_Official"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@myetherwallet"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@dogecoin"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@harmonyprotocol"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "United States"
                }
              ],
              "impressionTime" : "2022-01-04 00:37:38"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "ProfileAccountsSidebar",
              "advertiserInfo" : {
                "advertiserName" : "1inch Network",
                "screenName" : "@1inch"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@bitfinex"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@cryptomanran"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@BinanceResearch"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@BinanceChain"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@TheBinanceNFT"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@dapp_com"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@CoinMarketCap"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@Poloniex"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@CoinDesk"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@CurveFinance"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@TheCryptoDog"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@TheBlock__"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@defipulse"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@0xPolygon"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@haydenzadams"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@PancakeSwap"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@MMCrypto"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@cz_binance"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@avalancheavax"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@gate_io"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@0xProject"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@cryptocom"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@okx"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@crypto_birb"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@coinbase"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@VitalikButerin"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@MetaMask"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@ForbesCrypto"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@BinanceUS"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@krakenfx"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@coingecko"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@opensea"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@BittrexExchange"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@TrustWallet"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@HuobiGlobal"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@Gemini"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@Bybit_Official"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@myetherwallet"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@dogecoin"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@harmonyprotocol"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "United States"
                }
              ],
              "impressionTime" : "2022-01-04 00:37:40"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "ProfileAccountsSidebar",
              "advertiserInfo" : {
                "advertiserName" : "1inch Network",
                "screenName" : "@1inch"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@bitfinex"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@cryptomanran"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@BinanceResearch"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@BinanceChain"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@TheBinanceNFT"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@dapp_com"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@CoinMarketCap"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@Poloniex"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@CoinDesk"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@CurveFinance"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@TheCryptoDog"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@TheBlock__"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@defipulse"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@0xPolygon"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@haydenzadams"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@PancakeSwap"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@MMCrypto"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@cz_binance"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@avalancheavax"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@gate_io"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@0xProject"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@cryptocom"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@okx"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@crypto_birb"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@coinbase"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@VitalikButerin"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@MetaMask"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@ForbesCrypto"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@BinanceUS"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@krakenfx"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@coingecko"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@opensea"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@BittrexExchange"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@TrustWallet"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@HuobiGlobal"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@Gemini"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@Bybit_Official"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@myetherwallet"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@dogecoin"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@harmonyprotocol"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "United States"
                }
              ],
              "impressionTime" : "2022-01-04 00:30:26"
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adImpressions" : {
          "impressions" : [
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "WtfSidebar",
              "advertiserInfo" : {
                "advertiserName" : "Treehouse Finance",
                "screenName" : "@TreehouseFi"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@BinanceChain"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@TheBinanceNFT"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@CoinMarketCap"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@defipulse"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@Bitcoin"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@opensea"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "United States"
                },
                {
                  "targetingType" : "Languages",
                  "targetingValue" : "English"
                }
              ],
              "impressionTime" : "2022-01-27 16:36:18"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "WtfSidebar",
              "advertiserInfo" : {
                "advertiserName" : "Treehouse Finance",
                "screenName" : "@TreehouseFi"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@BinanceChain"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@TheBinanceNFT"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@CoinMarketCap"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@defipulse"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@Bitcoin"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@opensea"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                },
                {
                  "targetingType" : "Languages",
                  "targetingValue" : "English"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "United States"
                }
              ],
              "impressionTime" : "2022-01-27 16:36:20"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "WtfSidebar",
              "advertiserInfo" : {
                "advertiserName" : "VitalXP",
                "screenName" : "@VitalGameverse"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@TheSandboxGame"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@decentraland"
                },
                {
                  "targetingType" : "Gender",
                  "targetingValue" : "Men"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "United States"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "Desktop"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 to 34"
                }
              ],
              "impressionTime" : "2022-01-27 16:42:19"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "WtfSidebar",
              "advertiserInfo" : {
                "advertiserName" : "Invesco US",
                "screenName" : "@InvescoUS"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "United States"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "25 and up"
                }
              ],
              "impressionTime" : "2022-01-27 18:05:47"
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adImpressions" : {
          "impressions" : [
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1488593648073814018",
                "tweetText" : "We are confident, we are strong, we are loved because of those who were always there. With her father’s support, Olympic Gold Medalist Chloe Kim knows she is prepared to stand on her own during life’s biggest moments. Be inspired by their story.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "promotedTrendInfo" : {
                "trendId" : "85348",
                "name" : "#pggoodeveryday20220206",
                "description" : ""
              },
              "advertiserInfo" : {
                "advertiserName" : "P&G Good Everyday",
                "screenName" : "@pggoodeveryday"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "United States"
                }
              ],
              "impressionTime" : "2022-02-06 21:33:08"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "WtfSidebar",
              "advertiserInfo" : {
                "advertiserName" : "BetMGM 🦁",
                "screenName" : "@BetMGM"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "New Jersey"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "21 and up"
                }
              ],
              "impressionTime" : "2022-02-06 21:33:07"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "ProfileAccountsSidebar",
              "advertiserInfo" : {
                "advertiserName" : "Avalanche 🔺",
                "screenName" : "@avalancheavax"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "#crypto"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@SatoshiLite"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@VitalikButerin"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@RaoulGMI"
                },
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "Cryptocurrencies"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "21 to 49"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "United States"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "Desktop"
                }
              ],
              "impressionTime" : "2022-02-06 21:59:55"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "ProfileTweets",
              "promotedTweetInfo" : {
                "tweetId" : "1480905743645696003",
                "tweetText" : "Squad goal: Saving on car insurance. 🚙",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Flo from Progressive",
                "screenName" : "@ItsFlo"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Website Activity",
                  "targetingValue" : "Quote Finish"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "Desktop"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "New Jersey"
                }
              ],
              "impressionTime" : "2022-02-06 21:48:23"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "ProfileTweets",
              "promotedTweetInfo" : {
                "tweetId" : "1484276020274466817",
                "tweetText" : "Boardroom diversity helps create an equitable future, but how does it translate to stock prices?",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "E*TRADE from Morgan Stanley",
                "screenName" : "@etrade"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "$cvx"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "finance"
                },
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Financial news"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@CNBCFastMoney"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@BusinessInsider"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "Desktop"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "25 to 49"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "United States"
                }
              ],
              "impressionTime" : "2022-02-06 21:59:55"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "ClusterFollow",
              "advertiserInfo" : {
                "advertiserName" : "BetMGM 🦁",
                "screenName" : "@BetMGM"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "New Jersey"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "21 and up"
                }
              ],
              "impressionTime" : "2022-02-06 21:33:22"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "WtfSidebar",
              "advertiserInfo" : {
                "advertiserName" : "BetMGMCasino",
                "screenName" : "@BetMGMCasino"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Age",
                  "targetingValue" : "21 and up"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "New Jersey"
                }
              ],
              "impressionTime" : "2022-02-06 21:48:17"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "ProfileAccountsSidebar",
              "advertiserInfo" : {
                "advertiserName" : "Avalanche 🔺",
                "screenName" : "@avalancheavax"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "#crypto"
                },
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "Cryptocurrencies"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@SatoshiLite"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@VitalikButerin"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@RaoulGMI"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "United States"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "Desktop"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "21 to 49"
                }
              ],
              "impressionTime" : "2022-02-06 21:59:56"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "WtfSidebar",
              "advertiserInfo" : {
                "advertiserName" : "BetMGMCasino",
                "screenName" : "@BetMGMCasino"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Age",
                  "targetingValue" : "21 and up"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "New Jersey"
                }
              ],
              "impressionTime" : "2022-02-06 21:33:08"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1489704825713483777",
                "tweetText" : "Investing in art just got more accessible, more intuitive, and more affordable. \n\nEven in today’s unpredictable market, Masterworks investors received a net IRR of 30% in 2020 and 2021, based on the sale of two paintings. \n\nNow, anyone can invest in blue-chip art.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Sophie Schneider",
                "screenName" : "@sophiesishere"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "Cryptocurrency"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "Cryptocurrencies"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "Crypto"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "Ethereum"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@eToro"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@RobinhoodApp"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@BinanceAcademy"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@CoinbaseExch"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@BinanceLabs"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@binance"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@BinanceResearch"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@BinanceChain"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@CoinbaseSupport"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@CommerceCB"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@eToroUS"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@APompliano"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@BinanceBCF"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@BinanceHelpDesk"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@coinbase"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@krakenfx"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@CoinbaseWallet"
                },
                {
                  "targetingType" : "List",
                  "targetingValue" : "User list 9-2021"
                },
                {
                  "targetingType" : "List",
                  "targetingValue" : "12-28-21 user list for exclusion"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "United States"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "Desktop"
                },
                {
                  "targetingType" : "Gender",
                  "targetingValue" : "Men"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "25 and up"
                }
              ],
              "impressionTime" : "2022-02-06 21:49:50"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "ProfileAccountsSidebar",
              "advertiserInfo" : {
                "advertiserName" : "Avalanche 🔺",
                "screenName" : "@avalancheavax"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "Cryptocurrencies"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "#crypto"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@SatoshiLite"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@VitalikButerin"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@RaoulGMI"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "21 to 49"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "United States"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "Desktop"
                }
              ],
              "impressionTime" : "2022-02-06 21:50:18"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "ProfileAccountsSidebar",
              "advertiserInfo" : {
                "advertiserName" : "Avalanche 🔺",
                "screenName" : "@avalancheavax"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "Cryptocurrencies"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "#crypto"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@SatoshiLite"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@VitalikButerin"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@RaoulGMI"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "United States"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "21 to 49"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "Desktop"
                }
              ],
              "impressionTime" : "2022-02-06 21:33:21"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "ProfileAccountsSidebar",
              "advertiserInfo" : {
                "advertiserName" : "Avalanche 🔺",
                "screenName" : "@avalancheavax"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "Cryptocurrencies"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "#crypto"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@SatoshiLite"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@VitalikButerin"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@RaoulGMI"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "Desktop"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "United States"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "21 to 49"
                }
              ],
              "impressionTime" : "2022-02-06 21:33:20"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "ProfileAccountsSidebar",
              "advertiserInfo" : {
                "advertiserName" : "Avalanche 🔺",
                "screenName" : "@avalancheavax"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "Cryptocurrencies"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "#crypto"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@SatoshiLite"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@VitalikButerin"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@RaoulGMI"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "United States"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "Desktop"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "21 to 49"
                }
              ],
              "impressionTime" : "2022-02-06 21:50:32"
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adImpressions" : {
          "impressions" : [
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "WtfSidebar",
              "advertiserInfo" : {
                "advertiserName" : "BetMGM 🦁",
                "screenName" : "@BetMGM"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "New Jersey"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "21 and up"
                }
              ],
              "impressionTime" : "2022-02-07 04:01:28"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "ProfileAccountsSidebar",
              "advertiserInfo" : {
                "advertiserName" : "Avalanche 🔺",
                "screenName" : "@avalancheavax"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "Cryptocurrencies"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@SatoshiLite"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@VitalikButerin"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@RaoulGMI"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "#crypto"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "Desktop"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "United States"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "21 to 49"
                }
              ],
              "impressionTime" : "2022-02-07 04:01:43"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "ProfileAccountsSidebar",
              "advertiserInfo" : {
                "advertiserName" : "Avalanche 🔺",
                "screenName" : "@avalancheavax"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "Cryptocurrencies"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@SatoshiLite"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@VitalikButerin"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@RaoulGMI"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "#crypto"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "United States"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "21 to 49"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "Desktop"
                }
              ],
              "impressionTime" : "2022-02-07 04:01:44"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "WtfSidebar",
              "advertiserInfo" : {
                "advertiserName" : "BetMGM 🦁",
                "screenName" : "@BetMGM"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Age",
                  "targetingValue" : "21 and up"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "New Jersey"
                }
              ],
              "impressionTime" : "2022-02-07 04:01:53"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "advertiserInfo" : {
                "advertiserName" : "The Fast Track™",
                "screenName" : "@ByUplifter"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "United States"
                },
                {
                  "targetingType" : "Languages",
                  "targetingValue" : "English"
                }
              ],
              "impressionTime" : "2022-02-07 04:01:29"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1489704825713483777",
                "tweetText" : "Investing in art just got more accessible, more intuitive, and more affordable. \n\nEven in today’s unpredictable market, Masterworks investors received a net IRR of 30% in 2020 and 2021, based on the sale of two paintings. \n\nNow, anyone can invest in blue-chip art.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Sophie Schneider",
                "screenName" : "@sophiesishere"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "Ethereum"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "Cryptocurrency"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "Crypto"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "Cryptocurrencies"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@eToro"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@RobinhoodApp"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@BinanceAcademy"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@CoinbaseExch"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@BinanceLabs"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@binance"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@BinanceResearch"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@BinanceChain"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@CoinbaseSupport"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@CommerceCB"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@eToroUS"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@APompliano"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@BinanceBCF"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@BinanceHelpDesk"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@coinbase"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@krakenfx"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@CoinbaseWallet"
                },
                {
                  "targetingType" : "List",
                  "targetingValue" : "User list 9-2021"
                },
                {
                  "targetingType" : "List",
                  "targetingValue" : "12-28-21 user list for exclusion"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "25 and up"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "United States"
                },
                {
                  "targetingType" : "Gender",
                  "targetingValue" : "Men"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "Desktop"
                }
              ],
              "impressionTime" : "2022-02-07 04:01:54"
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adImpressions" : {
          "impressions" : [
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "ProfileAccountsSidebar",
              "advertiserInfo" : {
                "advertiserName" : "BetMGM 🦁",
                "screenName" : "@BetMGM"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Age",
                  "targetingValue" : "21 and up"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "New Jersey"
                }
              ],
              "impressionTime" : "2022-02-08 01:24:57"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1490641491622043650",
                "tweetText" : "Introducing Bud Light NEXT, our first beer with zero carbs. Brewed to make sure there’s zero in the way of possibility. We're adding $10k to your bank account so there's 0 in your way.\n\nReply with a photo of a 0 using #SpotAZero #Sweepstakes to be entered for a chance to win. https://t.co/geboYSchrV",
                "urls" : [ ],
                "mediaUrls" : [
                  "https://t.co/geboYSchrV"
                ]
              },
              "promotedTrendInfo" : {
                "trendId" : "85002",
                "name" : "#budlight20220207",
                "description" : ""
              },
              "advertiserInfo" : {
                "advertiserName" : "Bud Light",
                "screenName" : "@budlight"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "United States"
                }
              ],
              "impressionTime" : "2022-02-08 01:24:49"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "WtfSidebar",
              "advertiserInfo" : {
                "advertiserName" : "BetMGM 🦁",
                "screenName" : "@BetMGM"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Age",
                  "targetingValue" : "21 and up"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "New Jersey"
                }
              ],
              "impressionTime" : "2022-02-08 01:24:48"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "ProfileAccountsSidebar",
              "advertiserInfo" : {
                "advertiserName" : "Avalanche 🔺",
                "screenName" : "@avalancheavax"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "Cryptocurrencies"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "#crypto"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@SatoshiLite"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@VitalikButerin"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@RaoulGMI"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "Desktop"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "United States"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "21 to 49"
                }
              ],
              "impressionTime" : "2022-02-08 01:24:58"
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adImpressions" : {
          "impressions" : [
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "ProfileAccountsSidebar",
              "advertiserInfo" : {
                "advertiserName" : "Derpy Toshi Coin",
                "screenName" : "@DerpyToshiCoin"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@CheemsInu"
                },
                {
                  "targetingType" : "Gender",
                  "targetingValue" : "Men"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "21 to 49"
                }
              ],
              "impressionTime" : "2022-02-20 22:34:21"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "ProfileAccountsSidebar",
              "advertiserInfo" : {
                "advertiserName" : "Ophir Gottlieb",
                "screenName" : "@OphirGottlieb"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@BusinessInsider"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "21 and up"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "United States"
                }
              ],
              "impressionTime" : "2022-02-20 22:10:18"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "ProfileAccountsSidebar",
              "advertiserInfo" : {
                "advertiserName" : "Derpy Toshi Coin",
                "screenName" : "@DerpyToshiCoin"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@CheemsInu"
                },
                {
                  "targetingType" : "Gender",
                  "targetingValue" : "Men"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "21 to 49"
                }
              ],
              "impressionTime" : "2022-02-20 22:34:21"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "WtfSidebar",
              "advertiserInfo" : {
                "advertiserName" : "Bank of America",
                "screenName" : "@BankofAmerica"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Science news"
                },
                {
                  "targetingType" : "List",
                  "targetingValue" : "EHL_20211213"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "New Jersey"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                }
              ],
              "impressionTime" : "2022-02-20 22:10:18"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "ProfileAccountsSidebar",
              "advertiserInfo" : {
                "advertiserName" : "1inch Network",
                "screenName" : "@1inch"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Financial news"
                },
                {
                  "targetingType" : "Conversation topics"
                },
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "Cryptocurrencies"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@bitfinex"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@cryptomanran"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@BinanceResearch"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@BinanceChain"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@TheBinanceNFT"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@zapper_fi"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@dapp_com"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@CoinMarketCap"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@Poloniex"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@CoinDesk"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@CurveFinance"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@TheCryptoDog"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@TheBlock__"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@trondao"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@0xPolygon"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@Bitboy_Crypto"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@haydenzadams"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@PancakeSwap"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@MMCrypto"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@cz_binance"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@avalancheavax"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@APompliano"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@gate_io"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@0xProject"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@cryptocom"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@okx"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@news_of_bsc"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@crypto_birb"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@coinbase"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@VitalikButerin"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@aantonop"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@MetaMask"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@rogerkver"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@ForbesCrypto"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@BinanceUS"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@krakenfx"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@coingecko"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@opensea"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@BittrexExchange"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@TrustWallet"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@HuobiGlobal"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@Gemini"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@paraswap"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@Bybit_Official"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@myetherwallet"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@dogecoin"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@harmonyprotocol"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@ErikVoorhees"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "United States"
                }
              ],
              "impressionTime" : "2022-02-20 22:09:34"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "WtfSidebar",
              "advertiserInfo" : {
                "advertiserName" : "Bank of America",
                "screenName" : "@BankofAmerica"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Science news"
                },
                {
                  "targetingType" : "List",
                  "targetingValue" : "EHL_20211213"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "New Jersey"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                }
              ],
              "impressionTime" : "2022-02-20 22:09:29"
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adImpressions" : {
          "impressions" : [
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "WtfSidebar",
              "advertiserInfo" : {
                "advertiserName" : "Nodle Cash",
                "screenName" : "@NodleCash"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@AcalaNetwork"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@Polkadot"
                },
                {
                  "targetingType" : "Languages",
                  "targetingValue" : "English"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 to 49"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "United States"
                }
              ],
              "impressionTime" : "2022-01-04 15:54:12"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "WtfSidebar",
              "advertiserInfo" : {
                "advertiserName" : "New To The Street",
                "screenName" : "@NewToTheStreet"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@coinbase"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "United States"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                }
              ],
              "impressionTime" : "2022-01-04 15:54:09"
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adImpressions" : {
          "impressions" : [
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "ProfileAccountsSidebar",
              "advertiserInfo" : {
                "advertiserName" : "Cyphermon",
                "screenName" : "@CyphermonNFT"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@TheBinanceNFT"
                },
                {
                  "targetingType" : "Gender",
                  "targetingValue" : "Men"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "United States"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 to 34"
                }
              ],
              "impressionTime" : "2022-01-04 23:46:12"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "ProfileAccountsSidebar",
              "advertiserInfo" : {
                "advertiserName" : "TheRealHINUtoken",
                "screenName" : "@HinuDev"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "United States"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 to 34"
                },
                {
                  "targetingType" : "Gender",
                  "targetingValue" : "Men"
                }
              ],
              "impressionTime" : "2022-01-04 23:46:13"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "ProfileAccountsSidebar",
              "advertiserInfo" : {
                "advertiserName" : "Cyphermon",
                "screenName" : "@CyphermonNFT"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@TheBinanceNFT"
                },
                {
                  "targetingType" : "Gender",
                  "targetingValue" : "Men"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 to 34"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "United States"
                }
              ],
              "impressionTime" : "2022-01-04 23:58:41"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1478450800477286403",
                "tweetText" : "Streaming, gaming, sports, music, small biz and home internet are going Ultra! See what you missed on the 5G #UltraShow, hosted by Elizabeth Banks. Watch now! 🔥\n\nhttps://t.co/X3p9Tq5XqV",
                "urls" : [
                  "https://t.co/X3p9Tq5XqV"
                ],
                "mediaUrls" : [ ]
              },
              "promotedTrendInfo" : {
                "trendId" : "85030",
                "name" : "#Verizon20220104",
                "description" : ""
              },
              "advertiserInfo" : {
                "advertiserName" : "Verizon",
                "screenName" : "@Verizon"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "United States"
                }
              ],
              "impressionTime" : "2022-01-04 23:58:38"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "WtfSidebar",
              "advertiserInfo" : {
                "advertiserName" : "1inch Network",
                "screenName" : "@1inch"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@bitfinex"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@cryptomanran"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@BinanceResearch"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@BinanceChain"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@TheBinanceNFT"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@dapp_com"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@CoinMarketCap"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@Poloniex"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@CoinDesk"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@CurveFinance"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@TheCryptoDog"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@TheBlock__"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@defipulse"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@0xPolygon"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@haydenzadams"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@PancakeSwap"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@MMCrypto"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@cz_binance"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@avalancheavax"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@gate_io"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@0xProject"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@cryptocom"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@okx"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@crypto_birb"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@coinbase"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@VitalikButerin"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@MetaMask"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@ForbesCrypto"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@BinanceUS"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@krakenfx"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@coingecko"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@opensea"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@BittrexExchange"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@TrustWallet"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@HuobiGlobal"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@Gemini"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@Bybit_Official"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@myetherwallet"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@dogecoin"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@harmonyprotocol"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "United States"
                }
              ],
              "impressionTime" : "2022-01-04 23:46:05"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "WtfSidebar",
              "advertiserInfo" : {
                "advertiserName" : "1inch Network",
                "screenName" : "@1inch"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "Uniswap"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "ethereum"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "crypto"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "#SNX"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "$eth"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "#ethereum"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@bitfinex"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@cryptomanran"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@BinanceResearch"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@BinanceChain"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@TheBinanceNFT"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@dapp_com"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@CoinMarketCap"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@Poloniex"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@CoinDesk"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@CurveFinance"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@TheCryptoDog"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@TheBlock__"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@defipulse"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@0xPolygon"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@haydenzadams"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@PancakeSwap"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@MMCrypto"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@cz_binance"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@avalancheavax"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@gate_io"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@0xProject"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@cryptocom"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@okx"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@crypto_birb"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@coinbase"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@VitalikButerin"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@MetaMask"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@ForbesCrypto"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@BinanceUS"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@krakenfx"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@coingecko"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@opensea"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@BittrexExchange"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@TrustWallet"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@HuobiGlobal"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@Gemini"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@Bybit_Official"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@myetherwallet"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@dogecoin"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@harmonyprotocol"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "United States"
                }
              ],
              "impressionTime" : "2022-01-04 23:58:35"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "ProfileTweets",
              "promotedTweetInfo" : {
                "tweetId" : "1472961939924033543",
                "tweetText" : "Have 7+ years of work experience? You may qualify for a GMAT/GRE waiver. Learn more about the online MBA from Rice Business. https://t.co/owh2Xao3Xv",
                "urls" : [
                  "https://t.co/owh2Xao3Xv"
                ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "MBA@Rice",
                "screenName" : "@MBAatRice"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "business education"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "25 to 54"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Los Angeles CA, US"
                }
              ],
              "impressionTime" : "2022-01-04 23:58:42"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "WtfSidebar",
              "advertiserInfo" : {
                "advertiserName" : "1inch Network",
                "screenName" : "@1inch"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@bitfinex"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@cryptomanran"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@BinanceResearch"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@BinanceChain"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@TheBinanceNFT"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@dapp_com"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@CoinMarketCap"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@Poloniex"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@CoinDesk"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@CurveFinance"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@TheCryptoDog"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@TheBlock__"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@defipulse"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@0xPolygon"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@haydenzadams"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@PancakeSwap"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@MMCrypto"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@cz_binance"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@avalancheavax"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@gate_io"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@0xProject"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@cryptocom"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@okx"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@crypto_birb"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@coinbase"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@VitalikButerin"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@MetaMask"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@ForbesCrypto"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@BinanceUS"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@krakenfx"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@coingecko"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@opensea"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@BittrexExchange"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@TrustWallet"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@HuobiGlobal"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@Gemini"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@Bybit_Official"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@myetherwallet"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@dogecoin"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@harmonyprotocol"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "United States"
                }
              ],
              "impressionTime" : "2022-01-04 23:45:50"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "ProfileAccountsSidebar",
              "advertiserInfo" : {
                "advertiserName" : "1inch Network",
                "screenName" : "@1inch"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@bitfinex"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@cryptomanran"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@BinanceResearch"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@BinanceChain"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@TheBinanceNFT"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@dapp_com"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@CoinMarketCap"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@Poloniex"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@CoinDesk"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@CurveFinance"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@TheCryptoDog"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@TheBlock__"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@defipulse"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@0xPolygon"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@haydenzadams"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@PancakeSwap"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@MMCrypto"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@cz_binance"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@avalancheavax"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@gate_io"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@0xProject"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@cryptocom"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@okx"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@crypto_birb"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@coinbase"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@VitalikButerin"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@MetaMask"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@ForbesCrypto"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@BinanceUS"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@krakenfx"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@coingecko"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@opensea"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@BittrexExchange"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@TrustWallet"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@HuobiGlobal"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@Gemini"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@Bybit_Official"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@myetherwallet"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@dogecoin"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@harmonyprotocol"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "United States"
                }
              ],
              "impressionTime" : "2022-01-04 23:46:05"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "ProfileAccountsSidebar",
              "advertiserInfo" : {
                "advertiserName" : "Nitro Concepts",
                "screenName" : "@Nitro_Concepts"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Online gaming"
                },
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Tech news"
                },
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Technology"
                },
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Comedy"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "United States"
                }
              ],
              "impressionTime" : "2022-01-04 23:46:44"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "ProfileAccountsSidebar",
              "advertiserInfo" : {
                "advertiserName" : "1inch Network",
                "screenName" : "@1inch"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@bitfinex"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@cryptomanran"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@BinanceResearch"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@BinanceChain"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@TheBinanceNFT"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@dapp_com"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@CoinMarketCap"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@Poloniex"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@CoinDesk"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@CurveFinance"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@TheCryptoDog"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@TheBlock__"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@defipulse"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@0xPolygon"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@haydenzadams"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@PancakeSwap"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@MMCrypto"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@cz_binance"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@avalancheavax"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@gate_io"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@0xProject"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@cryptocom"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@okx"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@crypto_birb"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@coinbase"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@VitalikButerin"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@MetaMask"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@ForbesCrypto"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@BinanceUS"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@krakenfx"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@coingecko"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@opensea"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@BittrexExchange"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@TrustWallet"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@HuobiGlobal"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@Gemini"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@Bybit_Official"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@myetherwallet"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@dogecoin"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@harmonyprotocol"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "United States"
                }
              ],
              "impressionTime" : "2022-01-04 23:46:44"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "ProfileAccountsSidebar",
              "advertiserInfo" : {
                "advertiserName" : "Cyphermon",
                "screenName" : "@CyphermonNFT"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@TheBinanceNFT"
                },
                {
                  "targetingType" : "Gender",
                  "targetingValue" : "Men"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "United States"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 to 34"
                }
              ],
              "impressionTime" : "2022-01-04 23:58:41"
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adImpressions" : {
          "impressions" : [
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "WtfSidebar",
              "advertiserInfo" : {
                "advertiserName" : "1inch Network",
                "screenName" : "@1inch"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "Uniswap"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "crypto"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "ethereum"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "#SNX"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "$eth"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "#ethereum"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@bitfinex"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@cryptomanran"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@BinanceResearch"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@BinanceChain"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@TheBinanceNFT"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@dapp_com"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@CoinMarketCap"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@Poloniex"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@CoinDesk"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@CurveFinance"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@TheCryptoDog"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@TheBlock__"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@defipulse"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@0xPolygon"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@haydenzadams"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@PancakeSwap"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@MMCrypto"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@cz_binance"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@avalancheavax"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@gate_io"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@0xProject"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@cryptocom"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@okx"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@crypto_birb"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@coinbase"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@VitalikButerin"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@MetaMask"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@ForbesCrypto"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@BinanceUS"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@krakenfx"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@coingecko"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@opensea"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@BittrexExchange"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@TrustWallet"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@HuobiGlobal"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@Gemini"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@Bybit_Official"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@myetherwallet"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@dogecoin"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@harmonyprotocol"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "United States"
                }
              ],
              "impressionTime" : "2022-01-05 16:04:01"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1473417344013635584",
                "tweetText" : "RT @GoodSamCBS: You've earned your seat — you ARE a leader. Don't miss #GoodSamCBS tonight at 10/9c on @CBS. https://t.co/UXYq0HPqrj",
                "urls" : [ ],
                "mediaUrls" : [
                  "https://t.co/UXYq0HPqrj"
                ]
              },
              "promotedTrendInfo" : {
                "trendId" : "85174",
                "name" : "#CBS20220105",
                "description" : ""
              },
              "advertiserInfo" : {
                "advertiserName" : "CBS",
                "screenName" : "@CBS"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "United States"
                }
              ],
              "impressionTime" : "2022-01-05 16:04:04"
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adImpressions" : {
          "impressions" : [
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "WtfSidebar",
              "advertiserInfo" : {
                "advertiserName" : "IQAir",
                "screenName" : "@IQAir"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@UNEP"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@Greenpeace"
                },
                {
                  "targetingType" : "Languages",
                  "targetingValue" : "English"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "United States"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "Desktop"
                }
              ],
              "impressionTime" : "2022-01-06 14:52:22"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "ProfileAccountsSidebar",
              "advertiserInfo" : {
                "advertiserName" : "1inch Network",
                "screenName" : "@1inch"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "$eth"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "ethereum"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "#SNX"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "crypto"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "Uniswap"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "#ethereum"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@bitfinex"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@cryptomanran"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@BinanceResearch"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@BinanceChain"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@TheBinanceNFT"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@dapp_com"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@CoinMarketCap"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@Poloniex"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@CoinDesk"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@CurveFinance"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@TheCryptoDog"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@TheBlock__"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@defipulse"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@0xPolygon"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@haydenzadams"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@PancakeSwap"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@MMCrypto"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@cz_binance"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@avalancheavax"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@gate_io"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@0xProject"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@cryptocom"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@okx"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@crypto_birb"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@coinbase"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@VitalikButerin"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@MetaMask"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@ForbesCrypto"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@BinanceUS"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@krakenfx"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@coingecko"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@opensea"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@BittrexExchange"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@TrustWallet"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@HuobiGlobal"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@Gemini"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@Bybit_Official"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@myetherwallet"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@dogecoin"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@harmonyprotocol"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "United States"
                }
              ],
              "impressionTime" : "2022-01-06 14:56:51"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "ProfileAccountsSidebar",
              "advertiserInfo" : {
                "advertiserName" : "Cyphermon",
                "screenName" : "@CyphermonNFT"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@TheBinanceNFT"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "United States"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 to 34"
                },
                {
                  "targetingType" : "Gender",
                  "targetingValue" : "Men"
                }
              ],
              "impressionTime" : "2022-01-06 14:53:51"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "WtfSidebar",
              "advertiserInfo" : {
                "advertiserName" : "Michael A. Gayed, CFA",
                "screenName" : "@leadlagreport"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Technology"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@leadlagreport"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@elonmusk"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "United States"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "21 and up"
                }
              ],
              "impressionTime" : "2022-01-06 14:52:24"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "ProfileAccountsSidebar",
              "advertiserInfo" : {
                "advertiserName" : "1inch Network",
                "screenName" : "@1inch"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@bitfinex"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@cryptomanran"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@BinanceResearch"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@BinanceChain"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@TheBinanceNFT"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@dapp_com"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@CoinMarketCap"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@Poloniex"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@CoinDesk"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@CurveFinance"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@TheCryptoDog"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@TheBlock__"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@defipulse"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@0xPolygon"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@haydenzadams"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@PancakeSwap"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@MMCrypto"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@cz_binance"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@avalancheavax"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@gate_io"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@0xProject"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@cryptocom"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@okx"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@crypto_birb"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@coinbase"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@VitalikButerin"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@MetaMask"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@ForbesCrypto"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@BinanceUS"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@krakenfx"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@coingecko"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@opensea"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@BittrexExchange"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@TrustWallet"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@HuobiGlobal"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@Gemini"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@Bybit_Official"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@myetherwallet"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@dogecoin"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@harmonyprotocol"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "ethereum"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "#SNX"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "Uniswap"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "crypto"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "#ethereum"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "$eth"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "United States"
                }
              ],
              "impressionTime" : "2022-01-06 14:56:51"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "WtfSidebar",
              "advertiserInfo" : {
                "advertiserName" : "1inch Network",
                "screenName" : "@1inch"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@bitfinex"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@cryptomanran"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@BinanceResearch"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@BinanceChain"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@TheBinanceNFT"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@dapp_com"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@CoinMarketCap"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@Poloniex"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@CoinDesk"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@CurveFinance"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@TheCryptoDog"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@TheBlock__"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@defipulse"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@0xPolygon"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@haydenzadams"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@PancakeSwap"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@MMCrypto"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@cz_binance"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@avalancheavax"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@gate_io"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@0xProject"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@cryptocom"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@okx"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@crypto_birb"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@coinbase"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@VitalikButerin"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@MetaMask"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@ForbesCrypto"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@BinanceUS"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@krakenfx"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@coingecko"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@opensea"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@BittrexExchange"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@TrustWallet"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@HuobiGlobal"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@Gemini"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@Bybit_Official"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@myetherwallet"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@dogecoin"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@harmonyprotocol"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "Uniswap"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "crypto"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "#SNX"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "ethereum"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "#ethereum"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "$eth"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "United States"
                }
              ],
              "impressionTime" : "2022-01-06 14:56:43"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "WtfSidebar",
              "advertiserInfo" : {
                "advertiserName" : "1inch Network",
                "screenName" : "@1inch"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@bitfinex"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@cryptomanran"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@BinanceResearch"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@BinanceChain"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@TheBinanceNFT"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@dapp_com"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@CoinMarketCap"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@Poloniex"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@CoinDesk"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@CurveFinance"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@TheCryptoDog"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@TheBlock__"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@defipulse"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@0xPolygon"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@haydenzadams"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@PancakeSwap"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@MMCrypto"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@cz_binance"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@avalancheavax"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@gate_io"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@0xProject"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@cryptocom"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@okx"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@crypto_birb"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@coinbase"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@VitalikButerin"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@MetaMask"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@ForbesCrypto"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@BinanceUS"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@krakenfx"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@coingecko"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@opensea"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@BittrexExchange"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@TrustWallet"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@HuobiGlobal"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@Gemini"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@Bybit_Official"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@myetherwallet"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@dogecoin"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@harmonyprotocol"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "ethereum"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "$eth"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "#ethereum"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "Uniswap"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "#SNX"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "crypto"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "United States"
                }
              ],
              "impressionTime" : "2022-01-06 14:53:51"
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adImpressions" : {
          "impressions" : [
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "WtfSidebar",
              "advertiserInfo" : {
                "advertiserName" : "Bank of America",
                "screenName" : "@BankofAmerica"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Science news"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "#health"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "Health"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "#consumer"
                },
                {
                  "targetingType" : "List",
                  "targetingValue" : "EHL_20211213"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Minnesota"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "California"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                }
              ],
              "impressionTime" : "2022-01-06 17:34:39"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "WtfSidebar",
              "advertiserInfo" : {
                "advertiserName" : "1inch Network",
                "screenName" : "@1inch"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "#ethereum"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "$eth"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "ethereum"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "crypto"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "#SNX"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "Uniswap"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@bitfinex"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@cryptomanran"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@BinanceResearch"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@BinanceChain"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@TheBinanceNFT"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@dapp_com"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@CoinMarketCap"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@Poloniex"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@CoinDesk"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@CurveFinance"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@TheCryptoDog"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@TheBlock__"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@defipulse"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@0xPolygon"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@haydenzadams"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@PancakeSwap"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@MMCrypto"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@cz_binance"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@avalancheavax"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@gate_io"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@0xProject"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@cryptocom"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@okx"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@crypto_birb"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@coinbase"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@VitalikButerin"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@MetaMask"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@ForbesCrypto"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@BinanceUS"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@krakenfx"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@coingecko"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@opensea"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@BittrexExchange"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@TrustWallet"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@HuobiGlobal"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@Gemini"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@Bybit_Official"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@myetherwallet"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@dogecoin"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@harmonyprotocol"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "United States"
                }
              ],
              "impressionTime" : "2022-01-06 19:00:25"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1479093665503105026",
                "tweetText" : "A pickup truck with a revolutionary mix of capability, performance and design. Plus, zero tailpipe emissions. #SilveradoEV",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "promotedTrendInfo" : {
                "trendId" : "85166",
                "name" : "#SilveradoEV",
                "description" : "A new standard for pickups"
              },
              "advertiserInfo" : {
                "advertiserName" : "Chevrolet",
                "screenName" : "@chevrolet"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "United States"
                }
              ],
              "impressionTime" : "2022-01-06 19:05:50"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1473404805246857217",
                "tweetText" : "The New Year is here. Don't miss your chance to save: $4 per month.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "The Wall Street Journal",
                "screenName" : "@WSJ"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "this week"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "progress"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "#progress"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "gas prices"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "global warming"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "#education"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "education"
                },
                {
                  "targetingType" : "List"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "Desktop"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "United States"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "21 and up"
                }
              ],
              "impressionTime" : "2022-01-06 23:53:41"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "WtfSidebar",
              "advertiserInfo" : {
                "advertiserName" : "1inch Network",
                "screenName" : "@1inch"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "$eth"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "#ethereum"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "ethereum"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "Uniswap"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "#SNX"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "crypto"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@bitfinex"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@cryptomanran"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@BinanceResearch"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@BinanceChain"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@TheBinanceNFT"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@dapp_com"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@CoinMarketCap"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@Poloniex"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@CoinDesk"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@CurveFinance"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@TheCryptoDog"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@TheBlock__"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@defipulse"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@0xPolygon"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@haydenzadams"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@PancakeSwap"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@MMCrypto"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@cz_binance"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@avalancheavax"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@gate_io"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@0xProject"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@cryptocom"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@okx"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@crypto_birb"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@coinbase"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@VitalikButerin"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@MetaMask"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@ForbesCrypto"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@BinanceUS"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@krakenfx"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@coingecko"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@opensea"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@BittrexExchange"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@TrustWallet"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@HuobiGlobal"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@Gemini"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@Bybit_Official"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@myetherwallet"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@dogecoin"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@harmonyprotocol"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "United States"
                }
              ],
              "impressionTime" : "2022-01-06 23:53:51"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1473404695892963330",
                "tweetText" : "Our New Year Sale starts now. Join for $4 per month.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "The Wall Street Journal",
                "screenName" : "@WSJ"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "gas prices"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "global warming"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "this week"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "education"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "#education"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "#progress"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "progress"
                },
                {
                  "targetingType" : "List"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "United States"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "21 and up"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "Desktop"
                }
              ],
              "impressionTime" : "2022-01-06 23:53:54"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "WtfSidebar",
              "advertiserInfo" : {
                "advertiserName" : "1inch Network",
                "screenName" : "@1inch"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@bitfinex"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@cryptomanran"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@BinanceResearch"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@BinanceChain"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@TheBinanceNFT"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@dapp_com"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@CoinMarketCap"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@Poloniex"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@CoinDesk"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@CurveFinance"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@TheCryptoDog"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@TheBlock__"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@defipulse"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@0xPolygon"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@haydenzadams"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@PancakeSwap"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@MMCrypto"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@cz_binance"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@avalancheavax"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@gate_io"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@0xProject"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@cryptocom"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@okx"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@crypto_birb"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@coinbase"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@VitalikButerin"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@MetaMask"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@ForbesCrypto"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@BinanceUS"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@krakenfx"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@coingecko"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@opensea"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@BittrexExchange"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@TrustWallet"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@HuobiGlobal"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@Gemini"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@Bybit_Official"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@myetherwallet"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@dogecoin"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@harmonyprotocol"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "Uniswap"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "ethereum"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "#SNX"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "crypto"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "#ethereum"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "$eth"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "United States"
                }
              ],
              "impressionTime" : "2022-01-06 23:56:10"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "WtfSidebar",
              "advertiserInfo" : {
                "advertiserName" : "BlackBoxStocks",
                "screenName" : "@BlackBoxStocks"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "finance"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@iearnfinance"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Minnesota"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "California"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "21 and up"
                },
                {
                  "targetingType" : "Languages",
                  "targetingValue" : "English"
                }
              ],
              "impressionTime" : "2022-01-06 23:53:40"
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adImpressions" : {
          "impressions" : [
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "WtfSidebar",
              "advertiserInfo" : {
                "advertiserName" : "1inch Network",
                "screenName" : "@1inch"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@bitfinex"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@cryptomanran"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@BinanceResearch"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@BinanceChain"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@TheBinanceNFT"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@zapper_fi"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@dapp_com"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@CoinMarketCap"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@Poloniex"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@CoinDesk"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@CurveFinance"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@TheCryptoDog"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@TheBlock__"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@defipulse"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@0xPolygon"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@haydenzadams"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@PancakeSwap"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@MMCrypto"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@cz_binance"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@avalancheavax"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@gate_io"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@0xProject"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@cryptocom"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@okx"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@crypto_birb"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@coinbase"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@VitalikButerin"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@MetaMask"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@ForbesCrypto"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@BinanceUS"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@krakenfx"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@coingecko"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@opensea"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@BittrexExchange"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@TrustWallet"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@HuobiGlobal"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@Gemini"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@Bybit_Official"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@dogecoin"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@harmonyprotocol"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "$eth"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "Uniswap"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "#ethereum"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "#SNX"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "ethereum"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "crypto"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "United States"
                }
              ],
              "impressionTime" : "2022-01-07 15:59:31"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "WtfSidebar",
              "advertiserInfo" : {
                "advertiserName" : "1inch Network",
                "screenName" : "@1inch"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@bitfinex"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@cryptomanran"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@BinanceResearch"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@BinanceChain"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@TheBinanceNFT"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@zapper_fi"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@dapp_com"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@CoinMarketCap"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@Poloniex"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@CoinDesk"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@CurveFinance"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@TheCryptoDog"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@TheBlock__"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@defipulse"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@0xPolygon"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@haydenzadams"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@PancakeSwap"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@MMCrypto"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@cz_binance"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@avalancheavax"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@gate_io"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@0xProject"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@cryptocom"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@okx"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@crypto_birb"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@coinbase"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@VitalikButerin"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@MetaMask"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@ForbesCrypto"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@BinanceUS"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@krakenfx"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@coingecko"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@opensea"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@BittrexExchange"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@TrustWallet"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@HuobiGlobal"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@Gemini"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@Bybit_Official"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@dogecoin"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@harmonyprotocol"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "#ethereum"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "Uniswap"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "ethereum"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "#SNX"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "$eth"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "crypto"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "United States"
                }
              ],
              "impressionTime" : "2022-01-07 15:59:31"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1478514180311240710",
                "tweetText" : "Directed by George Clooney and starring Ben Affleck, #TheTenderBar is streaming now on Amazon Prime Video.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "promotedTrendInfo" : {
                "trendId" : "85017",
                "name" : "#PrimeVideo20220107",
                "description" : ""
              },
              "advertiserInfo" : {
                "advertiserName" : "Prime Video",
                "screenName" : "@PrimeVideo"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "United States"
                }
              ],
              "impressionTime" : "2022-01-07 15:59:32"
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adImpressions" : {
          "impressions" : [
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "WtfSidebar",
              "advertiserInfo" : {
                "advertiserName" : "1inch Network",
                "screenName" : "@1inch"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@bitfinex"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@cryptomanran"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@BinanceResearch"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@BinanceChain"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@TheBinanceNFT"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@zapper_fi"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@dapp_com"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@CoinMarketCap"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@Poloniex"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@CoinDesk"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@CurveFinance"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@TheCryptoDog"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@TheBlock__"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@defipulse"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@0xPolygon"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@haydenzadams"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@PancakeSwap"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@MMCrypto"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@cz_binance"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@avalancheavax"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@gate_io"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@0xProject"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@cryptocom"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@okx"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@crypto_birb"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@coinbase"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@VitalikButerin"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@MetaMask"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@ForbesCrypto"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@BinanceUS"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@krakenfx"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@coingecko"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@opensea"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@BittrexExchange"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@TrustWallet"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@HuobiGlobal"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@Gemini"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@Bybit_Official"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@dogecoin"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@harmonyprotocol"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "United States"
                }
              ],
              "impressionTime" : "2022-01-10 02:58:48"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1479271757513117700",
                "tweetText" : "The first #F150Lightning trucks are nearing production and they’re history in the making. #BuiltFordProud #LetThereBeLIGHTNING",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "promotedTrendInfo" : {
                "trendId" : "85216",
                "name" : "#Ford20220109",
                "description" : ""
              },
              "advertiserInfo" : {
                "advertiserName" : "Ford Motor Company",
                "screenName" : "@Ford"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "United States"
                }
              ],
              "impressionTime" : "2022-01-10 02:58:51"
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adImpressions" : {
          "impressions" : [
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "WtfSidebar",
              "advertiserInfo" : {
                "advertiserName" : "1inch Network",
                "screenName" : "@1inch"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Financial news"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@bitfinex"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@cryptomanran"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@BinanceResearch"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@BinanceChain"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@TheBinanceNFT"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@dapp_com"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@CoinMarketCap"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@Poloniex"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@CoinDesk"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@CurveFinance"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@TheCryptoDog"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@TheBlock__"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@defipulse"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@0xPolygon"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@haydenzadams"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@PancakeSwap"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@MMCrypto"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@cz_binance"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@avalancheavax"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@matchaxyz"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@gate_io"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@0xProject"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@cryptocom"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@okx"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@crypto_birb"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@coinbase"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@VitalikButerin"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@MetaMask"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@ForbesCrypto"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@BinanceUS"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@krakenfx"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@coingecko"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@opensea"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@BittrexExchange"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@TrustWallet"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@HuobiGlobal"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@Gemini"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@Bybit_Official"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@myetherwallet"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@dogecoin"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@harmonyprotocol"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "United States"
                }
              ],
              "impressionTime" : "2022-01-24 05:38:28"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "WtfSidebar",
              "advertiserInfo" : {
                "advertiserName" : "1inch Network",
                "screenName" : "@1inch"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@bitfinex"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@cryptomanran"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@BinanceResearch"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@BinanceChain"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@TheBinanceNFT"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@dapp_com"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@CoinMarketCap"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@Poloniex"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@CoinDesk"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@CurveFinance"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@TheCryptoDog"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@TheBlock__"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@defipulse"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@0xPolygon"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@haydenzadams"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@PancakeSwap"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@MMCrypto"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@cz_binance"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@avalancheavax"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@matchaxyz"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@gate_io"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@0xProject"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@cryptocom"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@okx"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@crypto_birb"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@coinbase"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@VitalikButerin"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@MetaMask"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@ForbesCrypto"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@BinanceUS"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@krakenfx"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@coingecko"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@opensea"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@BittrexExchange"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@TrustWallet"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@HuobiGlobal"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@Gemini"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@Bybit_Official"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@myetherwallet"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@dogecoin"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@harmonyprotocol"
                },
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Financial news"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "United States"
                }
              ],
              "impressionTime" : "2022-01-24 05:38:32"
            }
          ]
        }
      }
    }
  }
]