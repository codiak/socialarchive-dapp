window.YTD.personalization.part0 = [
  {
    "p13nData" : {
      "demographics" : {
        "languages" : [
          {
            "language" : "English",
            "isDisabled" : false
          }
        ],
        "genderInfo" : {
          "gender" : "male"
        }
      },
      "interests" : {
        "interests" : [
          {
            "name" : "Action sports",
            "isDisabled" : false
          },
          {
            "name" : "Animation",
            "isDisabled" : false
          },
          {
            "name" : "Comedy",
            "isDisabled" : false
          },
          {
            "name" : "Comedy",
            "isDisabled" : false
          },
          {
            "name" : "Computer gaming",
            "isDisabled" : false
          },
          {
            "name" : "Console gaming",
            "isDisabled" : false
          },
          {
            "name" : "Cryptocurrencies",
            "isDisabled" : false
          },
          {
            "name" : "Databases",
            "isDisabled" : false
          },
          {
            "name" : "Dogs",
            "isDisabled" : false
          },
          {
            "name" : "Ethereum cryptocurrency",
            "isDisabled" : false
          },
          {
            "name" : "Facebook",
            "isDisabled" : false
          },
          {
            "name" : "Financial news",
            "isDisabled" : false
          },
          {
            "name" : "Gaming",
            "isDisabled" : false
          },
          {
            "name" : "Gaming news and general info",
            "isDisabled" : false
          },
          {
            "name" : "Google",
            "isDisabled" : false
          },
          {
            "name" : "Google Innovation",
            "isDisabled" : false
          },
          {
            "name" : "Google brand conversation",
            "isDisabled" : false
          },
          {
            "name" : "Government",
            "isDisabled" : false
          },
          {
            "name" : "Hip hop",
            "isDisabled" : false
          },
          {
            "name" : "Industries",
            "isDisabled" : false
          },
          {
            "name" : "Jack Harlow",
            "isDisabled" : false
          },
          {
            "name" : "Leadership",
            "isDisabled" : false
          },
          {
            "name" : "Meta",
            "isDisabled" : false
          },
          {
            "name" : "Music",
            "isDisabled" : false
          },
          {
            "name" : "Music festivals and concerts",
            "isDisabled" : false
          },
          {
            "name" : "Oculus",
            "isDisabled" : false
          },
          {
            "name" : "Online gaming",
            "isDisabled" : false
          },
          {
            "name" : "Politics",
            "isDisabled" : false
          },
          {
            "name" : "Rap",
            "isDisabled" : false
          },
          {
            "name" : "Retail",
            "isDisabled" : false
          },
          {
            "name" : "Science news",
            "isDisabled" : false
          },
          {
            "name" : "Social media",
            "isDisabled" : false
          },
          {
            "name" : "Space and astronomy",
            "isDisabled" : false
          },
          {
            "name" : "Sporting events",
            "isDisabled" : false
          },
          {
            "name" : "Sporting goods",
            "isDisabled" : false
          },
          {
            "name" : "Sports news",
            "isDisabled" : false
          },
          {
            "name" : "Sports themed",
            "isDisabled" : false
          },
          {
            "name" : "Superstores",
            "isDisabled" : false
          },
          {
            "name" : "Tech news",
            "isDisabled" : false
          },
          {
            "name" : "Technology",
            "isDisabled" : false
          },
          {
            "name" : "Technology",
            "isDisabled" : false
          },
          {
            "name" : "Twitter",
            "isDisabled" : false
          },
          {
            "name" : "U.S. military",
            "isDisabled" : false
          },
          {
            "name" : "Virtual reality",
            "isDisabled" : false
          },
          {
            "name" : "Walmart",
            "isDisabled" : false
          },
          {
            "name" : "Weather",
            "isDisabled" : false
          },
          {
            "name" : "Web3",
            "isDisabled" : false
          }
        ],
        "partnerInterests" : [ ],
        "audienceAndAdvertisers" : {
          "numAudiences" : "67",
          "advertisers" : [
            "@AlgoFoundation",
            "@CallofDuty",
            "@DAMch_Official",
            "@GQMagazine",
            "@HBO",
            "@NielsenTest1",
            "@PanasonicUK",
            "@TheEconomist",
            "@VanityFair",
            "@WIRED",
            "@WIREDInsider",
            "@adidas",
            "@arstechnica",
            "@cheddar",
            "@fabriik_market",
            "@fold_app",
            "@hbomax",
            "@optimum",
            "@peacockTV",
            "@pedialyte",
            "@peetscoffee",
            "@pitchfork",
            "@test_sdb1"
          ],
          "lookalikeAdvertisers" : [
            "@HBOMaxBR",
            "@LinkedIn",
            "@Uber",
            "@tinderbrasil",
            "@Airbnb",
            "@Airbnb_uk",
            "@AlgoFoundation",
            "@BusinessInsider",
            "@CallofDuty",
            "@DAMch_Official",
            "@EurosportCentr1",
            "@GQMagazine",
            "@Gemini",
            "@HBO",
            "@LogRocket",
            "@MountainDew",
            "@NielsenTest1",
            "@NintendoAmerica",
            "@PanasonicUK",
            "@PayPalUK",
            "@SSLsCom",
            "@Spotify_PH",
            "@T2InteractiveUS",
            "@VanityFair",
            "@VelaEdFund",
            "@WIRED",
            "@WIREDInsider",
            "@adidas",
            "@airbnb_fr",
            "@arstechnica",
            "@business",
            "@cheddar",
            "@digitalocean",
            "@fabriik_market",
            "@fiverr",
            "@fold_app",
            "@gitcoin",
            "@hbomax",
            "@intel",
            "@kitehq",
            "@mountaincreek",
            "@optimum",
            "@peacockTV",
            "@pedialyte",
            "@peetscoffee",
            "@pitchfork",
            "@test_sdb1"
          ],
          "doNotReachAdvertisers" : [ ]
        },
        "shows" : [ ]
      },
      "locationHistory" : [
        "West New York, NJ, USA",
        "LOS ANGELES, USA"
      ],
      "inferredAgeInfo" : {
        "age" : [
          "13-54"
        ],
        "birthDate" : ""
      }
    }
  }
]