window.YTD.block.part0 = [
  {
    "blocking" : {
      "accountId" : "3072359823",
      "userLink" : "https://twitter.com/intent/user?user_id=3072359823"
    }
  }
]