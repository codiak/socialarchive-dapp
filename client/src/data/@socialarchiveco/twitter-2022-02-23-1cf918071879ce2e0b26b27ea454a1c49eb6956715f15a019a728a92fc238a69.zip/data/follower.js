window.YTD.follower.part0 = [
  {
    "follower" : {
      "accountId" : "43527072",
      "userLink" : "https://twitter.com/intent/user?user_id=43527072"
    }
  },
  {
    "follower" : {
      "accountId" : "14321476",
      "userLink" : "https://twitter.com/intent/user?user_id=14321476"
    }
  },
  {
    "follower" : {
      "accountId" : "17703833",
      "userLink" : "https://twitter.com/intent/user?user_id=17703833"
    }
  }
]