window.YTD.following.part0 = [
  {
    "following" : {
      "accountId" : "17703833",
      "userLink" : "https://twitter.com/intent/user?user_id=17703833"
    }
  },
  {
    "following" : {
      "accountId" : "2312333412",
      "userLink" : "https://twitter.com/intent/user?user_id=2312333412"
    }
  },
  {
    "following" : {
      "accountId" : "1324574383806009345",
      "userLink" : "https://twitter.com/intent/user?user_id=1324574383806009345"
    }
  },
  {
    "following" : {
      "accountId" : "1385231003745234944",
      "userLink" : "https://twitter.com/intent/user?user_id=1385231003745234944"
    }
  },
  {
    "following" : {
      "accountId" : "879945922540646400",
      "userLink" : "https://twitter.com/intent/user?user_id=879945922540646400"
    }
  },
  {
    "following" : {
      "accountId" : "1021693481906003968",
      "userLink" : "https://twitter.com/intent/user?user_id=1021693481906003968"
    }
  }
]