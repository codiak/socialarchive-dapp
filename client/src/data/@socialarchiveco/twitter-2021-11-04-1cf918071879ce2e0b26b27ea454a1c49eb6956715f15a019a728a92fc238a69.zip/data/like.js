window.YTD.like.part0 = [
  {
    "like" : {
      "tweetId" : "1451676767391989765",
      "fullText" : "@SocialArchiveCo https://t.co/8o8L9ARpe2",
      "expandedUrl" : "https://twitter.com/i/web/status/1451676767391989765"
    }
  }
]