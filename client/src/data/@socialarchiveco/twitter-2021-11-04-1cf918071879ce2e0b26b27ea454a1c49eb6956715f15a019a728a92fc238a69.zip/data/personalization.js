window.YTD.personalization.part0 = [
  {
    "p13nData" : {
      "demographics" : {
        "languages" : [
          {
            "language" : "English",
            "isDisabled" : false
          }
        ],
        "genderInfo" : {
          "gender" : ""
        }
      },
      "interests" : {
        "interests" : [
          {
            "name" : "Celebrity fan and gossip",
            "isDisabled" : false
          },
          {
            "name" : "Comedy",
            "isDisabled" : false
          },
          {
            "name" : "Comedy",
            "isDisabled" : false
          },
          {
            "name" : "Dogs",
            "isDisabled" : false
          },
          {
            "name" : "Music festivals and concerts",
            "isDisabled" : false
          },
          {
            "name" : "Science news",
            "isDisabled" : false
          },
          {
            "name" : "Social media",
            "isDisabled" : false
          },
          {
            "name" : "Space and astronomy",
            "isDisabled" : false
          },
          {
            "name" : "Sporting events",
            "isDisabled" : false
          },
          {
            "name" : "Sports news",
            "isDisabled" : false
          },
          {
            "name" : "Technology",
            "isDisabled" : false
          },
          {
            "name" : "Twitter",
            "isDisabled" : false
          },
          {
            "name" : "Weather",
            "isDisabled" : false
          }
        ],
        "partnerInterests" : [ ],
        "audienceAndAdvertisers" : {
          "numAudiences" : "42",
          "advertisers" : [
            "@25Days",
            "@CallofDuty",
            "@HBO",
            "@adidas",
            "@fold_app",
            "@hbomax",
            "@peacockTV"
          ],
          "lookalikeAdvertisers" : [
            "@25Days",
            "@CallofDuty",
            "@HBO",
            "@adidas",
            "@fold_app",
            "@hbomax",
            "@peacockTV"
          ]
        },
        "shows" : [ ]
      },
      "locationHistory" : [
        "LOS ANGELES, USA"
      ],
      "inferredAgeInfo" : {
        "age" : [
          "13-54"
        ],
        "birthDate" : ""
      }
    }
  }
]