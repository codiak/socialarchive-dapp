window.YTD.verified.part0 = [
  {
    "verified" : {
      "accountId" : "43527072",
      "verified" : false
    }
  }
]