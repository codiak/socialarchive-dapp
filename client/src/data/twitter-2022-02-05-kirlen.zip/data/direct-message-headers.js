window.YTD.direct_message_headers.part0 = [
  {
    "dmConversation" : {
      "conversationId" : "17478565-43527072",
      "messages" : [
        {
          "messageCreate" : {
            "id" : "730757396084211716",
            "senderId" : "43527072",
            "recipientId" : "17478565",
            "createdAt" : "2016-05-12T13:51:54.790Z"
          }
        },
        {
          "messageCreate" : {
            "id" : "712651548220755971",
            "senderId" : "17478565",
            "recipientId" : "43527072",
            "createdAt" : "2016-03-23T14:45:44.216Z"
          }
        },
        {
          "messageCreate" : {
            "id" : "712632898915078147",
            "senderId" : "43527072",
            "recipientId" : "17478565",
            "createdAt" : "2016-03-23T13:31:37.917Z"
          }
        }
      ]
    }
  },
  {
    "dmConversation" : {
      "conversationId" : "26436246-43527072",
      "messages" : [
        {
          "messageCreate" : {
            "id" : "382600779019714561",
            "senderId" : "43527072",
            "recipientId" : "26436246",
            "createdAt" : "2013-09-24T20:21:48.000Z"
          }
        },
        {
          "messageCreate" : {
            "id" : "382528022005284864",
            "senderId" : "26436246",
            "recipientId" : "43527072",
            "createdAt" : "2013-09-24T15:32:42.000Z"
          }
        }
      ]
    }
  },
  {
    "dmConversation" : {
      "conversationId" : "43525546-43527072",
      "messages" : [
        {
          "messageCreate" : {
            "id" : "447710701",
            "senderId" : "43525546",
            "recipientId" : "43527072",
            "createdAt" : "2009-10-11T14:07:19.000Z"
          }
        },
        {
          "messageCreate" : {
            "id" : "446239421",
            "senderId" : "43527072",
            "recipientId" : "43525546",
            "createdAt" : "2009-10-10T23:29:43.000Z"
          }
        },
        {
          "messageCreate" : {
            "id" : "445991910",
            "senderId" : "43525546",
            "recipientId" : "43527072",
            "createdAt" : "2009-10-10T21:20:39.000Z"
          }
        }
      ]
    }
  },
  {
    "dmConversation" : {
      "conversationId" : "43527072-137554801",
      "messages" : [
        {
          "messageCreate" : {
            "id" : "795313065587838979",
            "senderId" : "137554801",
            "recipientId" : "43527072",
            "createdAt" : "2016-11-06T17:13:05.772Z"
          }
        }
      ]
    }
  },
  {
    "dmConversation" : {
      "conversationId" : "43527072-278388728",
      "messages" : [
        {
          "messageCreate" : {
            "id" : "520324846937321472",
            "senderId" : "43527072",
            "recipientId" : "278388728",
            "createdAt" : "2014-10-09T21:28:05.390Z"
          }
        }
      ]
    }
  },
  {
    "dmConversation" : {
      "conversationId" : "43527072-1890964813",
      "messages" : [
        {
          "messageCreate" : {
            "id" : "892814341686341638",
            "senderId" : "1890964813",
            "recipientId" : "43527072",
            "createdAt" : "2017-08-02T18:28:21.565Z"
          }
        },
        {
          "messageCreate" : {
            "id" : "874990694204657667",
            "senderId" : "43527072",
            "recipientId" : "1890964813",
            "createdAt" : "2017-06-14T14:03:32.839Z"
          }
        }
      ]
    }
  },
  {
    "dmConversation" : {
      "conversationId" : "43527072-2442257604",
      "messages" : [
        {
          "messageCreate" : {
            "id" : "885900916158844932",
            "senderId" : "2442257604",
            "recipientId" : "43527072",
            "createdAt" : "2017-07-14T16:36:52.433Z"
          }
        }
      ]
    }
  },
  {
    "dmConversation" : {
      "conversationId" : "43527072-4301063243",
      "messages" : [
        {
          "messageCreate" : {
            "id" : "1468255254101770248",
            "senderId" : "4301063243",
            "recipientId" : "43527072",
            "createdAt" : "2021-12-07T16:25:06.124Z"
          }
        },
        {
          "messageCreate" : {
            "id" : "1468255179111866377",
            "senderId" : "43527072",
            "recipientId" : "4301063243",
            "createdAt" : "2021-12-07T16:24:48.280Z"
          }
        },
        {
          "messageCreate" : {
            "id" : "1468255028192362501",
            "senderId" : "43527072",
            "recipientId" : "4301063243",
            "createdAt" : "2021-12-07T16:24:12.262Z"
          }
        },
        {
          "messageCreate" : {
            "id" : "1468246085776859158",
            "senderId" : "4301063243",
            "recipientId" : "43527072",
            "createdAt" : "2021-12-07T15:48:40.288Z"
          }
        },
        {
          "messageCreate" : {
            "id" : "1468245980537667588",
            "senderId" : "4301063243",
            "recipientId" : "43527072",
            "createdAt" : "2021-12-07T15:48:15.176Z"
          }
        },
        {
          "messageCreate" : {
            "id" : "1468136553159569415",
            "senderId" : "43527072",
            "recipientId" : "4301063243",
            "createdAt" : "2021-12-07T08:33:25.612Z"
          }
        }
      ]
    }
  }
]