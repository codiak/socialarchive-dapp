window.YTD.ni_devices.part0 = [
  {
    "niDeviceResponse" : {
      "pushDevice" : {
        "deviceVersion" : "8.98.1",
        "udid" : "8B3991A7-1022-47F4-8516-535ABCA58819",
        "deviceType" : "Twitter for iOS",
        "token" : "MUBn5gIjxbQY5JHkMIALlwa2opjLwoHtlY0/K/oV6Ic=",
        "updatedDate" : "2022.02.05",
        "createdDate" : "2019.10.29"
      }
    }
  },
  {
    "niDeviceResponse" : {
      "messagingDevice" : {
        "phoneNumber" : "+16198653311",
        "carrier" : "t_mobile_us",
        "deviceType" : "Full",
        "updatedDate" : "2019.06.26",
        "createdDate" : "2017.06.19"
      }
    }
  }
]