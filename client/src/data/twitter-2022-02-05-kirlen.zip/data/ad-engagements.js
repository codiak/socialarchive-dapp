window.YTD.ad_engagements.part0 = [
  {
    "ad" : {
      "adsUserData" : {
        "adEngagements" : {
          "engagements" : [
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios",
                  "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo="
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "83585",
                  "name" : "#SMT5",
                  "description" : "Godhood Awaits. Shin Megami Tensei V is Now Available."
                },
                "advertiserInfo" : {
                  "advertiserName" : "Official ATLUS West",
                  "screenName" : "@Atlus_West"
                },
                "impressionTime" : "2021-11-15 15:43:01"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2021-11-15 15:43:10",
                  "engagementType" : "TrendView"
                }
              ]
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adEngagements" : {
          "engagements" : [
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios",
                  "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1471943028679987200",
                  "tweetText" : "If you're a frequent flyer then this app will save you hundreds of dollars 💸",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Hopper",
                  "screenName" : "@hopper"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Platforms",
                    "targetingValue" : "iOS"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "18 and up"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "United States"
                  }
                ],
                "impressionTime" : "2022-01-08 14:25:10"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-01-09 09:08:12",
                  "engagementType" : "VideoContentPlaybackStart"
                },
                {
                  "engagementTime" : "2022-01-09 09:08:13",
                  "engagementType" : "VideoContent1secView"
                },
                {
                  "engagementTime" : "2022-01-09 09:08:27",
                  "engagementType" : "VideoSession"
                },
                {
                  "engagementTime" : "2022-01-09 09:08:11",
                  "engagementType" : "ChargeableImpression"
                },
                {
                  "engagementTime" : "2022-01-09 09:08:14",
                  "engagementType" : "VideoContentMrcView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios",
                  "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1471593020415885312",
                  "tweetText" : "Mine, Plan, Fight - Everyday a new adventure, everyday a new challenge\n\nDownload Star Trek Fleet Command today.",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Star Trek Fleet Command",
                  "screenName" : "@StarTrekFleet"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Follower look-alikes",
                    "targetingValue" : "@wilw"
                  },
                  {
                    "targetingType" : "Follower look-alikes",
                    "targetingValue" : "@GeorgeTakei"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "18 and up"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "United States"
                  },
                  {
                    "targetingType" : "OS versions",
                    "targetingValue" : "iOS 14.5 and above"
                  },
                  {
                    "targetingType" : "Platforms",
                    "targetingValue" : "iOS"
                  },
                  {
                    "targetingType" : "Gender",
                    "targetingValue" : "Men"
                  }
                ],
                "impressionTime" : "2022-01-08 14:25:10"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-01-09 09:05:47",
                  "engagementType" : "VideoContentPlaybackStart"
                },
                {
                  "engagementTime" : "2022-01-09 09:06:55",
                  "engagementType" : "VideoSession"
                },
                {
                  "engagementTime" : "2022-01-09 09:05:49",
                  "engagementType" : "VideoContent1secView"
                },
                {
                  "engagementTime" : "2022-01-09 09:05:49",
                  "engagementType" : "VideoContentMrcView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios",
                  "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1384488131223687175",
                  "tweetText" : "📣📣📣#DOGECOIN IS HERE!\n\nTrade popular cryptos at a $1 minimum.\n\nTrade #cryptos 24/7, all year long.",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Webull",
                  "screenName" : "@WebullGlobal"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "#Stock"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "#Crypto"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "Digital"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "#Cryptocurrencies"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "#CryptoCurrency"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "#Digital"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "Cryptocurrencies"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "Stock"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "Cryptocurrency"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "Crypto"
                  },
                  {
                    "targetingType" : "Conversation topics",
                    "targetingValue" : "Cryptocurrencies"
                  },
                  {
                    "targetingType" : "App Activity",
                    "targetingValue" : "Install Webull: Investing & Trading IOS All"
                  },
                  {
                    "targetingType" : "Platforms",
                    "targetingValue" : "iOS"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "United States"
                  }
                ],
                "impressionTime" : "2022-01-08 14:25:10"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-01-09 09:07:54",
                  "engagementType" : "VideoContentPlaybackStart"
                },
                {
                  "engagementTime" : "2022-01-09 09:08:27",
                  "engagementType" : "VideoSession"
                }
              ]
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adEngagements" : {
          "engagements" : [
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios",
                  "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo="
                },
                "displayLocation" : "ProfileTweets",
                "promotedTweetInfo" : {
                  "tweetId" : "1463705626027376642",
                  "tweetText" : "Margin Trading is now live on the https://t.co/vCNztATSCO Exchange App 🚀\n \n🔄 100+ leveraged pairs inc. $SOL, $LUNA &amp; $DOT\n📈 Amplify positions with up to 10x leverage\n📉 Stake CRO for even lower interest rates\n\nTrade Now!",
                  "urls" : [
                    "https://t.co/vCNztATSCO"
                  ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Crypto.com",
                  "screenName" : "@cryptocom"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Interests",
                    "targetingValue" : "Financial news"
                  },
                  {
                    "targetingType" : "Conversation topics",
                    "targetingValue" : "Business & finance"
                  },
                  {
                    "targetingType" : "Conversation topics",
                    "targetingValue" : "Cryptocurrencies"
                  },
                  {
                    "targetingType" : "Conversation topics",
                    "targetingValue" : "Personal finance"
                  },
                  {
                    "targetingType" : "Conversation topics",
                    "targetingValue" : "Ethereum cryptocurrency"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "tezos"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "cryptocurrencies"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "#crypto"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "cryptocurrency"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "eth"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "investing"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "#invest"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "crypto"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "#investing"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "#cryptocurrency"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "financial"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "finance"
                  },
                  {
                    "targetingType" : "Follower look-alikes",
                    "targetingValue" : "@elonmusk"
                  },
                  {
                    "targetingType" : "App Activity",
                    "targetingValue" : "Install Crypto.com Exchange ANDROID All"
                  },
                  {
                    "targetingType" : "Website Activity",
                    "targetingValue" : "Exchange Site Signup"
                  },
                  {
                    "targetingType" : "App Activity",
                    "targetingValue" : "Install Crypto.com Exchange IOS All"
                  },
                  {
                    "targetingType" : "Languages",
                    "targetingValue" : "English"
                  },
                  {
                    "targetingType" : "Platforms",
                    "targetingValue" : "iOS"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Poland"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "18 and up"
                  }
                ],
                "impressionTime" : "2022-01-10 08:27:53"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-01-10 08:28:43",
                  "engagementType" : "VideoContentShortFormComplete"
                },
                {
                  "engagementTime" : "2022-01-10 08:28:04",
                  "engagementType" : "VideoContentMrcView"
                },
                {
                  "engagementTime" : "2022-01-10 08:28:04",
                  "engagementType" : "VideoContentPlayback25"
                },
                {
                  "engagementTime" : "2022-01-10 08:28:41",
                  "engagementType" : "VideoContentPlayback95"
                },
                {
                  "engagementTime" : "2022-01-10 08:29:10",
                  "engagementType" : "VideoSession"
                },
                {
                  "engagementTime" : "2022-01-10 08:28:07",
                  "engagementType" : "VideoContent6secView"
                },
                {
                  "engagementTime" : "2022-01-10 08:28:43",
                  "engagementType" : "VideoContentPlaybackComplete"
                },
                {
                  "engagementTime" : "2022-01-10 08:28:25",
                  "engagementType" : "VideoContentPlayback75"
                },
                {
                  "engagementTime" : "2022-01-10 08:27:58",
                  "engagementType" : "VideoContentPlaybackStart"
                },
                {
                  "engagementTime" : "2022-01-10 08:28:07",
                  "engagementType" : "VideoContentPlayback50"
                }
              ]
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adEngagements" : {
          "engagements" : [
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1487121711749382145",
                  "tweetText" : "Applications are now open for Artists, Businesspersons, Collectors and Developers. https://t.co/blHOztiW1I\n\nA - Artist, Photo, Music, Visual, Digital...\nB - Web3 Founder, Marketer, CM, SMM...\nC - Collectors, Gamers...\nD - Solidity, React, Vue, Python, Web3, Web2... https://t.co/NPtKI2JYiO",
                  "urls" : [
                    "https://t.co/blHOztiW1I"
                  ],
                  "mediaUrls" : [
                    "https://t.co/NPtKI2JYiO"
                  ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "MHOUSE",
                  "screenName" : "@mhousedotclub"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "nft art"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "artist"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "web3"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "nft"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "nft artist"
                  },
                  {
                    "targetingType" : "Languages",
                    "targetingValue" : "English"
                  }
                ],
                "impressionTime" : "2022-01-29 15:50:47"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-01-29 15:50:49",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            }
          ]
        }
      }
    }
  }
]