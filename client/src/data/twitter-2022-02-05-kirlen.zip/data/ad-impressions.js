window.YTD.ad_impressions.part0 = [
  {
    "ad" : {
      "adsUserData" : {
        "adImpressions" : {
          "impressions" : [
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone XS"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1336878011287629824",
                "tweetText" : "Up to 2% back on spending. Reserve yours in Ruby Steel today. Download app now and Reserve your Metal Card.\n#CRO",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Crypto.com",
                "screenName" : "@cryptocom"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@StellarOrg"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@CNBC"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@BusinessInsider"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@business"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@FastCompany"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "#nfts"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "#nft"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Install Crypto.com - Buy Bitcoin,Ether IOS All"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "United States"
                }
              ],
              "impressionTime" : "2021-12-07 08:40:54"
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adImpressions" : {
          "impressions" : [
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone XS"
              },
              "displayLocation" : "ProfileTweets",
              "promotedTweetInfo" : {
                "tweetId" : "1471862051794522115",
                "tweetText" : "🙌 Just imagine a DeFi project that allows you not to pay gas fees for swaps at all.\n\n✨ Sounds fantastic, doesn't it?\n\nFollow us for more ⤵️",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "1inch Network",
                "screenName" : "@1inch"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "#UNI"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "United States"
                }
              ],
              "impressionTime" : "2022-01-04 18:09:24"
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adImpressions" : {
          "impressions" : [
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "ProfileAccountsSidebar",
              "advertiserInfo" : {
                "advertiserName" : "Mans Robots",
                "screenName" : "@MansRobots"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Latvia"
                }
              ],
              "impressionTime" : "2022-01-21 15:36:06"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1481071380795826176",
                "tweetText" : "What’s on my holiday reading list? Robots, Shakespeare, and more. For more book recommendations and giveaways, sign up to become a Gates Notes Insider.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Bill Gates",
                "screenName" : "@BillGates"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@RedCross"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@CARE"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@UNICEF"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@UNDP"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@WHO"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@SavetheChildren"
                },
                {
                  "targetingType" : "Website Activity",
                  "targetingValue" : "Sign up (Completion) "
                },
                {
                  "targetingType" : "List",
                  "targetingValue" : "All insiders last 12 mos"
                },
                {
                  "targetingType" : "Website Activity",
                  "targetingValue" : "Site Visit Retargeting Audience"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Latvia"
                },
                {
                  "targetingType" : "Languages",
                  "targetingValue" : "English"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                }
              ],
              "impressionTime" : "2022-01-21 15:35:31"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "WtfSidebar",
              "advertiserInfo" : {
                "advertiserName" : "Mans Robots",
                "screenName" : "@MansRobots"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Latvia"
                }
              ],
              "impressionTime" : "2022-01-21 15:35:29"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "ProfileAccountsSidebar",
              "advertiserInfo" : {
                "advertiserName" : "Mans Robots",
                "screenName" : "@MansRobots"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Latvia"
                }
              ],
              "impressionTime" : "2022-01-21 15:52:10"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1425868138567012352",
                "tweetText" : "No time to learn a new language? \nBrowse Twitter with Toucan ⚡",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Taylor Nieman",
                "screenName" : "@Taylor_Nieman"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Languages",
                  "targetingValue" : "English"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "Desktop"
                }
              ],
              "impressionTime" : "2022-01-21 15:35:37"
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adImpressions" : {
          "impressions" : [
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "ProfileAccountsSidebar",
              "advertiserInfo" : {
                "advertiserName" : "Mans Robots",
                "screenName" : "@MansRobots"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Latvia"
                }
              ],
              "impressionTime" : "2022-01-29 15:50:37"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "WtfSidebar",
              "advertiserInfo" : {
                "advertiserName" : "Mans Robots",
                "screenName" : "@MansRobots"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Latvia"
                }
              ],
              "impressionTime" : "2022-01-29 15:41:46"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1481423956934467586",
                "tweetText" : "Learn a language while you browse your favorite websites.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Taylor Nieman",
                "screenName" : "@Taylor_Nieman"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Languages",
                  "targetingValue" : "English"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "Desktop"
                }
              ],
              "impressionTime" : "2022-01-29 15:41:48"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "ProfileAccountsSidebar",
              "advertiserInfo" : {
                "advertiserName" : "Mans Robots",
                "screenName" : "@MansRobots"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Latvia"
                }
              ],
              "impressionTime" : "2022-01-29 15:49:36"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "WtfSidebar",
              "advertiserInfo" : {
                "advertiserName" : "Mans Robots",
                "screenName" : "@MansRobots"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Latvia"
                }
              ],
              "impressionTime" : "2022-01-29 15:50:37"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1487121711749382145",
                "tweetText" : "Applications are now open for Artists, Businesspersons, Collectors and Developers. https://t.co/blHOztiW1I\n\nA - Artist, Photo, Music, Visual, Digital...\nB - Web3 Founder, Marketer, CM, SMM...\nC - Collectors, Gamers...\nD - Solidity, React, Vue, Python, Web3, Web2... https://t.co/NPtKI2JYiO",
                "urls" : [
                  "https://t.co/blHOztiW1I"
                ],
                "mediaUrls" : [
                  "https://t.co/NPtKI2JYiO"
                ]
              },
              "advertiserInfo" : {
                "advertiserName" : "MHOUSE",
                "screenName" : "@mhousedotclub"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "nft art"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "artist"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "web3"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "nft"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "nft artist"
                },
                {
                  "targetingType" : "Languages",
                  "targetingValue" : "English"
                }
              ],
              "impressionTime" : "2022-01-29 15:50:49"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "WtfSidebar",
              "advertiserInfo" : {
                "advertiserName" : "Mans Robots",
                "screenName" : "@MansRobots"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Latvia"
                }
              ],
              "impressionTime" : "2022-01-29 15:50:48"
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adImpressions" : {
          "impressions" : [
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "WtfSidebar",
              "advertiserInfo" : {
                "advertiserName" : "Huawei",
                "screenName" : "@Huawei"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Sports news"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@BBCNews"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@amazon"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@Meta"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@cnnbrk"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@Oracle"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@Tesla"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@cnni"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@Microsoft"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@Google"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@YouTube"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@BBCWorld"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@Apple"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@Windows"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@CNNBusiness"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@WSJ"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@CNN"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@intel"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@BBCBreaking"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@CNNPolitics"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "innovations"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "education"
                },
                {
                  "targetingType" : "List",
                  "targetingValue" : "Exclude audience list"
                },
                {
                  "targetingType" : "List",
                  "targetingValue" : "Exclude audience list20210118"
                },
                {
                  "targetingType" : "List",
                  "targetingValue" : "Exclude audience list20210218"
                }
              ],
              "impressionTime" : "2022-01-31 12:58:14"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "ProfileAccountsSidebar",
              "advertiserInfo" : {
                "advertiserName" : "Mans Robots",
                "screenName" : "@MansRobots"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Latvia"
                }
              ],
              "impressionTime" : "2022-01-31 12:58:15"
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adImpressions" : {
          "impressions" : [
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "WtfSidebar",
              "advertiserInfo" : {
                "advertiserName" : "letmespeak.org",
                "screenName" : "@Letmespeak_org"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "crypto"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "blockchain"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "nft"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "ethereum"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "nfts"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Latvia"
                },
                {
                  "targetingType" : "Languages",
                  "targetingValue" : "English"
                }
              ],
              "impressionTime" : "2022-02-01 10:52:33"
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adImpressions" : {
          "impressions" : [
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1481427781674176513",
                "tweetText" : "Can’t afford to learn a new language? You can with Toucan.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Taylor Nieman",
                "screenName" : "@Taylor_Nieman"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "Desktop"
                },
                {
                  "targetingType" : "Languages",
                  "targetingValue" : "English"
                }
              ],
              "impressionTime" : "2022-02-01 13:35:38"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "WtfSidebar",
              "advertiserInfo" : {
                "advertiserName" : "1inch Network",
                "screenName" : "@1inch"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@bhorowitz"
                },
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "Ethereum cryptocurrency"
                },
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Financial news"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "web3"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "BSC"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "#ethereum"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "crypto"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "ethereum"
                },
                {
                  "targetingType" : "Languages",
                  "targetingValue" : "English"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Latvia"
                }
              ],
              "impressionTime" : "2022-02-01 13:35:45"
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adImpressions" : {
          "impressions" : [
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1481432180765065219",
                "tweetText" : "Can’t afford to learn a new language? You can with Toucan.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Taylor Nieman",
                "screenName" : "@Taylor_Nieman"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "Desktop"
                },
                {
                  "targetingType" : "Languages",
                  "targetingValue" : "English"
                }
              ],
              "impressionTime" : "2022-02-02 14:14:12"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "WtfSidebar",
              "advertiserInfo" : {
                "advertiserName" : "Mans Robots",
                "screenName" : "@MansRobots"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Latvia"
                }
              ],
              "impressionTime" : "2022-02-02 14:14:11"
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adImpressions" : {
          "impressions" : [
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone XS"
              },
              "displayLocation" : "WtfSidebar",
              "advertiserInfo" : {
                "advertiserName" : "1inch Network",
                "screenName" : "@1inch"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "crypto"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "#UNI"
                },
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Financial news"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "United States"
                }
              ],
              "impressionTime" : "2022-01-08 14:25:15"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone XS"
              },
              "displayLocation" : "WtfSidebar",
              "advertiserInfo" : {
                "advertiserName" : "HuaweiUSA",
                "screenName" : "@HuaweiUSA"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "#technology"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "Virtual reality"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "technology"
                },
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Education news and general info"
                },
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Government"
                },
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Music festivals and concerts"
                },
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Sporting events"
                },
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "U.S. military"
                },
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Political elections"
                },
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Leadership"
                },
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "Business news"
                },
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "Technology"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@BBCNews"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@amazon"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@Meta"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@cnnbrk"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@Tesla"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@cnni"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@Microsoft"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@Google"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@YouTube"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@BBCWorld"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@Windows"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@CNNBusiness"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@WSJ"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@CNN"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@intel"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@BBCBreaking"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@CNNPolitics"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "United States"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                }
              ],
              "impressionTime" : "2022-01-08 14:25:15"
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adImpressions" : {
          "impressions" : [
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone XS"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1471943028679987200",
                "tweetText" : "If you're a frequent flyer then this app will save you hundreds of dollars 💸",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Hopper",
                "screenName" : "@hopper"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "United States"
                }
              ],
              "impressionTime" : "2022-01-09 09:08:11"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone XS"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1471238368847618061",
                "tweetText" : "Join the fastest growing community in #TheHobby and download Loupe, a FREE app designed for every card collector!",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Loupe",
                "screenName" : "@LoupeTheApp"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "#thehobby"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "#collect"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "United States"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                },
                {
                  "targetingType" : "OS versions",
                  "targetingValue" : "iOS 13.0 and above"
                },
                {
                  "targetingType" : "Gender",
                  "targetingValue" : "Men"
                }
              ],
              "impressionTime" : "2022-01-09 09:08:06"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone XS"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1345461532734341120",
                "tweetText" : "See exactly what subscriptions you're paying for and cancel those you're not using. Download Truebill today!",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Truebill",
                "screenName" : "@truebill"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "#financing"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "investing"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "#finance"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "financing"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "finance"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Install Truebill Budget & Bill Tracker IOS All"
                },
                {
                  "targetingType" : "List"
                },
                {
                  "targetingType" : "Languages",
                  "targetingValue" : "English"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "United States"
                },
                {
                  "targetingType" : "OS versions",
                  "targetingValue" : "iOS 14.5 and above"
                }
              ],
              "impressionTime" : "2022-01-09 09:05:23"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone XS"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1377521570646794243",
                "tweetText" : "The new weather app everyone is talking about🎉  \nGet smart hyperlocal weather alerts up to 90 mins in advance🌧️⚡☀️",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Tomorrow.io",
                "screenName" : "@tomorrowio_"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Weather"
                },
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "The Weather Channel"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@weatherchannel"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@nytimes"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@cnnbrk"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@sciam"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@CNN"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@washingtonpost"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "25 and up"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "United States"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                }
              ],
              "impressionTime" : "2022-01-09 09:06:08"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone XS"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1384488131223687175",
                "tweetText" : "📣📣📣#DOGECOIN IS HERE!\n\nTrade popular cryptos at a $1 minimum.\n\nTrade #cryptos 24/7, all year long.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Webull",
                "screenName" : "@WebullGlobal"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "#Stock"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "#Crypto"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "Digital"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "#Cryptocurrencies"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "#CryptoCurrency"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "#Digital"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "Cryptocurrencies"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "Stock"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "Cryptocurrency"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "Crypto"
                },
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "Cryptocurrencies"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Install Webull: Investing & Trading IOS All"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "United States"
                }
              ],
              "impressionTime" : "2022-01-09 09:07:23"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone XS"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1471593020415885312",
                "tweetText" : "Mine, Plan, Fight - Everyday a new adventure, everyday a new challenge\n\nDownload Star Trek Fleet Command today.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Star Trek Fleet Command",
                "screenName" : "@StarTrekFleet"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@wilw"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@GeorgeTakei"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "United States"
                },
                {
                  "targetingType" : "OS versions",
                  "targetingValue" : "iOS 14.5 and above"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                },
                {
                  "targetingType" : "Gender",
                  "targetingValue" : "Men"
                }
              ],
              "impressionTime" : "2022-01-09 09:05:40"
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adImpressions" : {
          "impressions" : [
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone XS"
              },
              "displayLocation" : "ProfileAccountsSidebar",
              "advertiserInfo" : {
                "advertiserName" : "محمد بن عبد الكريم العيسى",
                "screenName" : "@MhmdAlissa"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Poland"
                }
              ],
              "impressionTime" : "2022-01-10 08:28:54"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone XS"
              },
              "displayLocation" : "ProfileTweets",
              "promotedTweetInfo" : {
                "tweetId" : "1463705626027376642",
                "tweetText" : "Margin Trading is now live on the https://t.co/vCNztATSCO Exchange App 🚀\n \n🔄 100+ leveraged pairs inc. $SOL, $LUNA &amp; $DOT\n📈 Amplify positions with up to 10x leverage\n📉 Stake CRO for even lower interest rates\n\nTrade Now!",
                "urls" : [
                  "https://t.co/vCNztATSCO"
                ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Crypto.com",
                "screenName" : "@cryptocom"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Financial news"
                },
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "Business & finance"
                },
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "Cryptocurrencies"
                },
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "Personal finance"
                },
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "Ethereum cryptocurrency"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "tezos"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "cryptocurrencies"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "#crypto"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "cryptocurrency"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "eth"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "investing"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "#invest"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "crypto"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "#investing"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "#cryptocurrency"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "financial"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "finance"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@elonmusk"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Install Crypto.com Exchange ANDROID All"
                },
                {
                  "targetingType" : "Website Activity",
                  "targetingValue" : "Exchange Site Signup"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Install Crypto.com Exchange IOS All"
                },
                {
                  "targetingType" : "Languages",
                  "targetingValue" : "English"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Poland"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                }
              ],
              "impressionTime" : "2022-01-10 08:27:54"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone XS"
              },
              "displayLocation" : "ProfileAccountsSidebar",
              "advertiserInfo" : {
                "advertiserName" : "محمد بن عبد الكريم العيسى",
                "screenName" : "@MhmdAlissa"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Poland"
                }
              ],
              "impressionTime" : "2022-01-10 08:27:57"
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adImpressions" : {
          "impressions" : [
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone XS"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1456958530901225480",
                "tweetText" : "Take care of your journey in advance! Track flights and keep the info in one place. ✈️",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Planeslive",
                "screenName" : "@planeslive"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@British_Airways"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@Delta"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "trips"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "trip"
                },
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "National parks"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Latvia"
                }
              ],
              "impressionTime" : "2022-01-11 16:55:21"
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adImpressions" : {
          "impressions" : [
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "WtfSidebar",
              "advertiserInfo" : {
                "advertiserName" : "5ireChain",
                "screenName" : "@5ireChain"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "Cryptocurrencies"
                }
              ],
              "impressionTime" : "2022-01-17 12:50:35"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "ProfileAccountsSidebar",
              "advertiserInfo" : {
                "advertiserName" : "Mans Robots",
                "screenName" : "@MansRobots"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Latvia"
                }
              ],
              "impressionTime" : "2022-01-17 12:53:10"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1425868138567012352",
                "tweetText" : "No time to learn a new language? \nBrowse Twitter with Toucan ⚡",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Taylor Nieman",
                "screenName" : "@Taylor_Nieman"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Languages",
                  "targetingValue" : "English"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "Desktop"
                }
              ],
              "impressionTime" : "2022-01-17 12:50:36"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "WtfSidebar",
              "advertiserInfo" : {
                "advertiserName" : "Mans Robots",
                "screenName" : "@MansRobots"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Latvia"
                }
              ],
              "impressionTime" : "2022-01-17 12:53:09"
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adImpressions" : {
          "impressions" : [
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "ProfileAccountsSidebar",
              "advertiserInfo" : {
                "advertiserName" : "Mans Robots",
                "screenName" : "@MansRobots"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Latvia"
                }
              ],
              "impressionTime" : "2022-01-18 20:39:06"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "WtfSidebar",
              "advertiserInfo" : {
                "advertiserName" : "Mans Robots",
                "screenName" : "@MansRobots"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Latvia"
                }
              ],
              "impressionTime" : "2022-01-18 20:07:08"
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adImpressions" : {
          "impressions" : [
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "WtfSidebar",
              "advertiserInfo" : {
                "advertiserName" : "الوليد بن طلال",
                "screenName" : "@Alwaleed_Talal"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Languages",
                  "targetingValue" : "English"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Latvia"
                }
              ],
              "impressionTime" : "2022-01-19 14:14:06"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "ProfileAccountsSidebar",
              "advertiserInfo" : {
                "advertiserName" : "Mans Robots",
                "screenName" : "@MansRobots"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Latvia"
                }
              ],
              "impressionTime" : "2022-01-19 14:14:07"
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adImpressions" : {
          "impressions" : [
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "ProfileAccountsSidebar",
              "advertiserInfo" : {
                "advertiserName" : "Partisia Blockchain Foundation",
                "screenName" : "@partisiampc"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@alexisohanian"
                },
                {
                  "targetingType" : "Gender",
                  "targetingValue" : "Men"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "21 and up"
                }
              ],
              "impressionTime" : "2022-01-20 08:32:50"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "WtfSidebar",
              "advertiserInfo" : {
                "advertiserName" : "محمد بن عبد الكريم العيسى",
                "screenName" : "@MhmdAlissa"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Latvia"
                }
              ],
              "impressionTime" : "2022-01-20 08:32:49"
            }
          ]
        }
      }
    }
  }
]