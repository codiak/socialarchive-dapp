window.YTD.connected_application.part0 = [
  {
    "connectedApplication" : {
      "organization" : {
        "name" : ""
      },
      "name" : "Musedlab",
      "description" : "Creating new technologies and experiences for music making, learning, and engagement. ",
      "permissions" : [
        "read",
        "write"
      ],
      "approvedAt" : "2016-02-18T16:16:48.000Z",
      "id" : "9465388"
    }
  },
  {
    "connectedApplication" : {
      "organization" : {
        "name" : "",
        "url" : ""
      },
      "name" : "Slack.com",
      "description" : "Slack.com application",
      "permissions" : [
        "read"
      ],
      "approvedAt" : "2015-06-09T20:15:07.000Z",
      "id" : "4448334"
    }
  },
  {
    "connectedApplication" : {
      "organization" : {
        "name" : "Disqus",
        "url" : "http://disqus.com/",
        "privacyPolicyUrl" : "https://help.disqus.com/customer/portal/articles/466259-privacy-policy",
        "termsAndConditionsUrl" : "https://help.disqus.com/customer/portal/articles/466260-terms-of-service"
      },
      "name" : "DISQUS",
      "description" : "Disqus is a service and tool for web comments and discussions.",
      "permissions" : [
        "read",
        "write"
      ],
      "approvedAt" : "2013-04-18T22:31:03.000Z",
      "id" : "2858"
    }
  },
  {
    "connectedApplication" : {
      "organization" : {
        "name" : "Medium",
        "url" : "https://medium.com",
        "privacyPolicyUrl" : "https://medium.com/policy/medium-privacy-policy-f03bf92035c9",
        "termsAndConditionsUrl" : "https://medium.com/policy/medium-terms-of-service-9db0094a1e0f"
      },
      "name" : "Medium",
      "description" : "Evolving publishing",
      "permissions" : [
        "read",
        "write",
        "emailaddress"
      ],
      "approvedAt" : "2017-08-21T15:02:26.000Z",
      "id" : "1923576"
    }
  },
  {
    "connectedApplication" : {
      "organization" : {
        "name" : "Telly Inc.",
        "url" : "http://www.telly.com"
      },
      "name" : "TellyApp",
      "description" : "Telly - discover and share videos",
      "permissions" : [
        "read",
        "write"
      ],
      "approvedAt" : "2010-06-11T03:46:11.000Z",
      "id" : "7360"
    }
  },
  {
    "connectedApplication" : {
      "organization" : {
        "name" : "Twitter",
        "url" : "http://twitter.com"
      },
      "name" : "Mobile Web",
      "description" : "Twitter Mobile Web",
      "permissions" : [
        "read",
        "write"
      ],
      "approvedAt" : "2011-05-09T02:54:17.000Z",
      "id" : "49152"
    }
  },
  {
    "connectedApplication" : {
      "organization" : {
        "name" : "COLOURlovers"
      },
      "name" : "COLOURlovers",
      "description" : "COLOURlovers is a resource that monitors and influences color trends.",
      "permissions" : [
        "read",
        "write"
      ],
      "approvedAt" : "2011-02-17T14:01:55.000Z",
      "id" : "17563"
    }
  },
  {
    "connectedApplication" : {
      "organization" : {
        "name" : "Foursquare",
        "url" : "https://foursquare.com",
        "privacyPolicyUrl" : "https://foursquare.com/legal/privacy",
        "termsAndConditionsUrl" : "https://foursquare.com/legal/terms"
      },
      "name" : "Foursquare",
      "description" : "Foursquare helps you and your friends make the most of where you are",
      "permissions" : [
        "read",
        "write"
      ],
      "approvedAt" : "2013-03-14T04:20:45.000Z",
      "id" : "1166"
    }
  },
  {
    "connectedApplication" : {
      "organization" : {
        "name" : "Twitter",
        "url" : ""
      },
      "name" : "Twitter for iPhone",
      "description" : "Twitter for iPhone",
      "permissions" : [
        "read",
        "write"
      ],
      "approvedAt" : "2019-07-17T14:27:01.000Z",
      "id" : "129032"
    }
  },
  {
    "connectedApplication" : {
      "organization" : {
        "name" : "Zeega",
        "url" : "http://zeega.com"
      },
      "name" : "Zeega",
      "description" : "Zeega is revolutionizing web publishing and interactive storytelling for a future beyond blogs.",
      "permissions" : [
        "read"
      ],
      "approvedAt" : "2013-05-17T09:30:54.000Z",
      "id" : "3880310"
    }
  },
  {
    "connectedApplication" : {
      "organization" : {
        "name" : "Apple®",
        "url" : ""
      },
      "name" : "iOS",
      "description" : "iOS Twitter integration",
      "permissions" : [
        "read",
        "write"
      ],
      "approvedAt" : "2011-12-18T20:51:01.000Z",
      "id" : "312240"
    }
  },
  {
    "connectedApplication" : {
      "organization" : {
        "name" : "Spotify",
        "url" : "http://spotify.com",
        "privacyPolicyUrl" : "https://www.spotify.com/legal/privacy-policy/",
        "termsAndConditionsUrl" : "https://www.spotify.com/legal/end-user-agreement/"
      },
      "name" : "Spotify",
      "description" : "Spotify desktop client share widget",
      "permissions" : [
        "read",
        "write"
      ],
      "approvedAt" : "2016-04-29T13:36:31.000Z",
      "id" : "1467796"
    }
  },
  {
    "connectedApplication" : {
      "organization" : {
        "name" : "",
        "url" : ""
      },
      "name" : "OAuth-io",
      "description" : "OAuth that just works.",
      "permissions" : [
        "read"
      ],
      "approvedAt" : "2015-03-10T19:52:09.000Z",
      "id" : "4726933"
    }
  },
  {
    "connectedApplication" : {
      "organization" : {
        "name" : "Vine Labs, Inc",
        "url" : "http://vine.co"
      },
      "name" : "Vine - Make a Scene",
      "description" : "The best way to see and share life in motion. ",
      "permissions" : [
        "read",
        "write"
      ],
      "approvedAt" : "2013-03-16T07:40:19.000Z",
      "id" : "2873808"
    }
  },
  {
    "connectedApplication" : {
      "organization" : {
        "name" : "UberMedia Inc",
        "url" : "http://ubermedia.com",
        "privacyPolicyUrl" : "https://ubermedia.com/general-privacy-policy/",
        "termsAndConditionsUrl" : "https://ubermedia.com/company/terms-of-service/"
      },
      "name" : "Echofon",
      "description" : "Stay on top of your Twitter timeline with Echofon. The beautiful, subtle interface will be a welcome addition to your desktop.",
      "permissions" : [
        "read",
        "write"
      ],
      "approvedAt" : "2010-05-25T00:01:50.000Z",
      "id" : "73338"
    }
  },
  {
    "connectedApplication" : {
      "organization" : {
        "name" : "Twitter Inc.",
        "url" : "https://periscope.tv",
        "privacyPolicyUrl" : "https://periscope.tv/privacy",
        "termsAndConditionsUrl" : "https://periscope.tv/tos"
      },
      "name" : "Periscope",
      "description" : "Explore the world through someone's eyes!",
      "permissions" : [
        "read",
        "write",
        "emailaddress"
      ],
      "approvedAt" : "2016-04-13T17:53:14.000Z",
      "id" : "8036141"
    }
  },
  {
    "connectedApplication" : {
      "organization" : {
        "name" : "LinkedIn",
        "url" : "http://www.linkedin.com/"
      },
      "name" : "LinkedIn",
      "description" : "LinkedIn Status",
      "permissions" : [
        "read",
        "write"
      ],
      "approvedAt" : "2015-05-28T15:32:39.000Z",
      "id" : "22617"
    }
  },
  {
    "connectedApplication" : {
      "organization" : {
        "name" : "Neighborland",
        "url" : "https://neighborland.com",
        "privacyPolicyUrl" : "https://neighborland.com/about/privacy",
        "termsAndConditionsUrl" : "https://neighborland.com/about/terms"
      },
      "name" : "Neighborland",
      "description" : "Neighborland",
      "permissions" : [
        "read",
        "write"
      ],
      "approvedAt" : "2013-03-20T04:25:25.000Z",
      "id" : "678035"
    }
  },
  {
    "connectedApplication" : {
      "organization" : {
        "name" : "Twitter"
      },
      "name" : "Twitter for iPad",
      "description" : "Twitter for iPad",
      "permissions" : [
        "read",
        "write"
      ],
      "approvedAt" : "2011-09-05T00:53:40.000Z",
      "id" : "191841"
    }
  },
  {
    "connectedApplication" : {
      "organization" : {
        "name" : "Wox, inc",
        "url" : "https://drops.nyc",
        "privacyPolicyUrl" : "http://www.drops.nyc/privacy",
        "termsAndConditionsUrl" : "http://drops.nyc/tos"
      },
      "name" : "AudioDrops",
      "description" : "rediscover the world around you",
      "permissions" : [
        "read",
        "emailaddress"
      ],
      "approvedAt" : "2016-05-20T11:53:33.000Z",
      "id" : "5529302"
    }
  },
  {
    "connectedApplication" : {
      "organization" : {
        "name" : ""
      },
      "name" : "hang5",
      "description" : "do cool stuff",
      "permissions" : [
        "read"
      ],
      "approvedAt" : "2015-01-05T01:18:30.000Z",
      "id" : "7737664"
    }
  },
  {
    "connectedApplication" : {
      "organization" : {
        "name" : "@stevespaced",
        "url" : "http://spaced.world"
      },
      "name" : "Sampulator",
      "description" : "Produce music in your browser.",
      "permissions" : [
        "read"
      ],
      "approvedAt" : "2016-04-04T19:45:54.000Z",
      "id" : "9371781"
    }
  },
  {
    "connectedApplication" : {
      "organization" : {
        "name" : "Twitter",
        "url" : ""
      },
      "name" : "Twitter for iPhone",
      "description" : "Twitter for iPhone",
      "permissions" : [
        "read",
        "write"
      ],
      "approvedAt" : "2011-07-30T23:27:39.000Z",
      "id" : "129032"
    }
  },
  {
    "connectedApplication" : {
      "organization" : {
        "name" : "",
        "url" : ""
      },
      "name" : "Hackathon Starter Public",
      "description" : "public use",
      "permissions" : [
        "read",
        "write"
      ],
      "approvedAt" : "2016-09-28T12:39:26.000Z",
      "id" : "6046107"
    }
  },
  {
    "connectedApplication" : {
      "organization" : {
        "name" : "",
        "url" : ""
      },
      "name" : "Plotly",
      "description" : "Plotly makes better graphs than Excel, MATLAB, or Google Docs",
      "permissions" : [
        "read"
      ],
      "approvedAt" : "2016-06-03T01:44:42.000Z",
      "id" : "4276611"
    }
  },
  {
    "connectedApplication" : {
      "organization" : {
        "name" : "Automattic",
        "url" : "http://automattic.com/"
      },
      "name" : "WordPress.com",
      "description" : "Tweet your WordPress.com posts and comment on WordPress.com using your Twitter identity.",
      "permissions" : [
        "read",
        "write"
      ],
      "approvedAt" : "2015-05-15T03:23:31.000Z",
      "id" : "38869"
    }
  },
  {
    "connectedApplication" : {
      "organization" : {
        "name" : "Apple®",
        "url" : ""
      },
      "name" : "OS X",
      "description" : "OS X Twitter integration",
      "permissions" : [
        "read",
        "write"
      ],
      "approvedAt" : "2013-07-25T14:57:29.000Z",
      "id" : "1535234"
    }
  },
  {
    "connectedApplication" : {
      "organization" : {
        "name" : "Inkfold, Inc.",
        "url" : "http://www.inkfold.com"
      },
      "name" : "Inkfold",
      "description" : "A news experience designed to inspire curiosity and spark conversation.",
      "permissions" : [
        "read",
        "write"
      ],
      "approvedAt" : "2013-05-12T04:59:53.000Z",
      "id" : "4199402"
    }
  },
  {
    "connectedApplication" : {
      "organization" : {
        "name" : "Instagram, Inc.",
        "url" : "http://instagram.com"
      },
      "name" : "Instagram",
      "description" : "Instagram is a fast, beautiful and fun way to share your photos with friends and family.",
      "permissions" : [
        "read",
        "write"
      ],
      "approvedAt" : "2013-03-21T22:22:23.000Z",
      "id" : "239954"
    }
  },
  {
    "connectedApplication" : {
      "organization" : {
        "name" : "Pandora",
        "url" : "http://www.pandora.com"
      },
      "name" : "Pandora (Prod)",
      "description" : "Find the music you love. Let the music you love find you.",
      "permissions" : [
        "read",
        "write"
      ],
      "approvedAt" : "2014-10-04T21:44:19.000Z",
      "id" : "36084"
    }
  },
  {
    "connectedApplication" : {
      "organization" : {
        "name" : "TweetDeck"
      },
      "name" : "TweetDeck",
      "description" : "TweetDeck is an app that brings more flexibility and insight to power users.",
      "permissions" : [
        "read",
        "write"
      ],
      "approvedAt" : "2013-02-20T16:56:57.000Z",
      "id" : "55902"
    }
  },
  {
    "connectedApplication" : {
      "organization" : {
        "name" : ""
      },
      "name" : "MusED Suite",
      "description" : "Tools for making and learning about music from NYU MusEDLsb",
      "permissions" : [
        "read"
      ],
      "approvedAt" : "2017-07-03T15:48:09.000Z",
      "id" : "13942552"
    }
  }
]