window.YTD.direct_messages_group.part0 = [
  {
    "dmConversation" : {
      "conversationId" : "877878409828945920",
      "messages" : [
        {
          "messageCreate" : {
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Pretty cool!!",
            "mediaUrls" : [ ],
            "senderId" : "177638008",
            "id" : "884620746399600645",
            "createdAt" : "2017-07-11T03:49:56.089Z"
          }
        },
        {
          "messageCreate" : {
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "\"Could look like\" they haven't done it yet",
            "mediaUrls" : [ ],
            "senderId" : "18076356",
            "id" : "877990396072251399",
            "createdAt" : "2017-06-22T20:43:17.416Z"
          }
        },
        {
          "messageCreate" : {
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Don't know",
            "mediaUrls" : [ ],
            "senderId" : "8663482",
            "id" : "877952176563376132",
            "createdAt" : "2017-06-22T18:11:25.152Z"
          }
        },
        {
          "messageCreate" : {
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "?",
            "mediaUrls" : [ ],
            "senderId" : "8663482",
            "id" : "877952154987892739",
            "createdAt" : "2017-06-22T18:11:20.006Z"
          }
        },
        {
          "messageCreate" : {
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "This is crazy! Who is  involved in creating this database?",
            "mediaUrls" : [ ],
            "senderId" : "2440901547",
            "id" : "877951982824153092",
            "createdAt" : "2017-06-22T18:10:38.954Z"
          }
        },
        {
          "messageCreate" : {
            "reactions" : [ ],
            "urls" : [
              {
                "url" : "https://t.co/I7hJWw33gA",
                "expanded" : "https://twitter.com/teachingartists/status/875843624864333825",
                "display" : "twitter.com/teachingartist…"
              }
            ],
            "text" : "https://t.co/I7hJWw33gA",
            "mediaUrls" : [ ],
            "senderId" : "8663482",
            "id" : "877878409828945923",
            "createdAt" : "2017-06-22T13:18:17.849Z"
          }
        },
        {
          "joinConversation" : {
            "initiatingUserId" : "8663482",
            "participantsSnapshot" : [
              "8663482",
              "177638008",
              "151990745",
              "18076356",
              "2440901547",
              "987455108",
              "17332098",
              "43527072"
            ],
            "createdAt" : "2017-06-22T13:18:17.846Z"
          }
        }
      ]
    }
  }
]