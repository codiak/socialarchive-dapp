window.YTD.block.part0 = [
  {
    "blocking" : {
      "accountId" : "213796133",
      "userLink" : "https://twitter.com/intent/user?user_id=213796133"
    }
  }
]