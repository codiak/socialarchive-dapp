window.YTD.user_link_clicks.part0 = [
  {
    "userInteractionsData" : {
      "linkClick" : {
        "tweetId" : "1468316310291558405",
        "finalUrl" : "https://www.bloomberg.com/news/articles/2021-11-09/nft-crypto-art-market-boom-biggest-sales-going-to-male-artists-women-lag",
        "timeStampOfInteraction" : "2022-01-07T15:25:53.210Z"
      }
    }
  },
  {
    "userInteractionsData" : {
      "linkClick" : {
        "tweetId" : "1474565490077061121",
        "finalUrl" : "http://be.net/gallery/133814309/Looking-Glass-a-series-of-NFTs-for-Arqaam",
        "timeStampOfInteraction" : "2022-01-08T10:46:27.686Z"
      }
    }
  },
  {
    "userInteractionsData" : {
      "linkClick" : {
        "tweetId" : "1479612716935491584",
        "finalUrl" : "https://foundation.app/collection/who",
        "timeStampOfInteraction" : "2022-01-08T14:28:49.581Z"
      }
    }
  },
  {
    "userInteractionsData" : {
      "linkClick" : {
        "tweetId" : "1479654600676360192",
        "finalUrl" : "https://objkt.com/auction/e/b5B07xNX",
        "timeStampOfInteraction" : "2022-01-09T09:06:47.536Z"
      }
    }
  }
]