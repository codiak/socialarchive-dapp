window.YTD.lists_member.part0 = [
  {
    "userListInfo" : {
      "url" : "https://twitter.com/magnuskjoeller/lists/developers-in-ny-1"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/mandyhallmedia/lists/music3"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/wmscene/lists/musicians3"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/Playtronica/lists/musicians"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/Playtronica/lists/educators"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/nomadworksnyc/lists/top-nyc-developers"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/GadgetFlow/lists/top-developers-nyc"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/danest/lists/developers-in-new-york"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/gregcarley/lists/chaotic-moon"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/karaoehler/lists/matter-vc-class-one"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/arise_human/lists/people"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/cksample/lists/peopleworkedwith"
    }
  }
]