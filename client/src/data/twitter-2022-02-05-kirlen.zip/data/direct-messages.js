window.YTD.direct_messages.part0 = [
  {
    "dmConversation" : {
      "conversationId" : "17478565-43527072",
      "messages" : [
        {
          "messageCreate" : {
            "recipientId" : "17478565",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "hola, one thread I'd love to pick back up with you one o these days is \"white boarding and related working meeting practices\" -yours ruled!",
            "mediaUrls" : [ ],
            "senderId" : "43527072",
            "id" : "730757396084211716",
            "createdAt" : "2016-05-12T13:51:54.790Z"
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "43527072",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Great to see you too! Ill be back in NYC a lot.",
            "mediaUrls" : [ ],
            "senderId" : "17478565",
            "id" : "712651548220755971",
            "createdAt" : "2016-03-23T14:45:44.216Z"
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "17478565",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Hey, Corey! Great seeing you last week -- sorry you had to run! Would love to catch up...",
            "mediaUrls" : [ ],
            "senderId" : "43527072",
            "id" : "712632898915078147",
            "createdAt" : "2016-03-23T13:31:37.917Z"
          }
        }
      ]
    }
  },
  {
    "dmConversation" : {
      "conversationId" : "26436246-43527072",
      "messages" : [
        {
          "messageCreate" : {
            "recipientId" : "26436246",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "? link broken?",
            "mediaUrls" : [ ],
            "senderId" : "43527072",
            "id" : "382600779019714561",
            "createdAt" : "2013-09-24T20:21:48.000Z"
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "43527072",
            "reactions" : [ ],
            "urls" : [
              {
                "url" : "http://t.co/MUnXod1xuH",
                "expanded" : "http://golluce.com/twitter.com.news.php",
                "display" : "golluce.com/twitter.com.ne…"
              }
            ],
            "text" : "recommend http://t.co/MUnXod1xuH",
            "mediaUrls" : [ ],
            "senderId" : "26436246",
            "id" : "382528022005284864",
            "createdAt" : "2013-09-24T15:32:42.000Z"
          }
        }
      ]
    }
  },
  {
    "dmConversation" : {
      "conversationId" : "43525546-43527072",
      "messages" : [
        {
          "messageCreate" : {
            "recipientId" : "43527072",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Pockets? Hope so. Xxx",
            "mediaUrls" : [ ],
            "senderId" : "43525546",
            "id" : "447710701",
            "createdAt" : "2009-10-11T14:07:19.000Z"
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "43525546",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "See my tweets :)",
            "mediaUrls" : [ ],
            "senderId" : "43527072",
            "id" : "446239421",
            "createdAt" : "2009-10-10T23:29:43.000Z"
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "43527072",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Hey bubsy, where are you?",
            "mediaUrls" : [ ],
            "senderId" : "43525546",
            "id" : "445991910",
            "createdAt" : "2009-10-10T21:20:39.000Z"
          }
        }
      ]
    }
  },
  {
    "dmConversation" : {
      "conversationId" : "43527072-137554801",
      "messages" : [
        {
          "messageCreate" : {
            "recipientId" : "43527072",
            "reactions" : [ ],
            "urls" : [
              {
                "url" : "https://t.co/5Y4qumcBfi",
                "expanded" : "http://truetwit.com/vy452472679",
                "display" : "truetwit.com/vy452472679"
              }
            ],
            "text" : "jsheelmusic uses TrueTwit validation. To validate click here: https://t.co/5Y4qumcBfi",
            "mediaUrls" : [ ],
            "senderId" : "137554801",
            "id" : "795313065587838979",
            "createdAt" : "2016-11-06T17:13:05.772Z"
          }
        }
      ]
    }
  },
  {
    "dmConversation" : {
      "conversationId" : "43527072-278388728",
      "messages" : [
        {
          "messageCreate" : {
            "recipientId" : "278388728",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "going to see Brighton Beat tomorrow nite at Bklyn Bowl. you gonna be rockin' ?",
            "mediaUrls" : [ ],
            "senderId" : "43527072",
            "id" : "520324846937321472",
            "createdAt" : "2014-10-09T21:28:05.390Z"
          }
        }
      ]
    }
  },
  {
    "dmConversation" : {
      "conversationId" : "43527072-1890964813",
      "messages" : [
        {
          "messageCreate" : {
            "recipientId" : "43527072",
            "reactions" : [ ],
            "urls" : [
              {
                "url" : "https://t.co/s5lmZnNoTV",
                "expanded" : "https://twitter.com/gierschv/status/892786528958730240",
                "display" : "twitter.com/gierschv/statu…"
              }
            ],
            "text" : "https://t.co/s5lmZnNoTV",
            "mediaUrls" : [ ],
            "senderId" : "1890964813",
            "id" : "892814341686341638",
            "createdAt" : "2017-08-02T18:28:21.565Z"
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1890964813",
            "reactions" : [ ],
            "urls" : [
              {
                "url" : "https://t.co/PLJiWsoywQ",
                "expanded" : "https://twitter.com/ReneLopez/status/873586842456797185",
                "display" : "twitter.com/ReneLopez/stat…"
              }
            ],
            "text" : "Hi MusEDLab, Rene got our handle wrong - should follow him, retweet, etc. https://t.co/PLJiWsoywQ",
            "mediaUrls" : [ ],
            "senderId" : "43527072",
            "id" : "874990694204657667",
            "createdAt" : "2017-06-14T14:03:32.839Z"
          }
        }
      ]
    }
  },
  {
    "dmConversation" : {
      "conversationId" : "43527072-2442257604",
      "messages" : [
        {
          "messageCreate" : {
            "recipientId" : "43527072",
            "reactions" : [ ],
            "urls" : [
              {
                "url" : "https://t.co/0pHMR8jvjz",
                "expanded" : "https://twitter.com/i/moments/885875902776791040",
                "display" : "twitter.com/i/moments/8858…"
              }
            ],
            "text" : "https://t.co/0pHMR8jvjz",
            "mediaUrls" : [ ],
            "senderId" : "2442257604",
            "id" : "885900916158844932",
            "createdAt" : "2017-07-14T16:36:52.433Z"
          }
        }
      ]
    }
  },
  {
    "dmConversation" : {
      "conversationId" : "43527072-4301063243",
      "messages" : [
        {
          "messageCreate" : {
            "recipientId" : "43527072",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Just whatsapped!",
            "mediaUrls" : [ ],
            "senderId" : "4301063243",
            "id" : "1468255254101770248",
            "createdAt" : "2021-12-07T16:25:06.124Z"
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "4301063243",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "or signal?",
            "mediaUrls" : [ ],
            "senderId" : "43527072",
            "id" : "1468255179111866377",
            "createdAt" : "2021-12-07T16:24:48.280Z"
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "4301063243",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "yay, we’re just one hour apart! whatsapp? +16198653311",
            "mediaUrls" : [ ],
            "senderId" : "43527072",
            "id" : "1468255028192362501",
            "createdAt" : "2021-12-07T16:24:12.262Z"
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "43527072",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Yes we definitely should :) I live in Berlin now",
            "mediaUrls" : [ ],
            "senderId" : "4301063243",
            "id" : "1468246085776859158",
            "createdAt" : "2021-12-07T15:48:40.288Z"
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "43527072",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Omg Kevin!! I was thinking about you the other day",
            "mediaUrls" : [ ],
            "senderId" : "4301063243",
            "id" : "1468245980537667588",
            "createdAt" : "2021-12-07T15:48:15.176Z"
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "4301063243",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "hey there, Harshini, or should i say gm :) wanna catch up some time? what country/time zone ru in these days? we’re in Rīga…",
            "mediaUrls" : [ ],
            "senderId" : "43527072",
            "id" : "1468136553159569415",
            "createdAt" : "2021-12-07T08:33:25.612Z"
          }
        }
      ]
    }
  }
]