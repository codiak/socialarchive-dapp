window.YTD.like.part0 = [
  {
    "like" : {
      "tweetId" : "1475745660884652035",
      "fullText" : "I know a lot of folks who maybe need to hear this today. I maybe am one of those folks. Not the sad part about Vachss's passing, the other bit -- https://t.co/l4E8g2Djbw",
      "expandedUrl" : "https://twitter.com/i/web/status/1475745660884652035"
    }
  },
  {
    "like" : {
      "tweetId" : "1479577599328280577",
      "fullText" : "“Glitchy Night” \n\nIt’s with great pleasure that I announce that my first piece of 2022 is now live on @SuperRare \n\nhttps://t.co/KnekUIqLGe https://t.co/5d3ZUhMZ87",
      "expandedUrl" : "https://twitter.com/i/web/status/1479577599328280577"
    }
  },
  {
    "like" : {
      "tweetId" : "1479158002347397120",
      "fullText" : "Always make time for self love ❤️",
      "expandedUrl" : "https://twitter.com/i/web/status/1479158002347397120"
    }
  },
  {
    "like" : {
      "tweetId" : "1479101435090509830",
      "fullText" : "@Reuben_Wu @withFND https://t.co/6lhJBvT3Zc",
      "expandedUrl" : "https://twitter.com/i/web/status/1479101435090509830"
    }
  },
  {
    "like" : {
      "tweetId" : "1482373511326928900",
      "fullText" : "The first NFT I've ever won 😍 thank you @TAROxARTS!! So excited to have one of your works ❤️❤️❤️ https://t.co/aoX8j89fzW",
      "expandedUrl" : "https://twitter.com/i/web/status/1482373511326928900"
    }
  },
  {
    "like" : {
      "tweetId" : "1471259819810050049",
      "fullText" : "Hello, #tezos  #NFTCommunnity My debut collection is now live! 1/1 edi only. 7 $XTZ\n\n👉https://t.co/9NRvR9sQyg\n\nCreated during the pandemic last year while the world around me slowly crumbling down. Yes, #art saved me!\n\n#CleanNFT #NFTcollection #objktcom #Tez https://t.co/FrXZdmlRai",
      "expandedUrl" : "https://twitter.com/i/web/status/1471259819810050049"
    }
  },
  {
    "like" : {
      "tweetId" : "1479171566256672773",
      "fullText" : "@Reuben_Wu @withFND Probably this for no other reason than I like how it feels. https://t.co/xfywJQzDmZ",
      "expandedUrl" : "https://twitter.com/i/web/status/1479171566256672773"
    }
  },
  {
    "like" : {
      "tweetId" : "1479242032631660546",
      "fullText" : "✨ hi! welcome to the world of https://t.co/ltsQr99FZ9 ✨\n\nyou can find my available works in the thread\n\nhave a beautiful day 🌞 https://t.co/Zt2TETdBTS",
      "expandedUrl" : "https://twitter.com/i/web/status/1479242032631660546"
    }
  },
  {
    "like" : {
      "tweetId" : "1484513762346471430",
      "fullText" : "I was just playing around in Illustrator and this is the result🙂🎨 https://t.co/qmlKCrQzkS",
      "expandedUrl" : "https://twitter.com/i/web/status/1484513762346471430"
    }
  },
  {
    "like" : {
      "tweetId" : "1479253969574760450",
      "fullText" : "@Reuben_Wu @withFND ‘consumed’ is about how we as a society are being absorbed into the digital realm as we become more computer oriented. would love to drop this as an NFT as i think it’d be fitting for the space https://t.co/24utAoW8nq",
      "expandedUrl" : "https://twitter.com/i/web/status/1479253969574760450"
    }
  },
  {
    "like" : {
      "tweetId" : "1473609714525220865",
      "fullText" : "HUMMINGBIRD is up on @HicetnuncArt! This will be my last illustration, at least for a while, as I move towards generative art😊Here's my HEN collection so far, with multiple editions still available. Thanks to the collectors who already grabbed these  xx\nhttps://t.co/EY9YwHIviw https://t.co/TFB3eDuDFI",
      "expandedUrl" : "https://twitter.com/i/web/status/1473609714525220865"
    }
  },
  {
    "like" : {
      "tweetId" : "1472902898401128462",
      "fullText" : "GUARDIAN\n\nthe last available artwork from the \"2049 Was a Good Year\" collection\n\nhttps://t.co/VdZcaC3A4Y https://t.co/elWIzmwgx2",
      "expandedUrl" : "https://twitter.com/i/web/status/1472902898401128462"
    }
  },
  {
    "like" : {
      "tweetId" : "1476183941488992258",
      "fullText" : "Orbital is now available to collect on HEN \n\n20 editions \n3 tez each \n\nhttps://t.co/9faOY7wLZb https://t.co/16YjhDwQLC",
      "expandedUrl" : "https://twitter.com/i/web/status/1476183941488992258"
    }
  },
  {
    "like" : {
      "tweetId" : "1476259886589779968",
      "fullText" : "Paper Cut Machine - 2 Red \nRed small edition (only 5) x 0.75 tz :  https://t.co/ndVt8u6Spj\n\n#NFTs #NFT #nftcollector https://t.co/OqzDVDC0WC",
      "expandedUrl" : "https://twitter.com/i/web/status/1476259886589779968"
    }
  },
  {
    "like" : {
      "tweetId" : "1473364569162723337",
      "fullText" : "Please leave a like here if you took the time to read this fucker. Im not a native english speaker so forgive me if there are weird lines hahahahaa.",
      "expandedUrl" : "https://twitter.com/i/web/status/1473364569162723337"
    }
  },
  {
    "like" : {
      "tweetId" : "1464984424106401792",
      "fullText" : "Announcing Chromamorphs, a collection of 333 animated 3D morphs.\n\nPerfect spheres come alive according to their unique color signatures.\n\nPresale: 11/30\nPublic Sale: 12/01\n\nJoin @lclmachine's  discord for drop details: https://t.co/4cWbCYh4mE https://t.co/w7o6Yf8dd8",
      "expandedUrl" : "https://twitter.com/i/web/status/1464984424106401792"
    }
  },
  {
    "like" : {
      "tweetId" : "1473324157513256960",
      "fullText" : "Artificial Memories 7.77\n7 ed.\nAccepting top 7 offers in +/- 24hrs.\nOffer &gt; 77 tez will be accepted instantly.\n\nhttps://t.co/TuO6AY0qRo https://t.co/NxuI23CyUU",
      "expandedUrl" : "https://twitter.com/i/web/status/1473324157513256960"
    }
  },
  {
    "like" : {
      "tweetId" : "1473657246173253634",
      "fullText" : "Sold out means the next 3 pieces have been swapped! Witness the glory and destruction of the Doragon 👇\nThank you so much for the love with this new collection! 💚\n\n1/1, 10 $XTZ\n\n🔥https://t.co/TGhchDZ1pJ🔥\n\n#nfteers #NFTdrop #nftcollectors #tezosnft #pixelart https://t.co/nts5W1Xo6Z",
      "expandedUrl" : "https://twitter.com/i/web/status/1473657246173253634"
    }
  },
  {
    "like" : {
      "tweetId" : "1471497805323636744",
      "fullText" : "⚫️To be an artist, you need to exist in a world of silence. https://t.co/cJIBSKxjZW",
      "expandedUrl" : "https://twitter.com/i/web/status/1471497805323636744"
    }
  },
  {
    "like" : {
      "tweetId" : "1489339029019631616",
      "fullText" : "gn frens🌛 https://t.co/eKUM34TdKO",
      "expandedUrl" : "https://twitter.com/i/web/status/1489339029019631616"
    }
  },
  {
    "like" : {
      "tweetId" : "1473363924053598213",
      "fullText" : "June 2017. \n-\n\nA little story about a 27 year old ambitious creative who just created arcus but that got quite upset. https://t.co/W07VeywT02",
      "expandedUrl" : "https://twitter.com/i/web/status/1473363924053598213"
    }
  },
  {
    "like" : {
      "tweetId" : "1472335622153154560",
      "fullText" : "Special edition @Kibatsu_Mecha 100% art-directed by my firstborn (she's almost 6yrs old). We've decided not to list it ever because, you know, no one would ever be able to afford it 😉♥️🦄❄️🍩✨💎 https://t.co/jSKH382N9x",
      "expandedUrl" : "https://twitter.com/i/web/status/1472335622153154560"
    }
  },
  {
    "like" : {
      "tweetId" : "1472134796763672580",
      "fullText" : "The second work from a collaboration between myself and Dave @davestrickgifs is on air 🌹 on @withFND \nOne of my best pieces of all time. Enjoy and place you bids, put your likes. Retweet is appreciated \nhttps://t.co/Kc9m1QIyn1 #nftart #animation https://t.co/R2wVnbji3x",
      "expandedUrl" : "https://twitter.com/i/web/status/1472134796763672580"
    }
  },
  {
    "like" : {
      "tweetId" : "1488988095391453184",
      "fullText" : "Shapes https://t.co/jia1ZPkpIB",
      "expandedUrl" : "https://twitter.com/i/web/status/1488988095391453184"
    }
  },
  {
    "like" : {
      "tweetId" : "1479833132757139457",
      "fullText" : "Gas is fluctuating a lot today but if it gets low enough I'll be able to mint my new work on @withFND ☺️",
      "expandedUrl" : "https://twitter.com/i/web/status/1479833132757139457"
    }
  },
  {
    "like" : {
      "tweetId" : "1466848280516898816",
      "fullText" : "Doing some art therapy while listening to favorites songs...  Ah.. Soothing..  😌✨ https://t.co/llrdJbtsvw",
      "expandedUrl" : "https://twitter.com/i/web/status/1466848280516898816"
    }
  },
  {
    "like" : {
      "tweetId" : "1467808061104574466",
      "fullText" : "@OceanKnighter 😍",
      "expandedUrl" : "https://twitter.com/i/web/status/1467808061104574466"
    }
  },
  {
    "like" : {
      "tweetId" : "1387081606494658562",
      "fullText" : "... .--. . -.-. - .-. --- ... -.-. --- .--. -.--     .. ...     .-- .... .- -     .- ... - .-. --- -. --- -- . .-. ...     ..- ... .     - ---     .- -. .- .-.. -.-- --.. .     .-.. .. --. .... -     -.-. --- -- .. -. --.     ..-. .-. --- --     .-     ... - .- .-. #MorseCodeDay",
      "expandedUrl" : "https://twitter.com/i/web/status/1387081606494658562"
    }
  },
  {
    "like" : {
      "tweetId" : "1168221876721614848",
      "fullText" : "Has anyone checked to see if that guy from U2 ever found that thing??",
      "expandedUrl" : "https://twitter.com/i/web/status/1168221876721614848"
    }
  },
  {
    "like" : {
      "tweetId" : "1092526180920709120",
      "fullText" : "Oh hey.  Sorry for the delay.  Not on twitter all the time, Congressman.  This may take a while and I know how busy you must be but let's start with substance then move to process. Shall we? 1/ https://t.co/SUwGMdH43t",
      "expandedUrl" : "https://twitter.com/i/web/status/1092526180920709120"
    }
  },
  {
    "like" : {
      "tweetId" : "1176643027915411461",
      "fullText" : "Impeachmint https://t.co/TeAJh02l5a",
      "expandedUrl" : "https://twitter.com/i/web/status/1176643027915411461"
    }
  },
  {
    "like" : {
      "tweetId" : "1471892642493521925",
      "fullText" : "Today I modelled for a painting class filled with old cute Dutch artists in a schmancy studio. Something powerful about a naked brown body in the center of the room being respected  and heard by humans I thought I would never connect/interact with. IT WAS SO WHOLESOME AHHH",
      "expandedUrl" : "https://twitter.com/i/web/status/1471892642493521925"
    }
  },
  {
    "like" : {
      "tweetId" : "1465427886178025475",
      "fullText" : "my GENISIS on  @_Dartroom its here!\n\n\"ray of light\" ✨\n\n1/1- 250\n\navailable here: https://t.co/YP3BNx2G00 \n\n#dartroom #AlgoNFT #Algorand @dandaodara https://t.co/eRJWAn2dqb",
      "expandedUrl" : "https://twitter.com/i/web/status/1465427886178025475"
    }
  },
  {
    "like" : {
      "tweetId" : "1295713002105208832",
      "fullText" : "Michelle Obama, y’all.  https://t.co/0XU7Iw5Lr8",
      "expandedUrl" : "https://twitter.com/i/web/status/1295713002105208832"
    }
  },
  {
    "like" : {
      "tweetId" : "1476796937806483456",
      "fullText" : "Hey y'all! My name's Harshini and I'm a Sri Lankan-Peruvian digital artist based in Berlin🌟Constantly experimenting, always learning. Feel free to connect😊 Here's some of the work I made this year, all minted as #NFTart 🚀Thank you #NFT fam for a great 2021! ❤️ https://t.co/G8Qs70hvsp",
      "expandedUrl" : "https://twitter.com/i/web/status/1476796937806483456"
    }
  },
  {
    "like" : {
      "tweetId" : "1297667322321281025",
      "fullText" : "my fave pre-covid nyc memory is being offered a tissue by 3 separate strangers as I cried on the L train",
      "expandedUrl" : "https://twitter.com/i/web/status/1297667322321281025"
    }
  },
  {
    "like" : {
      "tweetId" : "1467566162804416519",
      "fullText" : "Recently one of my professors said, and I quote, \"you're not an artist unless you have your work in a gallery. The elite have to approve your work or you're just a hobby or pretend artist.\"\n\nNeedless to say, I walked out of the class. My final project will be a big 🖕to the prof.",
      "expandedUrl" : "https://twitter.com/i/web/status/1467566162804416519"
    }
  },
  {
    "like" : {
      "tweetId" : "1467191858933686276",
      "fullText" : "Dakpanplaat https://t.co/YqaOFjpBlr",
      "expandedUrl" : "https://twitter.com/i/web/status/1467191858933686276"
    }
  },
  {
    "like" : {
      "tweetId" : "1176642064253145088",
      "fullText" : "time now @benandjerrys? or maybe @benandjerrysUK? #standup4impeachment https://t.co/diRUy9ZQGs",
      "expandedUrl" : "https://twitter.com/i/web/status/1176642064253145088"
    }
  },
  {
    "like" : {
      "tweetId" : "1465504042348601353",
      "fullText" : "LF: advice! Should I price drop Screen Time? It actually has the second highest likes on my @tryShowtime page but I feel like I took a risk adding my geometric art to my @withFND :( Link below:\nhttps://t.co/c5Wp4f0c66 https://t.co/5qmyhKLXJq",
      "expandedUrl" : "https://twitter.com/i/web/status/1465504042348601353"
    }
  },
  {
    "like" : {
      "tweetId" : "1468355801639272450",
      "fullText" : "Been following the work of @_NicoleRuggiero for a while and I am so happy to add this piece to my collection. Especially now when I'm researching the metaverse and virtual bodies, I cannot think of a more inspiring piece to add to my collection. Nicole, you're awesome 🔥🔥❤️❤️ https://t.co/tT0hs4Edvx",
      "expandedUrl" : "https://twitter.com/i/web/status/1468355801639272450"
    }
  },
  {
    "like" : {
      "tweetId" : "1172326558901534720",
      "fullText" : "Now that Senator Harris brought it up, we could probably use most of the Wizard of Oz movie quotes to sum up Trumps entire presidency. #DemocraticDebate https://t.co/AZ0AmfvkgB",
      "expandedUrl" : "https://twitter.com/i/web/status/1172326558901534720"
    }
  },
  {
    "like" : {
      "tweetId" : "1168473536098447360",
      "fullText" : "Super zoom 🔍🤯 https://t.co/dhyYjzPr8h",
      "expandedUrl" : "https://twitter.com/i/web/status/1168473536098447360"
    }
  },
  {
    "like" : {
      "tweetId" : "1465505534585491462",
      "fullText" : "Today I found out @FVCKDIGITAL follows me on @tryShowtime and I mildly freaked out. I just love their work so much😭 thanks for the follow!! xoxo",
      "expandedUrl" : "https://twitter.com/i/web/status/1465505534585491462"
    }
  },
  {
    "like" : {
      "tweetId" : "1467808176858824708",
      "fullText" : "Thank you @OceanKnighter ❤️❤️❤️ really glad this owlie found a home in your collection! https://t.co/zXvupHBxK8",
      "expandedUrl" : "https://twitter.com/i/web/status/1467808176858824708"
    }
  },
  {
    "like" : {
      "tweetId" : "1470175885634555911",
      "fullText" : "UNSEEN and 2 other pieces from my \"Looking Glass\" collection being exhibited by @wizara_art are available to be collected!! Each piece at 0.22ETH. Check it out: \nhttps://t.co/QRVYSveKss https://t.co/WKSGytISeg",
      "expandedUrl" : "https://twitter.com/i/web/status/1470175885634555911"
    }
  },
  {
    "like" : {
      "tweetId" : "1351882312724713474",
      "fullText" : "Oh God, I can’t contain my excitement Good Fucking Riddance MF!! 🤣😂 #ByeTrump  #ByeFelicia  https://t.co/xdWtqlMRuB",
      "expandedUrl" : "https://twitter.com/i/web/status/1351882312724713474"
    }
  },
  {
    "like" : {
      "tweetId" : "1295419281073672195",
      "fullText" : "My dream is to one day jam with Dave Grohl, @taylorhawkins and all the @foofighters! Mr Grohl I would love to have a drum battle with you! I LOVE Everlong it’s really hard to play as it’s so fast but so much FUN! #foofighters https://t.co/Pmdhvl57uu",
      "expandedUrl" : "https://twitter.com/i/web/status/1295419281073672195"
    }
  },
  {
    "like" : {
      "tweetId" : "1468343556284821511",
      "fullText" : "Playing with creating an avatar with @readyplayerme and it is FREAKY and COOL how it got my skin tone and eye colour matched perfectly. It even suggested something I would actually wear IRL. All from a selfie. #Metaverse",
      "expandedUrl" : "https://twitter.com/i/web/status/1468343556284821511"
    }
  },
  {
    "like" : {
      "tweetId" : "1176152717275947009",
      "fullText" : "“People are suffering. People are dying. Entire ecosystems are collapsing. We are in the beginning of a mass extinction. And all you can talk about is money and fairytales of eternal economic growth. How dare you!”My speech in UN General Assembly in print https://t.co/8wYyCa4H01",
      "expandedUrl" : "https://twitter.com/i/web/status/1176152717275947009"
    }
  },
  {
    "like" : {
      "tweetId" : "784760656239202304",
      "fullText" : "Robert DeNiro demolishes  Trump—\"He's a punk. He's a pig. He's a con—a mutt who doesn't know what he's talking about https://t.co/JcK8nmkczO",
      "expandedUrl" : "https://twitter.com/i/web/status/784760656239202304"
    }
  },
  {
    "like" : {
      "tweetId" : "800545365900623873",
      "fullText" : "Star athlete turned Amy officer, turned star astronomer!  Happy Birthday, Edwin Hubble of \"Hubble's Law\" and @HubbleTelescope fame! https://t.co/a1bVlRAJSZ",
      "expandedUrl" : "https://twitter.com/i/web/status/800545365900623873"
    }
  },
  {
    "like" : {
      "tweetId" : "800743604419444737",
      "fullText" : "On the recommendation of @kevinirlen, bumping this as a mood elevator. https://t.co/952KYQ7ejA",
      "expandedUrl" : "https://twitter.com/i/web/status/800743604419444737"
    }
  },
  {
    "like" : {
      "tweetId" : "785213655214354432",
      "fullText" : "Trees are tree diagrams of themselves",
      "expandedUrl" : "https://twitter.com/i/web/status/785213655214354432"
    }
  },
  {
    "like" : {
      "tweetId" : "785250804420587520",
      "fullText" : "Someone named მამუკა ჯიბლაძე made a cool movie of the McGee graph, which has 24 nodes and 36 edges.  Learn the math: https://t.co/CVNryJ53gV https://t.co/7RwbHBjcNP",
      "expandedUrl" : "https://twitter.com/i/web/status/785250804420587520"
    }
  },
  {
    "like" : {
      "tweetId" : "786540771264589824",
      "fullText" : "Bob Dylan wins the 2016 Nobel Prize in Literature. https://t.co/4X3TWDrBBT https://t.co/T7U9wDXa4r",
      "expandedUrl" : "https://twitter.com/i/web/status/786540771264589824"
    }
  },
  {
    "like" : {
      "tweetId" : "806616626648989696",
      "fullText" : "Last week at #NYU with @alexruthmann and @MusEDLab team, performing on conductive rubbers and #touchme device https://t.co/dkbP2PTXuK",
      "expandedUrl" : "https://twitter.com/i/web/status/806616626648989696"
    }
  },
  {
    "like" : {
      "tweetId" : "724993937694412801",
      "fullText" : ".@herbiehancock at the @usedgov sharing how @MathSciMusic and can transform learning #education #jazzday https://t.co/PYurihpldy",
      "expandedUrl" : "https://twitter.com/i/web/status/724993937694412801"
    }
  },
  {
    "like" : {
      "tweetId" : "801094621161996288",
      "fullText" : "Students can experience Hip Hop technology w/the #Soundbreaking Sampler TechTool in this lesson: https://t.co/OkCFJML774 @MusEDLab @djspooky https://t.co/94Pn2FJtOc",
      "expandedUrl" : "https://twitter.com/i/web/status/801094621161996288"
    }
  },
  {
    "like" : {
      "tweetId" : "764245152764485632",
      "fullText" : "\"It does not matter how slowly you go as long as you do not stop.\"  -Confucius",
      "expandedUrl" : "https://twitter.com/i/web/status/764245152764485632"
    }
  },
  {
    "like" : {
      "tweetId" : "777520457599844352",
      "fullText" : "Sunday morning beats with the kids https://t.co/pHPRGPRmlo",
      "expandedUrl" : "https://twitter.com/i/web/status/777520457599844352"
    }
  },
  {
    "like" : {
      "tweetId" : "785289745735626752",
      "fullText" : "haha Trump just devoted his presidency to personal revenge so that's cool and useful and good for America",
      "expandedUrl" : "https://twitter.com/i/web/status/785289745735626752"
    }
  },
  {
    "like" : {
      "tweetId" : "747444498121240577",
      "fullText" : "Huge thank you to everyone who came out to the MusED Open Lab this weekend. We loved getting to know our students a little better!",
      "expandedUrl" : "https://twitter.com/i/web/status/747444498121240577"
    }
  },
  {
    "like" : {
      "tweetId" : "822926876033372160",
      "fullText" : "Whoa, the coastal elites really get around. https://t.co/YYWbtASJMm",
      "expandedUrl" : "https://twitter.com/i/web/status/822926876033372160"
    }
  },
  {
    "like" : {
      "tweetId" : "785913217012867072",
      "fullText" : "Thanks for hooking it up @therewasaguy https://t.co/BJDGoE7Tuj",
      "expandedUrl" : "https://twitter.com/i/web/status/785913217012867072"
    }
  },
  {
    "like" : {
      "tweetId" : "729145450910126080",
      "fullText" : "Thanks @alexruthmann &amp; @MusEDLab  https://t.co/Dr3vGOq86k",
      "expandedUrl" : "https://twitter.com/i/web/status/729145450910126080"
    }
  },
  {
    "like" : {
      "tweetId" : "735858842727129088",
      "fullText" : "Steal This Riff: How To Fix Copyright Law And Set Musicians Free https://t.co/Ua0qHH8Zav via @instapaper",
      "expandedUrl" : "https://twitter.com/i/web/status/735858842727129088"
    }
  },
  {
    "like" : {
      "tweetId" : "785301583512952832",
      "fullText" : "Is Martha Raddatz winning this debate?",
      "expandedUrl" : "https://twitter.com/i/web/status/785301583512952832"
    }
  },
  {
    "like" : {
      "tweetId" : "799403856085991424",
      "fullText" : "NYC friends: want to come by NYU and test a new rhythm interface I'm working on? Willing to do it while blindfolded? Hit me up.",
      "expandedUrl" : "https://twitter.com/i/web/status/799403856085991424"
    }
  },
  {
    "like" : {
      "tweetId" : "784946651072835584",
      "fullText" : "\"Next month we will grab you where it hurts. By your ballots.\" https://t.co/X5PKKWci5C",
      "expandedUrl" : "https://twitter.com/i/web/status/784946651072835584"
    }
  },
  {
    "like" : {
      "tweetId" : "726082789079146496",
      "fullText" : "Enjoying @IntlJazzDay concerts in Paris. #mathsciencemusic @MathSciMusic #JazzDay @MonkInstitute https://t.co/GIAkLX46gg",
      "expandedUrl" : "https://twitter.com/i/web/status/726082789079146496"
    }
  },
  {
    "like" : {
      "tweetId" : "822852619823677440",
      "fullText" : "Anti-Trump protests gathering at both ends of my subway trip into Manhattan. NYC, you give me hope.",
      "expandedUrl" : "https://twitter.com/i/web/status/822852619823677440"
    }
  },
  {
    "like" : {
      "tweetId" : "724924918291435525",
      "fullText" : "GroovePizza team @ethanhein @adamjnovember @pana_li @kevinirlen @mindofmatthew @therewasaguy @hill @jjorrM @angelahyl @HarshiniJK @asyrique",
      "expandedUrl" : "https://twitter.com/i/web/status/724924918291435525"
    }
  },
  {
    "like" : {
      "tweetId" : "822857100657389568",
      "fullText" : "My favorite homemade sign amid the crowd in DC, carried by a silver-haired woman: \"Now You've Pissed Off Grandma!\"",
      "expandedUrl" : "https://twitter.com/i/web/status/822857100657389568"
    }
  },
  {
    "like" : {
      "tweetId" : "670307784714493957",
      "fullText" : "Wonder how much Duke Ellington's own later piano style was modeled on Monk. Maybe it was just convergent evolution.",
      "expandedUrl" : "https://twitter.com/i/web/status/670307784714493957"
    }
  },
  {
    "like" : {
      "tweetId" : "670305050410004480",
      "fullText" : "Also, after listening to a lot of Monk, everyone else sounds anxious and self-doubting for filling up all the space with notes.",
      "expandedUrl" : "https://twitter.com/i/web/status/670305050410004480"
    }
  },
  {
    "like" : {
      "tweetId" : "619965923571695617",
      "fullText" : "I want to go to Mars just so I can be the first person to say that I prefer Earth's crust! @vice @elonmusk https://t.co/KMK8QJ2d9h",
      "expandedUrl" : "https://twitter.com/i/web/status/619965923571695617"
    }
  },
  {
    "like" : {
      "tweetId" : "670307102724853760",
      "fullText" : "After hearing Monk play \"Tea For Two\" or \"Sweet And Lovely,\" every other version sounds wrong.",
      "expandedUrl" : "https://twitter.com/i/web/status/670307102724853760"
    }
  },
  {
    "like" : {
      "tweetId" : "616039498435174400",
      "fullText" : "The sentiment behind Bob Seger’s “Old Time Rock And Roll” is like Scalia-level horrible.",
      "expandedUrl" : "https://twitter.com/i/web/status/616039498435174400"
    }
  },
  {
    "like" : {
      "tweetId" : "670305823776710656",
      "fullText" : "Monk did me a world of good, not just as a musician, but as a human: taught me that playfulness and intellect are not mutually exclusive.",
      "expandedUrl" : "https://twitter.com/i/web/status/670305823776710656"
    }
  },
  {
    "like" : {
      "tweetId" : "670306980226064384",
      "fullText" : "Also, Monk shows line between composition &amp; interpretation is nonexistent. Monk's takes on standards are as much his tunes as his originals.",
      "expandedUrl" : "https://twitter.com/i/web/status/670306980226064384"
    }
  },
  {
    "like" : {
      "tweetId" : "670304424628248576",
      "fullText" : "Current jazz has picked up on Monk's intellectualism but it forgot about his melodicism.",
      "expandedUrl" : "https://twitter.com/i/web/status/670304424628248576"
    }
  },
  {
    "like" : {
      "tweetId" : "670305201409126401",
      "fullText" : "I can tell you, the absolute scariest thing is to be on a stage with an instrument in your hand and not play it.",
      "expandedUrl" : "https://twitter.com/i/web/status/670305201409126401"
    }
  },
  {
    "like" : {
      "tweetId" : "670306181567619072",
      "fullText" : "Also, Monk had a great strategy for dealing with out-of-tune pianos, which was to bang on them hard enough to make them sound \"right.\"",
      "expandedUrl" : "https://twitter.com/i/web/status/670306181567619072"
    }
  },
  {
    "like" : {
      "tweetId" : "670307582754562052",
      "fullText" : "Even if Monk had never written a tune and had just played Ellington his whole career, he'd still be a crucial figure in 20th century music.",
      "expandedUrl" : "https://twitter.com/i/web/status/670307582754562052"
    }
  },
  {
    "like" : {
      "tweetId" : "616077171333984256",
      "fullText" : "@juantornor He really is a convenient synecdoche for a certain kind of atavistic wrongness.",
      "expandedUrl" : "https://twitter.com/i/web/status/616077171333984256"
    }
  },
  {
    "like" : {
      "tweetId" : "670305356959105024",
      "fullText" : "My criticism of every lame white jazz dude, including myself: playing too much, changing the topic too often, continual emotional evasion.",
      "expandedUrl" : "https://twitter.com/i/web/status/670305356959105024"
    }
  },
  {
    "like" : {
      "tweetId" : "670306014315610112",
      "fullText" : "Monk plays ballads ridiculously fast and medium tunes ridiculously slow. Learned a lot from that too.",
      "expandedUrl" : "https://twitter.com/i/web/status/670306014315610112"
    }
  },
  {
    "like" : {
      "tweetId" : "670306294759358465",
      "fullText" : "And of course his well-documented habit of taking his mistakes, doubling down on them, and basing new ideas on them.",
      "expandedUrl" : "https://twitter.com/i/web/status/670306294759358465"
    }
  },
  {
    "like" : {
      "tweetId" : "618199235830415365",
      "fullText" : "Recently updated: my guide to the mysterious melodic minor scale. http://t.co/VKFWB8ax4o",
      "expandedUrl" : "https://twitter.com/i/web/status/618199235830415365"
    }
  },
  {
    "like" : {
      "tweetId" : "670304887696138240",
      "fullText" : "I was annoyed when younger that so many Monk solos were just restatements of the head. Now it makes sense. He needs to make sure you get it.",
      "expandedUrl" : "https://twitter.com/i/web/status/670304887696138240"
    }
  },
  {
    "like" : {
      "tweetId" : "616313788053258240",
      "fullText" : "My 7-yr-old needed a hair band for her pony tail this morning. I suggested Poison. She wasn't amused.",
      "expandedUrl" : "https://twitter.com/i/web/status/616313788053258240"
    }
  },
  {
    "like" : {
      "tweetId" : "670304517775360000",
      "fullText" : "When's the last time a jazz composition got stuck in your head? And yet every last Monk head is an earworm.",
      "expandedUrl" : "https://twitter.com/i/web/status/670304517775360000"
    }
  },
  {
    "like" : {
      "tweetId" : "670302937248329728",
      "fullText" : "Refreshing my Monk repertoire on guitar. Monk tunes sit really well on guitar, better than linear, flowing bebop heads.",
      "expandedUrl" : "https://twitter.com/i/web/status/670302937248329728"
    }
  },
  {
    "like" : {
      "tweetId" : "618413398372577280",
      "fullText" : "The brand new Ceros Font Explorer is here! Learn more in our July release notes: http://t.co/rrx73BPAOA http://t.co/G39lmQBkJT",
      "expandedUrl" : "https://twitter.com/i/web/status/618413398372577280"
    }
  },
  {
    "like" : {
      "tweetId" : "670305092986396672",
      "fullText" : "Well, except Miles Davis.",
      "expandedUrl" : "https://twitter.com/i/web/status/670305092986396672"
    }
  },
  {
    "like" : {
      "tweetId" : "619955859611910144",
      "fullText" : "\"I…I'm a little divided. Should I stay or run away and leave it all behind?\" #timeslikethese",
      "expandedUrl" : "https://twitter.com/i/web/status/619955859611910144"
    }
  },
  {
    "like" : {
      "tweetId" : "668111007596720128",
      "fullText" : "Alex Johnson Family Memorial Fund https://t.co/OpmDaIQjPq for all of you who have been asking how to help",
      "expandedUrl" : "https://twitter.com/i/web/status/668111007596720128"
    }
  },
  {
    "like" : {
      "tweetId" : "670306471398252545",
      "fullText" : "This idea that if you play definitely enough, you literally can not play anything right or wrong, just strange or less strange.",
      "expandedUrl" : "https://twitter.com/i/web/status/670306471398252545"
    }
  },
  {
    "like" : {
      "tweetId" : "670303926579798017",
      "fullText" : "Especially impressive that those tunes are so weird on the page and so natural to the ear. \"Pannonica\" is baffling on paper, sounds great.",
      "expandedUrl" : "https://twitter.com/i/web/status/670303926579798017"
    }
  },
  {
    "like" : {
      "tweetId" : "577124359170576384",
      "fullText" : "Oh sun why have you forsaken us? #NYCweather #clouds #forsaken",
      "expandedUrl" : "https://twitter.com/i/web/status/577124359170576384"
    }
  },
  {
    "like" : {
      "tweetId" : "576762207377162240",
      "fullText" : "Jane Goodall, and my monkey feet. #JaneGoodall #nytmag #greywomen #wildwomen @RebelleTweet @GreyisOK #evolution http://t.co/qhUPPHOn3S",
      "expandedUrl" : "https://twitter.com/i/web/status/576762207377162240"
    }
  },
  {
    "like" : {
      "tweetId" : "576741642306248704",
      "fullText" : "OH \"We can't just be straight up twisted?\"",
      "expandedUrl" : "https://twitter.com/i/web/status/576741642306248704"
    }
  },
  {
    "like" : {
      "tweetId" : "532725520233140225",
      "fullText" : "doodle http://t.co/5oTtZmBWx0",
      "expandedUrl" : "https://twitter.com/i/web/status/532725520233140225"
    }
  },
  {
    "like" : {
      "tweetId" : "598871047505637377",
      "fullText" : "I don't mind telling you, this is some of my finest music writing. http://t.co/XxCSxqFX4T",
      "expandedUrl" : "https://twitter.com/i/web/status/598871047505637377"
    }
  },
  {
    "like" : {
      "tweetId" : "576916086903451648",
      "fullText" : "Exciting night: @Recurrency is on @ProductHunt. Maybe one day @ProductHunt will be on @Recurrency. #upvotetime",
      "expandedUrl" : "https://twitter.com/i/web/status/576916086903451648"
    }
  },
  {
    "like" : {
      "tweetId" : "532613065876176896",
      "fullText" : "OH \"That'll add some funk to the office.\"",
      "expandedUrl" : "https://twitter.com/i/web/status/532613065876176896"
    }
  },
  {
    "like" : {
      "tweetId" : "576912854231736320",
      "fullText" : "The Makerbot’s operating noise is remarkably soothing. I suspect that it actually runs silently but was sound designed by Brian Eno.",
      "expandedUrl" : "https://twitter.com/i/web/status/576912854231736320"
    }
  },
  {
    "like" : {
      "tweetId" : "577322346387611648",
      "fullText" : "Things my dog barked at today: the grim reaper, a blimp, the grumpy cat airplane, and the drunk yells of so many bros. #sxsw",
      "expandedUrl" : "https://twitter.com/i/web/status/577322346387611648"
    }
  },
  {
    "like" : {
      "tweetId" : "571298714976985088",
      "fullText" : "I inadvertently taught Milo the word \"selfie.\" Hurray for me.",
      "expandedUrl" : "https://twitter.com/i/web/status/571298714976985088"
    }
  },
  {
    "like" : {
      "tweetId" : "342686351881277443",
      "fullText" : "Mobile Audio Rising. Old Media in New Contexts. @bonnier http://t.co/blYP76ad72 How @SpokenLayer is helping publishers with audio on mobile",
      "expandedUrl" : "https://twitter.com/i/web/status/342686351881277443"
    }
  },
  {
    "like" : {
      "tweetId" : "422845223656755200",
      "fullText" : "Darcy &amp; Mom #darcysbirth http://t.co/UxLx8xjJmK",
      "expandedUrl" : "https://twitter.com/i/web/status/422845223656755200"
    }
  },
  {
    "like" : {
      "tweetId" : "576824697003892736",
      "fullText" : "3D printing at the #NYU @MusEDLab #artsmediamakerhack @nyusteinhardt @NYULeslie http://t.co/2613NCylLA",
      "expandedUrl" : "https://twitter.com/i/web/status/576824697003892736"
    }
  },
  {
    "like" : {
      "tweetId" : "1092650723567910912",
      "fullText" : "to help in this debate. So back to substance.  Earlier I mentioned how we want fluid responses to support the (sometimes competing) goal of \"secure flow.\" It's how we think about movement in our homeland.  (I'll leave the moral and legal issues about a wall to others). 18/",
      "expandedUrl" : "https://twitter.com/i/web/status/1092650723567910912"
    }
  },
  {
    "like" : {
      "tweetId" : "1092530237710221312",
      "fullText" : "Anyway, I feel silly writing this. You know this and if you don't happy to continue the conversation but one final thing.   . . about that mansplaining thing. 11/",
      "expandedUrl" : "https://twitter.com/i/web/status/1092530237710221312"
    }
  },
  {
    "like" : {
      "tweetId" : "1092650726906626049",
      "fullText" : "So, on substance, the \"wall\" defeats those two primary tenets of protecting a complex system: balancing security with flow (the border and points of entry) and avoiding the single point of failure (the wall can be overcome by a ladder or tunnel).  22/",
      "expandedUrl" : "https://twitter.com/i/web/status/1092650726906626049"
    }
  },
  {
    "like" : {
      "tweetId" : "1092530232744177666",
      "fullText" : "nearly 800 miles of barriers, drones, dogs, etc. -- are so much better.  See unlike a war zone (I'll defer to you on that), a port of entry must permit flow.  It is how we function as a market economy. So us \"experts\" think about it in terms of how do we better \"secure flow\" 5/",
      "expandedUrl" : "https://twitter.com/i/web/status/1092530232744177666"
    }
  },
  {
    "like" : {
      "tweetId" : "1092526185400188929",
      "fullText" : "That would be Will Hurd so just read this first.  https://t.co/Wz0kLrBBA6\nIf viewing better than reading, how about this:\nhttps://t.co/bckDsvHkQh 3/",
      "expandedUrl" : "https://twitter.com/i/web/status/1092526185400188929"
    }
  },
  {
    "like" : {
      "tweetId" : "1092530243120885761",
      "fullText" : "Some of us have spent a career in and out of government, or media, or private sector, and the academy (she is me).  But I would take your interest in my opinions more seriously if they didn't include such odd personal attacks.  14/",
      "expandedUrl" : "https://twitter.com/i/web/status/1092530243120885761"
    }
  },
  {
    "like" : {
      "tweetId" : "1092530244043657217",
      "fullText" : "It's not becoming of your position.  \nI wish you best as you assess this and your role.  And you engage with women and men whom you disagree with in a much less personal manner.  I believe the facts, history, economics and policy are against building a wall. You don't. 15/",
      "expandedUrl" : "https://twitter.com/i/web/status/1092530244043657217"
    }
  },
  {
    "like" : {
      "tweetId" : "1092650728785616896",
      "fullText" : "Ok, I think I may have violated some unwritten rule of twitter and threads, but my objection to the wall (even assuming I could get it for free and in a day, which I can't) are not just \"that's not who we are\" or \"immigrants are good for America.\"  24/",
      "expandedUrl" : "https://twitter.com/i/web/status/1092650728785616896"
    }
  },
  {
    "like" : {
      "tweetId" : "1092526187992281091",
      "fullText" : "So, why would anyone who lives, works or actually spent a career (I think you know my bio by now. . . ) in homeland security and border management not favor a wall?  The alternatives -- man/women power, technology, barriers (yes, lest you forget, the Obama Administration built",
      "expandedUrl" : "https://twitter.com/i/web/status/1092526187992281091"
    }
  },
  {
    "like" : {
      "tweetId" : "1092530233549430786",
      "fullText" : "build a wall.  So let's take your example of the fentanyl arrest.  Think about it: it was stopped because it wasn't a wall.  It was intelligence, man/women power, technology and DOGS that led to the arrest.  That's how it should work; it's not a sign that there is a better 6/",
      "expandedUrl" : "https://twitter.com/i/web/status/1092530233549430786"
    }
  },
  {
    "like" : {
      "tweetId" : "1092650726034235392",
      "fullText" : "barriers so that the access point is either avoided (i.e. you can't get into a system through cyber attack because the system is layered and bifurcated) or difficult to access (i.e. lock the cockpit door, but have multiple security layers before entry to plane.) 21/",
      "expandedUrl" : "https://twitter.com/i/web/status/1092650726034235392"
    }
  },
  {
    "like" : {
      "tweetId" : "1092650727963590656",
      "fullText" : "It's just a way to think about the substantive arguments about real security.  Moral debates are important; legal ones as well.  But it's important that critics of the wall also have the tools to explain why we aren't \"soft\" on security, but actually take it quite seriously. 23/",
      "expandedUrl" : "https://twitter.com/i/web/status/1092650727963590656"
    }
  },
  {
    "like" : {
      "tweetId" : "1092650722490044416",
      "fullText" : "Hi. So I'm back online and thanks for all these responses.  I was rushed when I wrote this so I think I'm allowed to continue because in the responses it occurred to me that the basic tenets of security were relatively new to folks and I\"ll try to arm you all with what I know 17/",
      "expandedUrl" : "https://twitter.com/i/web/status/1092650722490044416"
    }
  },
  {
    "like" : {
      "tweetId" : "1092530235105525760",
      "fullText" : "So let's assume you have 100 pennies to spend across competing priorities.  And so let's say you want ALL of them to be spent on border enforcement (not sure how your constituencies would feel about that).   8/",
      "expandedUrl" : "https://twitter.com/i/web/status/1092530235105525760"
    }
  },
  {
    "like" : {
      "tweetId" : "1092530242193903616",
      "fullText" : "And as a graduate of Harvard, your odd mentions of it in every tweet to me (this is the first time I have mentioned it) suggests its a dig. I'm sorry you feel that way about what you may or may not have learned here. We try to teach responsible bipartisan leadership.  13/",
      "expandedUrl" : "https://twitter.com/i/web/status/1092530242193903616"
    }
  },
  {
    "like" : {
      "tweetId" : "1092650724394221568",
      "fullText" : "But there is also a second tenet for how we think about complex security challenges: layered security.  The basic goal here is to ensure that you don't build a system around, what we call, a \"single point of failure.\" 19/",
      "expandedUrl" : "https://twitter.com/i/web/status/1092650724394221568"
    }
  },
  {
    "like" : {
      "tweetId" : "1092650725220515846",
      "fullText" : "A \"single point of failure\" is to be avoided at all costs because if it is penetrated, then the whole system goes down.  9/11 and cockpit doors; Sony hack and a single system administrator; BP oil spill and a blowout preventer.  So, ideally we build systems that have multiple 20/",
      "expandedUrl" : "https://twitter.com/i/web/status/1092650725220515846"
    }
  },
  {
    "like" : {
      "tweetId" : "1092526183919570949",
      "fullText" : "On substance, I think you know the answer.  And if you listened to the one person who is your colleague and who actually knows the border (and is from your party), you would understand why the dynamics of border security are fluid and require a layered, not static, response. 2/",
      "expandedUrl" : "https://twitter.com/i/web/status/1092526183919570949"
    }
  },
  {
    "like" : {
      "tweetId" : "1092530244878245888",
      "fullText" : "Support your point with facts, history, economics and policy.  Not with mocking a woman.  Because, well, she is me.  And you will lose that one.  16/16",
      "expandedUrl" : "https://twitter.com/i/web/status/1092530244878245888"
    }
  },
  {
    "like" : {
      "tweetId" : "1092530236015681536",
      "fullText" : "How would you spend them? No one, not even CBP until last few months, ever even thought a wall made sense because it would take years (tell me how that solves a crisis, but as you know there isn't one), require eminent domain (your Texas colleagues have thoughts on that), and 9/",
      "expandedUrl" : "https://twitter.com/i/web/status/1092530236015681536"
    }
  },
  {
    "like" : {
      "tweetId" : "1092530236892295168",
      "fullText" : "would pull from the dynamic security that does work.  So that us \"experts\" oppose the wall is just an unbecoming comment.  Us experts include your Republican colleagues and those of us who have worked border issues in government.  And, again, CBP.  10/",
      "expandedUrl" : "https://twitter.com/i/web/status/1092530236892295168"
    }
  },
  {
    "like" : {
      "tweetId" : "1092530234363207681",
      "fullText" : "alternative with a static solution.  So I suspect you get this but I\"m happy to explain.  On process, though, you are the congressman.  And you know that your job is to weigh priorities with funding.  7/",
      "expandedUrl" : "https://twitter.com/i/web/status/1092530234363207681"
    }
  },
  {
    "like" : {
      "tweetId" : "1085498662447394817",
      "fullText" : "- a journalist went to cover a story about a shelter for abandoned dogs . That beautiful and innocent puppy, wanting affection and a home , grabbed him with his legs .. \nthe journalist , adopted him ❤️ https://t.co/pEzpYAip8i",
      "expandedUrl" : "https://twitter.com/i/web/status/1085498662447394817"
    }
  },
  {
    "like" : {
      "tweetId" : "1092650729628680193",
      "fullText" : "I'm not known for being soft on security, border or otherwise.  And so in the realm of policy options, the wall fails every standard that we have learned in homeland security for the last 20 years.  Now, I say good night. 25/25",
      "expandedUrl" : "https://twitter.com/i/web/status/1092650729628680193"
    }
  },
  {
    "like" : {
      "tweetId" : "1092530239933161474",
      "fullText" : "I wasn't going to re-engage it.  I don't want to be know as the \"expert\" who accused you of mansplaining any more than you want to be known for an SNL skit.  It's not why we do what we do; it's personal and I took to heart what you said in response to the SNL skit. Civility. 12/",
      "expandedUrl" : "https://twitter.com/i/web/status/1092530239933161474"
    }
  },
  {
    "like" : {
      "tweetId" : "974978856997224448",
      "fullText" : "When the full extent of your venality, moral turpitude, and political corruption becomes known, you will take your rightful place as a disgraced demagogue in the dustbin of history. You may scapegoat Andy McCabe, but you will  not destroy America...America will triumph over you. https://t.co/uKppoDbduj",
      "expandedUrl" : "https://twitter.com/i/web/status/974978856997224448"
    }
  },
  {
    "like" : {
      "tweetId" : "873328974188826624",
      "fullText" : "All 213 Beatles Songs, Ranked From Worst to Best https://t.co/8uDiSsXkLm via @instapaper",
      "expandedUrl" : "https://twitter.com/i/web/status/873328974188826624"
    }
  },
  {
    "like" : {
      "tweetId" : "898164423411605504",
      "fullText" : "I collected some recent threads about Eurocentric music ed, hip-hop and Nazi Twitter here: https://t.co/eg83GlAs3Z",
      "expandedUrl" : "https://twitter.com/i/web/status/898164423411605504"
    }
  },
  {
    "like" : {
      "tweetId" : "897525895715573761",
      "fullText" : "Yesterday's long thread about white supremacy in music ed got the attention of the Twitter Nazis. Hurray.",
      "expandedUrl" : "https://twitter.com/i/web/status/897525895715573761"
    }
  },
  {
    "like" : {
      "tweetId" : "1045522659386314753",
      "fullText" : "NEWS: The American Bar Association—whose “well qualified” rating has been cited by Kavanaugh—calls on the Senate to delay a vote on his SCOTUS nomination until after the @FBI conducts a background check on the Ford allegations. https://t.co/UAbmT1kKqh",
      "expandedUrl" : "https://twitter.com/i/web/status/1045522659386314753"
    }
  },
  {
    "like" : {
      "tweetId" : "954807991785611264",
      "fullText" : "here is my entire “A Story Like Mine” poem from today’s #WomensMarch2018 in NYC tw: rape / assault. Thank you. https://t.co/l3fji73woM",
      "expandedUrl" : "https://twitter.com/i/web/status/954807991785611264"
    }
  },
  {
    "like" : {
      "tweetId" : "897561998485057536",
      "fullText" : "OMG. What did we just watch? He blamed the anti-racism protesters. He likened George Washington to Robert E. Lee. Donald. Trump. Fuck. You.",
      "expandedUrl" : "https://twitter.com/i/web/status/897561998485057536"
    }
  },
  {
    "like" : {
      "tweetId" : "857483886879797248",
      "fullText" : "Welcome to Latvian citizenship Mikhail Baryshnikov! It's great to have you with us!\nhttps://t.co/ndYgPV1wTb",
      "expandedUrl" : "https://twitter.com/i/web/status/857483886879797248"
    }
  },
  {
    "like" : {
      "tweetId" : "899689748779982849",
      "fullText" : "You notice how quiet @DonaldJTrumpJr has been lately? Talk about a total eclipse of the son! \nhttps://t.co/hHq6G2zpZL",
      "expandedUrl" : "https://twitter.com/i/web/status/899689748779982849"
    }
  },
  {
    "like" : {
      "tweetId" : "873586842456797185",
      "fullText" : "These kids have dreams &amp; they will turn them into songs. Love 2 @nyumusedlab 4 hosting &amp; @guitarmashnyc 4 organizing. https://t.co/mGWpia32dQ",
      "expandedUrl" : "https://twitter.com/i/web/status/873586842456797185"
    }
  },
  {
    "like" : {
      "tweetId" : "858062648587558912",
      "fullText" : "The reason that guy sitting a few seats away from me at the cafe looked so much like John Turturro is that he was John Turturro.",
      "expandedUrl" : "https://twitter.com/i/web/status/858062648587558912"
    }
  },
  {
    "like" : {
      "tweetId" : "1032792308511596546",
      "fullText" : "@CornelWest Thank you brother West. 🙏 #brotherwest #cornelwest #cnn #AndersonCooper",
      "expandedUrl" : "https://twitter.com/i/web/status/1032792308511596546"
    }
  },
  {
    "like" : {
      "tweetId" : "914920182740541440",
      "fullText" : "I don't care how long it took, I am glad for these words. We need more like @Calebkeeter, so pls speak out. We can all be on the same side. https://t.co/twuF8xs0Vn",
      "expandedUrl" : "https://twitter.com/i/web/status/914920182740541440"
    }
  },
  {
    "like" : {
      "tweetId" : "915068359363973121",
      "fullText" : "RIP, Tom Petty. His death has been confirmed by the Los Angeles Times.\n\nA great musician who will be sorely missed by millions of Americans. https://t.co/5CSWJ09qqK",
      "expandedUrl" : "https://twitter.com/i/web/status/915068359363973121"
    }
  },
  {
    "like" : {
      "tweetId" : "899624247236190210",
      "fullText" : "Bob Dylan remembers rockabilly legend Roland Janes\nhttps://t.co/hCpZk12rkk",
      "expandedUrl" : "https://twitter.com/i/web/status/899624247236190210"
    }
  },
  {
    "like" : {
      "tweetId" : "954825915703242753",
      "fullText" : "So, yeah, after all these months, I’m still not welcome at #WomensMarch2018 etc. (For now). But I support you!!! https://t.co/IMlRx1PmUV",
      "expandedUrl" : "https://twitter.com/i/web/status/954825915703242753"
    }
  },
  {
    "like" : {
      "tweetId" : "873313123784175616",
      "fullText" : ".@ReneLopez sharing his journey as a songwriter with #gmteens @GuitarMashNYC Teen Songwriting Circle @NYUMusicEd https://t.co/OqgTv4wM6k",
      "expandedUrl" : "https://twitter.com/i/web/status/873313123784175616"
    }
  },
  {
    "like" : {
      "tweetId" : "913761731297517568",
      "fullText" : "Great new video about the @NASA_Orion Exploration Mission-1 (EM-1): https://t.co/utisO23W9N",
      "expandedUrl" : "https://twitter.com/i/web/status/913761731297517568"
    }
  },
  {
    "like" : {
      "tweetId" : "867074370568679424",
      "fullText" : "Great show @CleanGreenMM! Educating about #climatechange through music with students in Lawrence, MA. Learn more at https://t.co/YWbFSnWRg7 https://t.co/nshNPbS1uW",
      "expandedUrl" : "https://twitter.com/i/web/status/867074370568679424"
    }
  },
  {
    "like" : {
      "tweetId" : "915074359412133888",
      "fullText" : "\"I wanna write her name in the sky\nI'm gonna free fall out into nothing\nGonna leave this world for a while\" Rest in peace Tom Petty 💔",
      "expandedUrl" : "https://twitter.com/i/web/status/915074359412133888"
    }
  },
  {
    "like" : {
      "tweetId" : "889940108341805056",
      "fullText" : "Dear makers of music production tools: I know \"master/slave\" is a conventional term, but it's time to find a new one.",
      "expandedUrl" : "https://twitter.com/i/web/status/889940108341805056"
    }
  },
  {
    "like" : {
      "tweetId" : "899660323690598404",
      "fullText" : "Legend talking legend. @bobdylan https://t.co/9barFWYlFY",
      "expandedUrl" : "https://twitter.com/i/web/status/899660323690598404"
    }
  },
  {
    "like" : {
      "tweetId" : "897577010003947520",
      "fullText" : "Thank you @produceramadeus for all of your support! 🙏 we appreciate you and can't wait to build… https://t.co/3FU2ApOOT1",
      "expandedUrl" : "https://twitter.com/i/web/status/897577010003947520"
    }
  },
  {
    "like" : {
      "tweetId" : "914951908439314432",
      "fullText" : "The guitarist for the Josh Abbott band: \"I've been a proponent of the 2nd amendment my entire life. Until the events of last night.\" https://t.co/a6wuj0RLcC",
      "expandedUrl" : "https://twitter.com/i/web/status/914951908439314432"
    }
  },
  {
    "like" : {
      "tweetId" : "893499273844805632",
      "fullText" : "What are the potential benefits of #biosimilars for the U.S. marketplace? https://t.co/ib6G1lrJXC https://t.co/TzEvswwsRe",
      "expandedUrl" : "https://twitter.com/i/web/status/893499273844805632"
    }
  },
  {
    "like" : {
      "tweetId" : "834086084850176000",
      "fullText" : "Explore the science of the microphone for #eweek2017 using a free TeachRock #PBS @soundbreaking lesson https://t.co/m4TQgVYVAM @DiscoverEorg https://t.co/2LUvEPWvCP",
      "expandedUrl" : "https://twitter.com/i/web/status/834086084850176000"
    }
  },
  {
    "like" : {
      "tweetId" : "832720876944494592",
      "fullText" : "E. B. White on the beauty of a free press, from a letter in 1976. https://t.co/2dw4VtVIHO https://t.co/dJM3NKgvhY",
      "expandedUrl" : "https://twitter.com/i/web/status/832720876944494592"
    }
  },
  {
    "like" : {
      "tweetId" : "832449724049338368",
      "fullText" : "“I inherited a mess.” - @realdonaldtrump #LSSC https://t.co/o6DMHKlIAV",
      "expandedUrl" : "https://twitter.com/i/web/status/832449724049338368"
    }
  },
  {
    "like" : {
      "tweetId" : "832908222491136000",
      "fullText" : "I know Nike wants to sell shoes but I like the varied Muslim women's representation here - complication is good https://t.co/EI4mHLVJ0r",
      "expandedUrl" : "https://twitter.com/i/web/status/832908222491136000"
    }
  },
  {
    "like" : {
      "tweetId" : "833310204104175616",
      "fullText" : "For LA’s growing legion of fashionable, social media-savvy hipsters, the event was catnip. https://t.co/p60fdieEv3",
      "expandedUrl" : "https://twitter.com/i/web/status/833310204104175616"
    }
  },
  {
    "like" : {
      "tweetId" : "836761703538909185",
      "fullText" : "Couldn't fathom anything worse than watching that talking pile of human feces be applauded by the most spineless cowards in our government.",
      "expandedUrl" : "https://twitter.com/i/web/status/836761703538909185"
    }
  },
  {
    "like" : {
      "tweetId" : "832791830664146947",
      "fullText" : "Trump simply has to be impeached. We can't be made to endure this for four years. These past 29 days have been enough.",
      "expandedUrl" : "https://twitter.com/i/web/status/832791830664146947"
    }
  },
  {
    "like" : {
      "tweetId" : "836311839235538944",
      "fullText" : ".@reckoner165 compares a Penderecki score to its spectrogram. That was a good idea. https://t.co/jIi14VUWui",
      "expandedUrl" : "https://twitter.com/i/web/status/836311839235538944"
    }
  },
  {
    "like" : {
      "tweetId" : "835584884965945345",
      "fullText" : "What to wear to the resistance. https://t.co/8n3B462t3T #resistance #shepersisted #whattowear #womensmarch #marching #resist",
      "expandedUrl" : "https://twitter.com/i/web/status/835584884965945345"
    }
  },
  {
    "like" : {
      "tweetId" : "845721600498397184",
      "fullText" : "making magic and building with our friends from @dream_yard @foundsoundnat @urbanartbeat… https://t.co/JV3Mt69KAK",
      "expandedUrl" : "https://twitter.com/i/web/status/845721600498397184"
    }
  },
  {
    "like" : {
      "tweetId" : "836754999409590274",
      "fullText" : "Somebody please tell me Dr. Ben Carson isn't the Designated Survivor tonight.",
      "expandedUrl" : "https://twitter.com/i/web/status/836754999409590274"
    }
  },
  {
    "like" : {
      "tweetId" : "836074170266103808",
      "fullText" : "Amy Adams and her golden orbs. ☺Loving all the gold and silver. #Oscars #AmyAdams https://t.co/TbctAJngYa",
      "expandedUrl" : "https://twitter.com/i/web/status/836074170266103808"
    }
  },
  {
    "like" : {
      "tweetId" : "834095634751844354",
      "fullText" : "Read my new post, \"Do These Ten Things and Trump Will Be Toast.\" My 10-point Action Plan to stop @realDonaldTrump. https://t.co/IN1pYtwDVQ",
      "expandedUrl" : "https://twitter.com/i/web/status/834095634751844354"
    }
  },
  {
    "like" : {
      "tweetId" : "833196122478931968",
      "fullText" : "Looks like a great core workout. https://t.co/O7bLJsyqvu",
      "expandedUrl" : "https://twitter.com/i/web/status/833196122478931968"
    }
  },
  {
    "like" : {
      "tweetId" : "833861138412609536",
      "fullText" : "Intricate web of glaciers amidst majestic Himalayan peaks. https://t.co/Pb4aVCpcBJ",
      "expandedUrl" : "https://twitter.com/i/web/status/833861138412609536"
    }
  },
  {
    "like" : {
      "tweetId" : "833362623802519553",
      "fullText" : "Take some comfort, America. At least our Secretary of Defense does not have dictatorial tendencies and is not insane. https://t.co/hGdEWgFhV3",
      "expandedUrl" : "https://twitter.com/i/web/status/833362623802519553"
    }
  },
  {
    "like" : {
      "tweetId" : "836576562623430656",
      "fullText" : "It follows the trope of 'live is always better' but there is also so much more that you *get* about the music when you see people do it.",
      "expandedUrl" : "https://twitter.com/i/web/status/836576562623430656"
    }
  },
  {
    "like" : {
      "tweetId" : "844896595179180034",
      "fullText" : "My heart goes out to the victims and their families in London. No act of terror can shake the strength and resilience of our British ally.",
      "expandedUrl" : "https://twitter.com/i/web/status/844896595179180034"
    }
  },
  {
    "like" : {
      "tweetId" : "832717936401883137",
      "fullText" : "Only a FAKE PRESIDENT would declare the First Amendment to be the enemy of the American people. https://t.co/ZFZvlTf8Az",
      "expandedUrl" : "https://twitter.com/i/web/status/832717936401883137"
    }
  },
  {
    "like" : {
      "tweetId" : "834171947432808448",
      "fullText" : "It was a very emotional evening in Christchurch. A lot of powerful healing energy going in both directions. https://t.co/CG9Efl1rg0",
      "expandedUrl" : "https://twitter.com/i/web/status/834171947432808448"
    }
  },
  {
    "like" : {
      "tweetId" : "832964533681582080",
      "fullText" : "Journalists, I know you will not be bullied or intimidated. Keep doing your job. Your country depends on you. https://t.co/94xIMScmp0",
      "expandedUrl" : "https://twitter.com/i/web/status/832964533681582080"
    }
  },
  {
    "like" : {
      "tweetId" : "833089064551096320",
      "fullText" : "When you listen to Trump right now, remember he is the most unpopular newly elected President in modern history. Your resistance is working",
      "expandedUrl" : "https://twitter.com/i/web/status/833089064551096320"
    }
  },
  {
    "like" : {
      "tweetId" : "845768727589273602",
      "fullText" : "Yay! I made this cut. Thank you @AARP #disruptaging #over50 #fashionblogger #midlife #savvy https://t.co/faDD7s1oe6",
      "expandedUrl" : "https://twitter.com/i/web/status/845768727589273602"
    }
  },
  {
    "like" : {
      "tweetId" : "838950851767062528",
      "fullText" : "😂 https://t.co/BMVAP6V63d",
      "expandedUrl" : "https://twitter.com/i/web/status/838950851767062528"
    }
  },
  {
    "like" : {
      "tweetId" : "832724853346033666",
      "fullText" : "Conservatives, feel free to speak up for the Constitution anytime the mood strikes. It is time. https://t.co/0mfHUQ03yO",
      "expandedUrl" : "https://twitter.com/i/web/status/832724853346033666"
    }
  },
  {
    "like" : {
      "tweetId" : "831136494203105280",
      "fullText" : "Custom Cement Bricks, Originally crafted on site and derived from the landscape. https://t.co/7WTfXjR5Gx https://t.co/O0lI9Mf4CG",
      "expandedUrl" : "https://twitter.com/i/web/status/831136494203105280"
    }
  },
  {
    "like" : {
      "tweetId" : "830569374004211712",
      "fullText" : "Betsy DeVos' Dept of Education took down a website for disabled children--info on Individuals with Disabilities Educ Act is now gone. #Shame",
      "expandedUrl" : "https://twitter.com/i/web/status/830569374004211712"
    }
  },
  {
    "like" : {
      "tweetId" : "830943255114240002",
      "fullText" : "Ella! #EllaFitzgerald #GRAMMYs #womenworking #ShePersisted https://t.co/ICOWPpmeD6",
      "expandedUrl" : "https://twitter.com/i/web/status/830943255114240002"
    }
  },
  {
    "like" : {
      "tweetId" : "832411540636712962",
      "fullText" : "Really, Little Jared complaining about me cuz I get under President Daddy-in-Law's skin? Oh, baby boy, I'm so sorry. https://t.co/4W8Sh9sHxy",
      "expandedUrl" : "https://twitter.com/i/web/status/832411540636712962"
    }
  },
  {
    "like" : {
      "tweetId" : "830091088958521346",
      "fullText" : "Bunch of ladies on the R train just started harmonizing along with the acapella gospel buskers. Love NYC at times like this.",
      "expandedUrl" : "https://twitter.com/i/web/status/830091088958521346"
    }
  },
  {
    "like" : {
      "tweetId" : "830464067399741440",
      "fullText" : "tfw you bite into a delicious bagel, only to realize that it too is an actant fully deployed in the world",
      "expandedUrl" : "https://twitter.com/i/web/status/830464067399741440"
    }
  },
  {
    "like" : {
      "tweetId" : "830826236389777408",
      "fullText" : "Wise words from @FrankBruni to Ds: Protest &amp; process aren't enough; clear vision &amp; fresh voices matter. https://t.co/MMUIUMlfIM NYTimes: Are",
      "expandedUrl" : "https://twitter.com/i/web/status/830826236389777408"
    }
  },
  {
    "like" : {
      "tweetId" : "830233648356016129",
      "fullText" : "This is a brilliant passage. https://t.co/5NkUdiHji7 https://t.co/6fq72kvPmj",
      "expandedUrl" : "https://twitter.com/i/web/status/830233648356016129"
    }
  },
  {
    "like" : {
      "tweetId" : "832487241909825536",
      "fullText" : "Seriously. That was 12 hrs ago &amp; I can't get 2 sleep! Am I not alone on this? The whole country should have a hard time sleeping tonight...",
      "expandedUrl" : "https://twitter.com/i/web/status/832487241909825536"
    }
  },
  {
    "like" : {
      "tweetId" : "832626779818950656",
      "fullText" : "Look! 💃💃💃 https://t.co/gS8UimKxwZ",
      "expandedUrl" : "https://twitter.com/i/web/status/832626779818950656"
    }
  },
  {
    "like" : {
      "tweetId" : "830465205683503108",
      "fullText" : "So good I had to come back- best place to chillax on a Phoenix morning (@ Ocotillo) #Yelp #Yelfie https://t.co/NEnWiEG6NE https://t.co/gMOJjHhcGl",
      "expandedUrl" : "https://twitter.com/i/web/status/830465205683503108"
    }
  },
  {
    "like" : {
      "tweetId" : "832318288575229957",
      "fullText" : "#BeatRhyme legend Kid Lucky &amp; @KailaMullady of @NorthCoastNYC want to see you at the American Human #Beatbox Fest: https://t.co/wZB4rjKAc5 https://t.co/GqNibsvGpn",
      "expandedUrl" : "https://twitter.com/i/web/status/832318288575229957"
    }
  },
  {
    "like" : {
      "tweetId" : "830112045748084736",
      "fullText" : "Flynn's backtracking about his signals to Moscow has caught VP in Pence-down situation.  https://t.co/0nLljGAPWF",
      "expandedUrl" : "https://twitter.com/i/web/status/830112045748084736"
    }
  },
  {
    "like" : {
      "tweetId" : "830799429103935493",
      "fullText" : "Jackson is 7! https://t.co/47uzTjuj4j https://t.co/iI6mWg0wdl",
      "expandedUrl" : "https://twitter.com/i/web/status/830799429103935493"
    }
  },
  {
    "like" : {
      "tweetId" : "831169403995639809",
      "fullText" : "From Bacteria to Bach and Back by Daniel C Dennett review – consciousness explained? https://t.co/63mZyCzdQD via @instapaper",
      "expandedUrl" : "https://twitter.com/i/web/status/831169403995639809"
    }
  },
  {
    "like" : {
      "tweetId" : "822873393838039040",
      "fullText" : "I envy Republican senators. How often do people get a chance to be a hero without risking their lives? Be brave. Do the right thing.",
      "expandedUrl" : "https://twitter.com/i/web/status/822873393838039040"
    }
  },
  {
    "like" : {
      "tweetId" : "830782303030775808",
      "fullText" : "Oy. @ABCSharkTank &amp; @dallasmavs now on growing list of stuff President Loco compelling me to support...@Nordstrom, @Starbucks, @Oreo, @Delta https://t.co/T1IZ7wTH0f",
      "expandedUrl" : "https://twitter.com/i/web/status/830782303030775808"
    }
  },
  {
    "like" : {
      "tweetId" : "830594784863645699",
      "fullText" : "I CANNOT RETWEET THIS ENOUGH ❤❤ https://t.co/KpCTQjN8zz",
      "expandedUrl" : "https://twitter.com/i/web/status/830594784863645699"
    }
  },
  {
    "like" : {
      "tweetId" : "830806366323408898",
      "fullText" : "It's Sunday morning, must be Stereolab.",
      "expandedUrl" : "https://twitter.com/i/web/status/830806366323408898"
    }
  },
  {
    "like" : {
      "tweetId" : "829818984094654465",
      "fullText" : "\"I resent the implication that this administration is shamelessly plugging Ivanka Trump's clothing line.\" https://t.co/5IxEq0qz8e",
      "expandedUrl" : "https://twitter.com/i/web/status/829818984094654465"
    }
  },
  {
    "like" : {
      "tweetId" : "832486382576640002",
      "fullText" : "Never have I been unable 2 fall asleep simply because of watching a press conference. That was the most disturbing thing I've ever seen onTV",
      "expandedUrl" : "https://twitter.com/i/web/status/832486382576640002"
    }
  },
  {
    "like" : {
      "tweetId" : "830484260398178305",
      "fullText" : "30 years ago today I became a filmmaker.  On February 11, 1987, I began shooting \"Roger &amp; Me.\" Thanks to all of you who've supported me!",
      "expandedUrl" : "https://twitter.com/i/web/status/830484260398178305"
    }
  },
  {
    "like" : {
      "tweetId" : "832022765679017987",
      "fullText" : "How the Fashion World Is Getting Political and We LOVE It https://t.co/PYXqt51aOD via @bloglovin #politicalfashion #FashionWeek",
      "expandedUrl" : "https://twitter.com/i/web/status/832022765679017987"
    }
  },
  {
    "like" : {
      "tweetId" : "830623921674280960",
      "fullText" : "This powerful piece is well worth reading.  https://t.co/LfgFL1Gbco",
      "expandedUrl" : "https://twitter.com/i/web/status/830623921674280960"
    }
  },
  {
    "like" : {
      "tweetId" : "832013602857086985",
      "fullText" : "Susan! #susansontag https://t.co/R90zf7QL0i",
      "expandedUrl" : "https://twitter.com/i/web/status/832013602857086985"
    }
  },
  {
    "like" : {
      "tweetId" : "829518270432735234",
      "fullText" : "SLS rocket platform installations nearing completion @NASAKennedy's cavernous vehicle assembly building. Makes you feel tiny in comparison! https://t.co/OnmuVktRpx",
      "expandedUrl" : "https://twitter.com/i/web/status/829518270432735234"
    }
  },
  {
    "like" : {
      "tweetId" : "828396590675161088",
      "fullText" : "UH, NEW FAVORITE ONLINE MUSIC MAKING GAME/TOOL?!\n\nGROOVEPIZZA https://t.co/TQRUfxAlzQ",
      "expandedUrl" : "https://twitter.com/i/web/status/828396590675161088"
    }
  },
  {
    "like" : {
      "tweetId" : "827535639465824258",
      "fullText" : "1. DECLARATION OF RESISTANCE\n\nWhen in the course of American history it becomes necessary for the people to save our Nation from a Tyrant,",
      "expandedUrl" : "https://twitter.com/i/web/status/827535639465824258"
    }
  },
  {
    "like" : {
      "tweetId" : "828765285142388737",
      "fullText" : "A follower told me since phone calls not getting thru, he's been sending his Senator pizzas w/messages written in pepperoni. 🍕😂🍕",
      "expandedUrl" : "https://twitter.com/i/web/status/828765285142388737"
    }
  },
  {
    "like" : {
      "tweetId" : "829842545719009280",
      "fullText" : "The trick is to uphold the security of the nation and the Constitution at the same time.",
      "expandedUrl" : "https://twitter.com/i/web/status/829842545719009280"
    }
  },
  {
    "like" : {
      "tweetId" : "828002567607029761",
      "fullText" : "What is our country coming to?\n\nIts senses. https://t.co/6fPKvP8gEf",
      "expandedUrl" : "https://twitter.com/i/web/status/828002567607029761"
    }
  },
  {
    "like" : {
      "tweetId" : "829502158945054722",
      "fullText" : "There’s no Rule 19 to silence me from talking about Jeff Sessions anymore. So let me say loudly &amp; clearly: This is just the beginning.",
      "expandedUrl" : "https://twitter.com/i/web/status/829502158945054722"
    }
  },
  {
    "like" : {
      "tweetId" : "827917892641497090",
      "fullText" : "#TeachRock founder @StevieVanZandt, #DaveGrohl and #WhoopiGoldberg discuss The Beatles and American culture in the 1960s. https://t.co/gl3a9q4AMa",
      "expandedUrl" : "https://twitter.com/i/web/status/827917892641497090"
    }
  },
  {
    "like" : {
      "tweetId" : "828744137499373568",
      "fullText" : "Proud of our #American tech companies! #technology #MadeInAmerica #pride #Resistance https://t.co/oakagWoEcP",
      "expandedUrl" : "https://twitter.com/i/web/status/828744137499373568"
    }
  },
  {
    "like" : {
      "tweetId" : "827627599002292224",
      "fullText" : "Eminem unleashes on President Trump: \"I'll make his whole brand go under\" https://t.co/LxIVNHs3dj https://t.co/828VhM0DdR",
      "expandedUrl" : "https://twitter.com/i/web/status/827627599002292224"
    }
  },
  {
    "like" : {
      "tweetId" : "829887489317990400",
      "fullText" : "Holy crap. A white, Christian woman. From Tennessee. Pushing for single payer. Via Medicaid expansion. She even knew the Aetna scam. #WOW https://t.co/AboGqU9NKh",
      "expandedUrl" : "https://twitter.com/i/web/status/829887489317990400"
    }
  },
  {
    "like" : {
      "tweetId" : "829885989392879616",
      "fullText" : "We officially have a million Twitter followers! LIterally could not do it without you all.",
      "expandedUrl" : "https://twitter.com/i/web/status/829885989392879616"
    }
  },
  {
    "like" : {
      "tweetId" : "827993217522073600",
      "fullText" : "We have a winner https://t.co/oM5WKh7VCI",
      "expandedUrl" : "https://twitter.com/i/web/status/827993217522073600"
    }
  },
  {
    "like" : {
      "tweetId" : "829799815387181058",
      "fullText" : "You tell 'em, girl. https://t.co/at2BCQaazI",
      "expandedUrl" : "https://twitter.com/i/web/status/829799815387181058"
    }
  },
  {
    "like" : {
      "tweetId" : "829502383533260801",
      "fullText" : "If Jeff Sessions turns a blind eye while @realDonaldTrump violates the Constitution or breaks the law, he'll hear from all of us.",
      "expandedUrl" : "https://twitter.com/i/web/status/829502383533260801"
    }
  },
  {
    "like" : {
      "tweetId" : "828413665883914240",
      "fullText" : "A new low in keytar history.",
      "expandedUrl" : "https://twitter.com/i/web/status/828413665883914240"
    }
  },
  {
    "like" : {
      "tweetId" : "829692403191787521",
      "fullText" : "W/every new tweet, Trump confirms he doesn't care about being presidential, ethical, truthful or sane. It's all about his baby-skinned ego.",
      "expandedUrl" : "https://twitter.com/i/web/status/829692403191787521"
    }
  },
  {
    "like" : {
      "tweetId" : "828070571644694528",
      "fullText" : "Thank you, So-Called President Trump! I've been struggling for 2 weeks over what to call you, and your tweet here gave us the answer. https://t.co/HVf3oSWYum",
      "expandedUrl" : "https://twitter.com/i/web/status/828070571644694528"
    }
  },
  {
    "like" : {
      "tweetId" : "829846072415703041",
      "fullText" : "We have been saying this for a while. https://t.co/JFpVlTYUZm",
      "expandedUrl" : "https://twitter.com/i/web/status/829846072415703041"
    }
  },
  {
    "like" : {
      "tweetId" : "829502924460011520",
      "fullText" : "And you better believe every Senator who voted to put Jeff Sessions’s radical hatred into @TheJusticeDept will hear from all of us, too.",
      "expandedUrl" : "https://twitter.com/i/web/status/829502924460011520"
    }
  },
  {
    "like" : {
      "tweetId" : "829689481523507200",
      "fullText" : "They are https://t.co/IEDE7E4Nks",
      "expandedUrl" : "https://twitter.com/i/web/status/829689481523507200"
    }
  },
  {
    "like" : {
      "tweetId" : "827916063803375616",
      "fullText" : "Bringing #Beyonce into the classroom with a well-researched TeachRock #lessonplan is a meaningful way to celebrate #BlackHistoryMonth ! https://t.co/82VkkiWNBS",
      "expandedUrl" : "https://twitter.com/i/web/status/827916063803375616"
    }
  },
  {
    "like" : {
      "tweetId" : "828236034907447296",
      "fullText" : "Unshakeable resolve. #resist https://t.co/ra8lYdK3af",
      "expandedUrl" : "https://twitter.com/i/web/status/828236034907447296"
    }
  },
  {
    "like" : {
      "tweetId" : "828994456938504192",
      "fullText" : "I wish I really understood even one thing",
      "expandedUrl" : "https://twitter.com/i/web/status/828994456938504192"
    }
  },
  {
    "like" : {
      "tweetId" : "829886211883929600",
      "fullText" : "The majority has come alive! https://t.co/iHzcuf8h52",
      "expandedUrl" : "https://twitter.com/i/web/status/829886211883929600"
    }
  },
  {
    "like" : {
      "tweetId" : "825817449211760640",
      "fullText" : "There is something more important and powerful than all three branches of government. It is you – the people. #BatteryPark https://t.co/FXVHlahxHB",
      "expandedUrl" : "https://twitter.com/i/web/status/825817449211760640"
    }
  },
  {
    "like" : {
      "tweetId" : "826576281584168960",
      "fullText" : "Thank you, random Norwegian,for your hypothetical sacrifice https://t.co/Z52rDRqWVL",
      "expandedUrl" : "https://twitter.com/i/web/status/826576281584168960"
    }
  },
  {
    "like" : {
      "tweetId" : "826220501819412480",
      "fullText" : "Incredible scene here at the Supreme Court. This is what America is about- standing together for all faiths, families, and backgrounds. https://t.co/vCUV13hNiB",
      "expandedUrl" : "https://twitter.com/i/web/status/826220501819412480"
    }
  },
  {
    "like" : {
      "tweetId" : "826924107459473408",
      "fullText" : "America’s New Resistance https://t.co/BYBnZKHLLe via @instapaper",
      "expandedUrl" : "https://twitter.com/i/web/status/826924107459473408"
    }
  },
  {
    "like" : {
      "tweetId" : "828226974011256832",
      "fullText" : "Still my favorite sign from the #WomensMarch. https://t.co/aqop4MjU3g",
      "expandedUrl" : "https://twitter.com/i/web/status/828226974011256832"
    }
  },
  {
    "like" : {
      "tweetId" : "826186747369230336",
      "fullText" : "What So Many People Don’t Get About the U.S. Working Class https://t.co/Ftj8MJ7uDe via @instapaper",
      "expandedUrl" : "https://twitter.com/i/web/status/826186747369230336"
    }
  },
  {
    "like" : {
      "tweetId" : "827335825910353920",
      "fullText" : "It's dark, but we must also notice the small victories. Today the head of Uber, after 1000s deleted its app, stepped down fr Trump's council",
      "expandedUrl" : "https://twitter.com/i/web/status/827335825910353920"
    }
  },
  {
    "like" : {
      "tweetId" : "825690039950639105",
      "fullText" : "As my grandfather, Navy veteran Everett Palmatier used to say, \"what to expect from a pig, but a grunt?\"",
      "expandedUrl" : "https://twitter.com/i/web/status/825690039950639105"
    }
  },
  {
    "like" : {
      "tweetId" : "828251889993150464",
      "fullText" : "I love my city! #ilovenewyork #handsanitizer #getreal #LoveTrumpsHate https://t.co/ODNkLlgulT",
      "expandedUrl" : "https://twitter.com/i/web/status/828251889993150464"
    }
  },
  {
    "like" : {
      "tweetId" : "825731297700093953",
      "fullText" : "Blogging again; Join me https://t.co/rvxP0Ju1Tk",
      "expandedUrl" : "https://twitter.com/i/web/status/825731297700093953"
    }
  },
  {
    "like" : {
      "tweetId" : "825825910830034944",
      "fullText" : "Supported Greater Boston Food Bank today!  Check out https://t.co/Hg3MxAffdM.  #endinghunger",
      "expandedUrl" : "https://twitter.com/i/web/status/825825910830034944"
    }
  },
  {
    "like" : {
      "tweetId" : "825837061466886145",
      "fullText" : "Would love a YC-style accelerator program for young people running for office, w/YC level mentors, execs, $$$. Batch could be ready in 2018!",
      "expandedUrl" : "https://twitter.com/i/web/status/825837061466886145"
    }
  },
  {
    "like" : {
      "tweetId" : "827290042376806400",
      "fullText" : "While resisting fascism I've also managed to resist sleep, laundry, showering, and vegetables",
      "expandedUrl" : "https://twitter.com/i/web/status/827290042376806400"
    }
  },
  {
    "like" : {
      "tweetId" : "825491488884813825",
      "fullText" : "#resistance is very important without resistors your computer breaks and bad things happen so remember to always #resist https://t.co/uwY3L2wKAK",
      "expandedUrl" : "https://twitter.com/i/web/status/825491488884813825"
    }
  },
  {
    "like" : {
      "tweetId" : "826566587234684928",
      "fullText" : "I’ve got news for all you liberals who think all the marching and protesting is making  difference.\n\nIt is. https://t.co/i6RL8JJNsk",
      "expandedUrl" : "https://twitter.com/i/web/status/826566587234684928"
    }
  },
  {
    "like" : {
      "tweetId" : "826948779127480320",
      "fullText" : "Reuters offers guidelines on \"Covering Trump the Reuters Way\"\n\n https://t.co/JQZWqEArkm",
      "expandedUrl" : "https://twitter.com/i/web/status/826948779127480320"
    }
  },
  {
    "like" : {
      "tweetId" : "825511640854622209",
      "fullText" : "I have ordered the Port Authority to reverse its decision regarding the JFK AirTrain. The people of New York will have their voices heard. https://t.co/zwGOYgzQPg",
      "expandedUrl" : "https://twitter.com/i/web/status/825511640854622209"
    }
  },
  {
    "like" : {
      "tweetId" : "826152254130552834",
      "fullText" : "On virtually every major issue, Trump represents a minority of Americans. Our job now is to bring the majority together and fight back.",
      "expandedUrl" : "https://twitter.com/i/web/status/826152254130552834"
    }
  },
  {
    "like" : {
      "tweetId" : "825469347867029510",
      "fullText" : "Outside of Terminal 4 at JFK, while lawyers fight on the inside, the protests have EXPLODED in size demanding justice for the detained... https://t.co/lKcrBg5IOD",
      "expandedUrl" : "https://twitter.com/i/web/status/825469347867029510"
    }
  },
  {
    "like" : {
      "tweetId" : "826920398604300289",
      "fullText" : "How Kellyanne Conway became the greatest spin doctor in modern American history https://t.co/9ySEsOB5zz via @instapaper",
      "expandedUrl" : "https://twitter.com/i/web/status/826920398604300289"
    }
  },
  {
    "like" : {
      "tweetId" : "825518044537618433",
      "fullText" : "I'm 20 minutes from landing at JFK. Pilot just warned us about delays due to #NoBan protests at T4. \n\nThe passengers' response? \n\nApplause.",
      "expandedUrl" : "https://twitter.com/i/web/status/825518044537618433"
    }
  },
  {
    "like" : {
      "tweetId" : "826176920945438720",
      "fullText" : "Autocracy: Rules for Survival https://t.co/lGp2eyiyBV",
      "expandedUrl" : "https://twitter.com/i/web/status/826176920945438720"
    }
  },
  {
    "like" : {
      "tweetId" : "826913623272464391",
      "fullText" : "Heard of Kickstarter Live? Surprise! There's a @mattervc company behind it all. Kickstarter acquires Huzza: https://t.co/QTaT9qu5tl",
      "expandedUrl" : "https://twitter.com/i/web/status/826913623272464391"
    }
  },
  {
    "like" : {
      "tweetId" : "827892526598209537",
      "fullText" : "The opinion of this so-called President, does not reflect or respect co-equal judicial branch of government in our country, is ridiculous! https://t.co/tIFYo4Pobs",
      "expandedUrl" : "https://twitter.com/i/web/status/827892526598209537"
    }
  },
  {
    "like" : {
      "tweetId" : "825830249095114754",
      "fullText" : "God bless Chris Wallace for not interrupting this spectacular Kellyanne Conway meltdown. https://t.co/83lZm5Ylem",
      "expandedUrl" : "https://twitter.com/i/web/status/825830249095114754"
    }
  },
  {
    "like" : {
      "tweetId" : "823184974392266753",
      "fullText" : "I think the best part of the joyous Women’s March was just the aggressive reminder that we live in THIS world, too.",
      "expandedUrl" : "https://twitter.com/i/web/status/823184974392266753"
    }
  },
  {
    "like" : {
      "tweetId" : "823311415947759616",
      "fullText" : ".@PARISDENNARD says \"it would be ridiculous\" not to trust @seanspicer because it was 1st presser.  He lied ... repeatedly &amp; on purpose. @CNN",
      "expandedUrl" : "https://twitter.com/i/web/status/823311415947759616"
    }
  },
  {
    "like" : {
      "tweetId" : "823210956562006018",
      "fullText" : "If you *know* that an anti-fascist rally is the ‘wrong place’ for you, then you are clear on what you’re advocating. https://t.co/OkJcGWPinH",
      "expandedUrl" : "https://twitter.com/i/web/status/823210956562006018"
    }
  },
  {
    "like" : {
      "tweetId" : "825410270675746818",
      "fullText" : "Congratulations, Trump, my outrage at your illegal and immoral actions has overcome my crippling social anxiety disorder. Calling EVERYBODY.",
      "expandedUrl" : "https://twitter.com/i/web/status/825410270675746818"
    }
  },
  {
    "like" : {
      "tweetId" : "822933529931563008",
      "fullText" : "Train spotted just outside Washington  DC Union Station. Graffiti may be back. Defending America. 👊👊👊👊👊 https://t.co/fpjMFpqk2C",
      "expandedUrl" : "https://twitter.com/i/web/status/822933529931563008"
    }
  },
  {
    "like" : {
      "tweetId" : "825402370079203328",
      "fullText" : "Trump is a big mistake.",
      "expandedUrl" : "https://twitter.com/i/web/status/825402370079203328"
    }
  },
  {
    "like" : {
      "tweetId" : "823311576992096258",
      "fullText" : "Enough, @cnn!\n@PARISDENNARD's 'point of view' is beyond believable. A paid 'Trump' supporter, his 'argument' is nonsense!\n@CNNnewsroom",
      "expandedUrl" : "https://twitter.com/i/web/status/823311576992096258"
    }
  },
  {
    "like" : {
      "tweetId" : "825394357066989569",
      "fullText" : "Fuck each and every one of these \"leaders.\" What a bunch of cowards. https://t.co/HqOr3XMCgC",
      "expandedUrl" : "https://twitter.com/i/web/status/825394357066989569"
    }
  },
  {
    "like" : {
      "tweetId" : "825471462865780736",
      "fullText" : "I think this makes @justinamash the third Republican to find his voice. Hope others wake-up from the stupor and follow suit. https://t.co/HwZViwBvq5",
      "expandedUrl" : "https://twitter.com/i/web/status/825471462865780736"
    }
  },
  {
    "like" : {
      "tweetId" : "823199061381672962",
      "fullText" : "I feel like #WokeBaby just gave us something powerful here but our third eye ain't ready for the truth https://t.co/0FJJqsrtli",
      "expandedUrl" : "https://twitter.com/i/web/status/823199061381672962"
    }
  },
  {
    "like" : {
      "tweetId" : "824963590121742336",
      "fullText" : "\"I wish this was fake news\"\n#womensmarch #nycwomensmarch https://t.co/7k1G7MUeWn https://t.co/SAy37DUsTY",
      "expandedUrl" : "https://twitter.com/i/web/status/824963590121742336"
    }
  },
  {
    "like" : {
      "tweetId" : "823184384559878144",
      "fullText" : "\"Alternative facts are not facts. They are falsehoods,\" Chuck Todd tells Pres. Trump's counselor Kellyanne Conway this morning. WATCH: https://t.co/Ao005dQ13r",
      "expandedUrl" : "https://twitter.com/i/web/status/823184384559878144"
    }
  },
  {
    "like" : {
      "tweetId" : "825122558492151808",
      "fullText" : "That's more like it https://t.co/tRffECObuf",
      "expandedUrl" : "https://twitter.com/i/web/status/825122558492151808"
    }
  },
  {
    "like" : {
      "tweetId" : "822999376750583808",
      "fullText" : "It was the year 2017 and things had gone full cyberpunk https://t.co/gd7PCEBHZ2",
      "expandedUrl" : "https://twitter.com/i/web/status/822999376750583808"
    }
  },
  {
    "like" : {
      "tweetId" : "823217819928133635",
      "fullText" : "Day 1 of Trump Administration: ACLU demands documents related to Trump's conflicts of interest. Add your name: https://t.co/gUiiT6pkUO",
      "expandedUrl" : "https://twitter.com/i/web/status/823217819928133635"
    }
  },
  {
    "like" : {
      "tweetId" : "825553863432425473",
      "fullText" : "A young refugee fleeing religious persecution came to the US decades ago. He's Sergey Brin, co-founder @Google. He's at #sfoprotest https://t.co/gOfOTkKZQZ",
      "expandedUrl" : "https://twitter.com/i/web/status/825553863432425473"
    }
  },
  {
    "like" : {
      "tweetId" : "825480885571092480",
      "fullText" : "In other cities, go to your Airport's international terminal now. Show @realDonaldTrump who the majority is! We didn't vote for this bigot.",
      "expandedUrl" : "https://twitter.com/i/web/status/825480885571092480"
    }
  },
  {
    "like" : {
      "tweetId" : "825479846360915971",
      "fullText" : "Homeland Security now detaining 11 innocent Muslims inside JFK Terminal 4. Everybody peacefully to JFK! Term 4!! Shut this place down!",
      "expandedUrl" : "https://twitter.com/i/web/status/825479846360915971"
    }
  },
  {
    "like" : {
      "tweetId" : "825469507615481856",
      "fullText" : "I've made an effort to keep a civil and high minded tone in my online presence and Trump has reduced me to constant swearing in a week.",
      "expandedUrl" : "https://twitter.com/i/web/status/825469507615481856"
    }
  },
  {
    "like" : {
      "tweetId" : "825469054571933696",
      "fullText" : "Mr President, kindly go fuck yourself https://t.co/36xoSsONcw",
      "expandedUrl" : "https://twitter.com/i/web/status/825469054571933696"
    }
  },
  {
    "like" : {
      "tweetId" : "823263336599027716",
      "fullText" : "@alexruthmann I've been using it in wkshops for this https://t.co/qTFbpnMal1 and in larger projects: love export options &amp; Soundtrap link",
      "expandedUrl" : "https://twitter.com/i/web/status/823263336599027716"
    }
  },
  {
    "like" : {
      "tweetId" : "825422265634402306",
      "fullText" : "We're en route to join the protest at JFK Terminal 4. The resistance will be livetweeted. #MuslimBan #MuslimBanprotest",
      "expandedUrl" : "https://twitter.com/i/web/status/825422265634402306"
    }
  },
  {
    "like" : {
      "tweetId" : "825470818129936384",
      "fullText" : "The NYC Taxi Workers just called for a work stoppage, starting at 6 pm. No pick ups or drop offs to JFK.",
      "expandedUrl" : "https://twitter.com/i/web/status/825470818129936384"
    }
  },
  {
    "like" : {
      "tweetId" : "825502182204198912",
      "fullText" : "Cadman Plaza, Brooklyn. #NoBanNoWall https://t.co/KghvNEGGsB",
      "expandedUrl" : "https://twitter.com/i/web/status/825502182204198912"
    }
  },
  {
    "like" : {
      "tweetId" : "823311245252161537",
      "fullText" : "Sincere question to @PARISDENNARD - is there anything that Donald Trump or his team could do that you would object to? Anything at all.",
      "expandedUrl" : "https://twitter.com/i/web/status/823311245252161537"
    }
  },
  {
    "like" : {
      "tweetId" : "822932025296515073",
      "fullText" : "\"Freedom is in peril.  Defend it with all your might.\" #WomensMarchOakland https://t.co/xBcWhf18OK",
      "expandedUrl" : "https://twitter.com/i/web/status/822932025296515073"
    }
  },
  {
    "like" : {
      "tweetId" : "822913268834598916",
      "fullText" : "@justinhendrix https://t.co/Tq933BS4Me",
      "expandedUrl" : "https://twitter.com/i/web/status/822913268834598916"
    }
  },
  {
    "like" : {
      "tweetId" : "822967774993678340",
      "fullText" : "#womensmarch Protest signs left behind as memorials... #nyc https://t.co/DRgsyiAz5m",
      "expandedUrl" : "https://twitter.com/i/web/status/822967774993678340"
    }
  },
  {
    "like" : {
      "tweetId" : "822858041846624256",
      "fullText" : "the british womens march signs are definitely my favourite https://t.co/ToXGmadxbB",
      "expandedUrl" : "https://twitter.com/i/web/status/822858041846624256"
    }
  },
  {
    "like" : {
      "tweetId" : "823162978405122048",
      "fullText" : "Because my liberation is bound to my students' liberation: One thing that I have learned from critical... https://t.co/5LE7gcT7qe",
      "expandedUrl" : "https://twitter.com/i/web/status/823162978405122048"
    }
  },
  {
    "like" : {
      "tweetId" : "822949229161222152",
      "fullText" : "Grand Central is flooded with people who are STILL coming to #WomensMarch #NYC https://t.co/nhyp5pTgVr",
      "expandedUrl" : "https://twitter.com/i/web/status/822949229161222152"
    }
  },
  {
    "like" : {
      "tweetId" : "822851628071993344",
      "fullText" : "It's OFFICIAL #WomensMarchOnWashington is biggest inaugural protest in HISTORY. Sorry Mr. Trump, THIS is what a populist movement looks like https://t.co/mREzlQnUAy",
      "expandedUrl" : "https://twitter.com/i/web/status/822851628071993344"
    }
  },
  {
    "like" : {
      "tweetId" : "822932581863882756",
      "fullText" : "I was teaching a music production while y'all were protesting, but I called Trump \"that motherfucker\" throughout if that helps",
      "expandedUrl" : "https://twitter.com/i/web/status/822932581863882756"
    }
  },
  {
    "like" : {
      "tweetId" : "822932264560553984",
      "fullText" : "#WomensMarchOakland https://t.co/7bDdmFDEPK",
      "expandedUrl" : "https://twitter.com/i/web/status/822932264560553984"
    }
  },
  {
    "like" : {
      "tweetId" : "822952244278689793",
      "fullText" : "Watch the @NAMMTECAwards live online tonight! #TECAwards #groovepizza #audioeducation https://t.co/lWhDyUVB6u",
      "expandedUrl" : "https://twitter.com/i/web/status/822952244278689793"
    }
  },
  {
    "like" : {
      "tweetId" : "822949826841182208",
      "fullText" : "\"No Hate, no fear, immigrants are welcome here.\" #womensmarch #nyc #nycwomensmarch https://t.co/xBx5WJjXAa",
      "expandedUrl" : "https://twitter.com/i/web/status/822949826841182208"
    }
  },
  {
    "like" : {
      "tweetId" : "822820336198713348",
      "fullText" : "Pink pussy hats and posters arriving at Grand Central #womensmarch https://t.co/U2o10kIJFE",
      "expandedUrl" : "https://twitter.com/i/web/status/822820336198713348"
    }
  },
  {
    "like" : {
      "tweetId" : "822926767358754816",
      "fullText" : "Awesome sign at Women's March NYC, Grand Central Station. [pic by @mikemermin] https://t.co/2ciozdTCjn",
      "expandedUrl" : "https://twitter.com/i/web/status/822926767358754816"
    }
  },
  {
    "like" : {
      "tweetId" : "823023872798814208",
      "fullText" : "Really folks, today's #WomensMarch was at least twice size of Trump Inaugural. Though, we all been told, it's not the size that matters...",
      "expandedUrl" : "https://twitter.com/i/web/status/823023872798814208"
    }
  },
  {
    "like" : {
      "tweetId" : "822846096653385729",
      "fullText" : "New York City #WomensMarch https://t.co/PGiwjOdKXg",
      "expandedUrl" : "https://twitter.com/i/web/status/822846096653385729"
    }
  },
  {
    "like" : {
      "tweetId" : "822922129637330944",
      "fullText" : "This guy has it straight! #WomensMarchOnWashington https://t.co/Mi9Jgc8H7Q",
      "expandedUrl" : "https://twitter.com/i/web/status/822922129637330944"
    }
  },
  {
    "like" : {
      "tweetId" : "823024264177709056",
      "fullText" : "#GroovePizza brought to you by @ethanhein @adamjnovember @kevinirlen @mindofmatthew @HarshiniJK @hill @artseducation @yciw and @MusEDLab",
      "expandedUrl" : "https://twitter.com/i/web/status/823024264177709056"
    }
  },
  {
    "like" : {
      "tweetId" : "823163575355244546",
      "fullText" : "Day One of the #resistance. Took us 5 years to get numbers this big against G.W. Bush. Only 24 hours against Trump. https://t.co/h6RMm5bkkn",
      "expandedUrl" : "https://twitter.com/i/web/status/823163575355244546"
    }
  },
  {
    "like" : {
      "tweetId" : "822964179493617664",
      "fullText" : "A big thank you to the organizers and the men and women of the NYPD for keeping 400,000 New Yorkers safe during today's #WomensMarchNYC. https://t.co/vkGharcQqk",
      "expandedUrl" : "https://twitter.com/i/web/status/822964179493617664"
    }
  },
  {
    "like" : {
      "tweetId" : "822968486536347648",
      "fullText" : "America in Revolt today! DC:1M; LA: 750Kj NYC: 250K; Seattle: 200K; Boston: 125K+; Denver: 100K+ Over 300 other citIes... How many millions?",
      "expandedUrl" : "https://twitter.com/i/web/status/822968486536347648"
    }
  },
  {
    "like" : {
      "tweetId" : "823039686205706241",
      "fullText" : "#NYC #womensmarch Signs left behind for others to read and add to https://t.co/ZyUNemAjPv https://t.co/y36vUp1fa4",
      "expandedUrl" : "https://twitter.com/i/web/status/823039686205706241"
    }
  },
  {
    "like" : {
      "tweetId" : "823046754123780097",
      "fullText" : "Voting is over. This is the winner. https://t.co/TaKp6VLWWB",
      "expandedUrl" : "https://twitter.com/i/web/status/823046754123780097"
    }
  },
  {
    "like" : {
      "tweetId" : "823179089586569216",
      "fullText" : "\"Alternative facts\"??? Is that the new name for those things we used to call, \"lies\"? https://t.co/AmJRVRyC7j",
      "expandedUrl" : "https://twitter.com/i/web/status/823179089586569216"
    }
  },
  {
    "like" : {
      "tweetId" : "822823632770633729",
      "fullText" : "Streets are packed! Metro subway jammed!!! Amazing. #WomensMarch",
      "expandedUrl" : "https://twitter.com/i/web/status/822823632770633729"
    }
  },
  {
    "like" : {
      "tweetId" : "822997959746981888",
      "fullText" : "So, we're doing this again next week, right?",
      "expandedUrl" : "https://twitter.com/i/web/status/822997959746981888"
    }
  }
]