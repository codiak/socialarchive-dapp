window.YTD.device_token.part0 = [
  {
    "deviceToken" : {
      "clientApplicationId" : "3033300",
      "token" : "GMFne6i3u26GW5MAek02fYKtfdKQy3fZzTwOpBmz",
      "createdAt" : "2022-01-17T12:50:33.324Z",
      "lastSeenAt" : "2022-01-17T12:50:33.326Z",
      "clientApplicationName" : "Twitter Web App (Twitter. Inc)"
    }
  }
]