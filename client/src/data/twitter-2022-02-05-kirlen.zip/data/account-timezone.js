window.YTD.account_timezone.part0 = [
  {
    "accountTimezone" : {
      "accountId" : "43527072",
      "timeZone" : "Eastern Time (US & Canada)"
    }
  }
]