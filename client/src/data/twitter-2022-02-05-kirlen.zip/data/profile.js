window.YTD.profile.part0 = [
  {
    "profile" : {
      "description" : {
        "bio" : "software developer, musician",
        "website" : "https://t.co/IPsvoY4jsR",
        "location" : "New York City"
      },
      "avatarMediaUrl" : "https://pbs.twimg.com/profile_images/1483539661859561472/sHsDFLCV.jpg"
    }
  }
]