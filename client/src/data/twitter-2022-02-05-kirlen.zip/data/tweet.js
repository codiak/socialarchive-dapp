window.YTD.tweet.part0 = [
  {
    "tweet" : {
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Crowd Fusion",
            "screen_name" : "crowdfusion",
            "indices" : [
              "3",
              "15"
            ],
            "id_str" : "8515252",
            "id" : "8515252"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "id_str" : "38232220686753792",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "38232220686753792",
      "created_at" : "Thu Feb 17 13:44:06 +0000 2011",
      "favorited" : false,
      "full_text" : "RT @crowdfusion: Correction: Crowd Fusion CEO Brian Alvey will be live on The Big Web Show Episode 39, TODAY Feb. 17th at 12PM ET http:/ ...",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "retweeted" : false,
      "source" : "<a href=\"https://dev.twitter.com/docs/tfw\" rel=\"nofollow\">Twitter for Websites</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "TechCrunch",
            "screen_name" : "TechCrunch",
            "indices" : [
              "102",
              "113"
            ],
            "id_str" : "816653",
            "id" : "816653"
          }
        ],
        "urls" : [
          {
            "url" : "http://t.co/yvsGXtH",
            "expanded_url" : "http://tcrn.ch/fHMDk0",
            "display_url" : "tcrn.ch/fHMDk0",
            "indices" : [
              "78",
              "97"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "113"
      ],
      "favorite_count" : "0",
      "id_str" : "37927190175678464",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "37927190175678464",
      "possibly_sensitive" : false,
      "created_at" : "Wed Feb 16 17:32:01 +0000 2011",
      "favorited" : false,
      "full_text" : "What Do TMZ And The Daily Have In Common?  Both Are Published On Crowd Fusion http://t.co/yvsGXtH via @techcrunch",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Crowd Fusion",
            "screen_name" : "crowdfusion",
            "indices" : [
              "3",
              "15"
            ],
            "id_str" : "8515252",
            "id" : "8515252"
          }
        ],
        "urls" : [
          {
            "url" : "http://t.co/Va0fgrC",
            "expanded_url" : "http://authjo.bz/j/7642",
            "display_url" : "authjo.bz/j/7642",
            "indices" : [
              "77",
              "96"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "96"
      ],
      "favorite_count" : "0",
      "id_str" : "37926177180106752",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "37926177180106752",
      "possibly_sensitive" : false,
      "created_at" : "Wed Feb 16 17:27:59 +0000 2011",
      "favorited" : false,
      "full_text" : "RT @crowdfusion: Are you a skilled Object Oriented Programmer? We're hiring! http://t.co/Va0fgrC",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "thedaily",
            "indices" : [
              "49",
              "58"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "58"
      ],
      "favorite_count" : "0",
      "id_str" : "32855352076668928",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "32855352076668928",
      "created_at" : "Wed Feb 02 17:38:21 +0000 2011",
      "favorited" : false,
      "full_text" : "Reading the first issue of The Daily on my iPad. #thedaily",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "85"
      ],
      "favorite_count" : "0",
      "id_str" : "14628807209",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "14628807209",
      "created_at" : "Mon May 24 15:07:34 +0000 2010",
      "favorited" : false,
      "full_text" : "Check out Incline and Favela Family - http://www.reverbnation.com/inclinefavelafamily",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "73"
      ],
      "favorite_count" : "0",
      "id_str" : "14628758406",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "14628758406",
      "created_at" : "Mon May 24 15:06:45 +0000 2010",
      "favorited" : false,
      "full_text" : "Check out Cape Cod Melody Tent - http://www.reverbnation.com/venue/336733",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Kevin Irlen",
            "screen_name" : "kevinirlen",
            "indices" : [
              "0",
              "11"
            ],
            "id_str" : "43527072",
            "id" : "43527072"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "86"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "8304808157",
      "id_str" : "8305223282",
      "in_reply_to_user_id" : "43527072",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "8305223282",
      "in_reply_to_status_id" : "8304808157",
      "created_at" : "Thu Jan 28 02:18:01 +0000 2010",
      "favorited" : false,
      "full_text" : "@kevinirlen I think he just hinted that THE issue is this bullshit political gridlock.",
      "lang" : "en",
      "in_reply_to_screen_name" : "kevinirlen",
      "in_reply_to_user_id_str" : "43527072"
    }
  },
  {
    "tweet" : {
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "18"
      ],
      "favorite_count" : "0",
      "id_str" : "8304808157",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "8304808157",
      "created_at" : "Thu Jan 28 02:05:12 +0000 2010",
      "favorited" : false,
      "full_text" : "Watching the SOTU.",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "id_str" : "4889776807",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "4889776807",
      "created_at" : "Thu Oct 15 14:35:04 +0000 2009",
      "favorited" : false,
      "full_text" : "On board SV Rhapsody. Back in the marina after being out since Sunday. May take the dinghy across to Pt Hospital for some more snorkeling...",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "56"
      ],
      "favorite_count" : "0",
      "id_str" : "4782435480",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "4782435480",
      "created_at" : "Sun Oct 11 11:29:13 +0000 2009",
      "favorited" : false,
      "full_text" : "Yikes! I'll scour bags and pockets when I get to Bocas..",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "138"
      ],
      "favorite_count" : "0",
      "id_str" : "4782421826",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "4782421826",
      "created_at" : "Sun Oct 11 11:27:44 +0000 2009",
      "favorited" : false,
      "full_text" : "Opened my wallet this morning to find my drivers license missing! Showed it back at Logan in addition to passport. Did they give it back??",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "59"
      ],
      "favorite_count" : "0",
      "id_str" : "4771590002",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "4771590002",
      "created_at" : "Sat Oct 10 23:31:44 +0000 2009",
      "favorited" : false,
      "full_text" : "Went to see the Mira Flores Locks\n http://twitpic.com/l1g9b",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "36"
      ],
      "favorite_count" : "0",
      "id_str" : "4771488580",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "4771488580",
      "created_at" : "Sat Oct 10 23:26:32 +0000 2009",
      "favorited" : false,
      "full_text" : "Fortunately, the hotel has wireless.",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "45"
      ],
      "favorite_count" : "0",
      "id_str" : "4771471170",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "4771471170",
      "created_at" : "Sat Oct 10 23:25:37 +0000 2009",
      "favorited" : false,
      "full_text" : "Got into Panama fine, but no phone service :(",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "id_str" : "4757824694",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "4757824694",
      "created_at" : "Sat Oct 10 09:55:22 +0000 2009",
      "favorited" : false,
      "full_text" : "Slept all the way to airport, sort of. Ate breakfast, found I didn't pack any vitamins after all! Hope that be my biggest packing mistake...",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "42"
      ],
      "favorite_count" : "0",
      "id_str" : "4725465131",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "4725465131",
      "created_at" : "Fri Oct 09 03:14:45 +0000 2009",
      "favorited" : false,
      "full_text" : "getting ready to go to visit Pat in Panama",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "27"
      ],
      "favorite_count" : "0",
      "id_str" : "1971183519",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1971183519",
      "created_at" : "Sat May 30 13:26:58 +0000 2009",
      "favorited" : false,
      "full_text" : "joining twitter, what else?",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Crowd Fusion",
            "screen_name" : "crowdfusion",
            "indices" : [
              "3",
              "15"
            ],
            "id_str" : "8515252",
            "id" : "8515252"
          }
        ],
        "urls" : [
          {
            "url" : "http://t.co/i97IGbUA",
            "expanded_url" : "http://su.pr/6RZn86",
            "display_url" : "su.pr/6RZn86",
            "indices" : [
              "65",
              "85"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "85"
      ],
      "favorite_count" : "0",
      "id_str" : "160100046321364993",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "160100046321364993",
      "possibly_sensitive" : false,
      "created_at" : "Thu Jan 19 20:43:20 +0000 2012",
      "favorited" : false,
      "full_text" : "RT @crowdfusion: Crowd Fusion Selected as SIIA Previews Finalist http://t.co/i97IGbUA",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Dan Burbank",
            "screen_name" : "AstroCoastie",
            "indices" : [
              "0",
              "13"
            ],
            "id_str" : "277020058",
            "id" : "277020058"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "49"
      ],
      "favorite_count" : "0",
      "id_str" : "141244746575265792",
      "in_reply_to_user_id" : "277020058",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "141244746575265792",
      "created_at" : "Mon Nov 28 19:59:06 +0000 2011",
      "favorited" : false,
      "full_text" : "@AstroCoastie Hey, Dan! How's it going out there?",
      "lang" : "en",
      "in_reply_to_screen_name" : "AstroCoastie",
      "in_reply_to_user_id_str" : "277020058"
    }
  },
  {
    "tweet" : {
      "retweeted" : false,
      "source" : "<a href=\"https://dev.twitter.com/docs/tfw\" rel=\"nofollow\">Twitter for Websites</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Kickstarter",
            "screen_name" : "Kickstarter",
            "indices" : [
              "89",
              "101"
            ],
            "id_str" : "16186995",
            "id" : "16186995"
          }
        ],
        "urls" : [
          {
            "url" : "http://t.co/edukXxBo",
            "expanded_url" : "http://kck.st/tyYOdL",
            "display_url" : "kck.st/tyYOdL",
            "indices" : [
              "102",
              "122"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "122"
      ],
      "favorite_count" : "0",
      "id_str" : "137537162420817921",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "137537162420817921",
      "possibly_sensitive" : false,
      "created_at" : "Fri Nov 18 14:26:29 +0000 2011",
      "favorited" : false,
      "full_text" : "Just backed Not Now, Ollie!  (a book about a bored Pug) by the awesome Jennifer Leach on @Kickstarter http://t.co/edukXxBo",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/#!/download/ipad\" rel=\"nofollow\">Twitter for iPad</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "donkey kong doug",
            "screen_name" : "imacdowell",
            "indices" : [
              "0",
              "11"
            ],
            "id_str" : "144643235",
            "id" : "144643235"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "18"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "131030522519486464",
      "id_str" : "131154363531010048",
      "in_reply_to_user_id" : "144643235",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "131154363531010048",
      "in_reply_to_status_id" : "131030522519486464",
      "created_at" : "Mon Oct 31 23:43:31 +0000 2011",
      "favorited" : false,
      "full_text" : "@imacdowell sweet!",
      "lang" : "en",
      "in_reply_to_screen_name" : "imacdowell",
      "in_reply_to_user_id_str" : "144643235"
    }
  },
  {
    "tweet" : {
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "donkey kong doug",
            "screen_name" : "imacdowell",
            "indices" : [
              "0",
              "11"
            ],
            "id_str" : "144643235",
            "id" : "144643235"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "36"
      ],
      "favorite_count" : "0",
      "id_str" : "131001348425646080",
      "in_reply_to_user_id" : "144643235",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "131001348425646080",
      "created_at" : "Mon Oct 31 13:35:30 +0000 2011",
      "favorited" : false,
      "full_text" : "@imacdowell So how is (was?) Hawaii?",
      "lang" : "en",
      "in_reply_to_screen_name" : "imacdowell",
      "in_reply_to_user_id_str" : "144643235"
    }
  },
  {
    "tweet" : {
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Crowd Fusion",
            "screen_name" : "crowdfusion",
            "indices" : [
              "3",
              "15"
            ],
            "id_str" : "8515252",
            "id" : "8515252"
          }
        ],
        "urls" : [
          {
            "url" : "http://t.co/z3QXrrUC",
            "expanded_url" : "http://su.pr/2hMFhG",
            "display_url" : "su.pr/2hMFhG",
            "indices" : [
              "83",
              "103"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "103"
      ],
      "favorite_count" : "0",
      "id_str" : "129267085489606656",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "129267085489606656",
      "possibly_sensitive" : false,
      "created_at" : "Wed Oct 26 18:44:09 +0000 2011",
      "favorited" : false,
      "full_text" : "RT @crowdfusion: Crowd Fusion is hiring Web Developers who are seeking innovation! http://t.co/z3QXrrUC",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "22"
      ],
      "favorite_count" : "0",
      "id_str" : "103479174756438016",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "103479174756438016",
      "created_at" : "Tue Aug 16 14:52:12 +0000 2011",
      "favorited" : false,
      "full_text" : "OH: I like grownups...",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "130"
      ],
      "favorite_count" : "0",
      "id_str" : "102241213146611713",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "102241213146611713",
      "created_at" : "Sat Aug 13 04:52:59 +0000 2011",
      "favorited" : false,
      "full_text" : "Saw anuther one! And could that be the ISS rising rapidly toward me in the southeast? The sky is so mysterious on a moonlit night.",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "22"
      ],
      "favorite_count" : "0",
      "id_str" : "102229076567265280",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "102229076567265280",
      "created_at" : "Sat Aug 13 04:04:45 +0000 2011",
      "favorited" : false,
      "full_text" : "I just saw a meteor :)",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "lauma solakis",
            "screen_name" : "laumasolakis",
            "indices" : [
              "0",
              "13"
            ],
            "id_str" : "26511337",
            "id" : "26511337"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "68"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "97382120414130176",
      "id_str" : "97448687726374912",
      "in_reply_to_user_id" : "26511337",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "97448687726374912",
      "in_reply_to_status_id" : "97382120414130176",
      "created_at" : "Sat Jul 30 23:29:12 +0000 2011",
      "favorited" : false,
      "full_text" : "@laumasolakis Anita says you always did have a great sense of humor!",
      "lang" : "en",
      "in_reply_to_screen_name" : "laumasolakis",
      "in_reply_to_user_id_str" : "26511337"
    }
  },
  {
    "tweet" : {
      "retweeted" : false,
      "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Brian Alvey",
            "screen_name" : "brianalvey",
            "indices" : [
              "0",
              "11"
            ],
            "id_str" : "4119021",
            "id" : "4119021"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "78"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "88609978402881536",
      "id_str" : "88614903446900737",
      "in_reply_to_user_id" : "4119021",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "88614903446900737",
      "in_reply_to_status_id" : "88609978402881536",
      "created_at" : "Wed Jul 06 14:26:54 +0000 2011",
      "favorited" : false,
      "full_text" : "@brianalvey omg, there it goes! you guys are the greatest! best b-day ever ;-)",
      "lang" : "en",
      "in_reply_to_screen_name" : "brianalvey",
      "in_reply_to_user_id_str" : "4119021"
    }
  },
  {
    "tweet" : {
      "retweeted" : false,
      "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Brian Alvey",
            "screen_name" : "brianalvey",
            "indices" : [
              "0",
              "11"
            ],
            "id_str" : "4119021",
            "id" : "4119021"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "129"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "88604379262877696",
      "id_str" : "88607455336087552",
      "in_reply_to_user_id" : "4119021",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "88607455336087552",
      "in_reply_to_status_id" : "88604379262877696",
      "created_at" : "Wed Jul 06 13:57:18 +0000 2011",
      "favorited" : false,
      "full_text" : "@brianalvey Um, we're at the beach on CC waiting for a Happy B-day flyover from the Crowd Fusion bi-plane. Is that not happening?",
      "lang" : "en",
      "in_reply_to_screen_name" : "brianalvey",
      "in_reply_to_user_id_str" : "4119021"
    }
  },
  {
    "tweet" : {
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Crowd Fusion",
            "screen_name" : "crowdfusion",
            "indices" : [
              "3",
              "15"
            ],
            "id_str" : "8515252",
            "id" : "8515252"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "id_str" : "83578250433007616",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "83578250433007616",
      "created_at" : "Wed Jun 22 16:53:02 +0000 2011",
      "favorited" : false,
      "full_text" : "RT @crowdfusion: We're looking for skilled Developers (PHP, OOP, HTML5, JavaScript, jQuery, MySQL), communicators & CMS experts! http:// ...",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Crowd Fusion",
            "screen_name" : "crowdfusion",
            "indices" : [
              "3",
              "15"
            ],
            "id_str" : "8515252",
            "id" : "8515252"
          }
        ],
        "urls" : [
          {
            "url" : "http://t.co/S5TEDgD",
            "expanded_url" : "http://newyork.craigslist.org/mnh/sof/2437595099.html",
            "display_url" : "newyork.craigslist.org/mnh/sof/243759…",
            "indices" : [
              "82",
              "101"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "101"
      ],
      "favorite_count" : "0",
      "id_str" : "80371666588405760",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "80371666588405760",
      "possibly_sensitive" : false,
      "created_at" : "Mon Jun 13 20:31:13 +0000 2011",
      "favorited" : false,
      "full_text" : "RT @crowdfusion: Are you an experienced technical writer? Crowd Fusion is hiring: http://t.co/S5TEDgD",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "C.K. Sample III",
            "screen_name" : "cksample",
            "indices" : [
              "3",
              "12"
            ],
            "id_str" : "804863",
            "id" : "804863"
          },
          {
            "name" : "YouTube",
            "screen_name" : "YouTube",
            "indices" : [
              "67",
              "75"
            ],
            "id_str" : "10228272",
            "id" : "10228272"
          }
        ],
        "urls" : [
          {
            "url" : "http://t.co/LmOBUd4",
            "expanded_url" : "http://www.youtube.com/watch?v=yV0zlKHjEvA&feature=share",
            "display_url" : "youtube.com/watch?v=yV0zlK…",
            "indices" : [
              "43",
              "62"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "75"
      ],
      "favorite_count" : "0",
      "id_str" : "80358195759026176",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "80358195759026176",
      "possibly_sensitive" : false,
      "created_at" : "Mon Jun 13 19:37:41 +0000 2011",
      "favorited" : false,
      "full_text" : "RT @cksample: me singing Believe it or not http://t.co/LmOBUd4 via @youtube",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "retweeted" : false,
      "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "68"
      ],
      "favorite_count" : "0",
      "id_str" : "68118985740259329",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "68118985740259329",
      "created_at" : "Wed May 11 01:03:26 +0000 2011",
      "favorited" : false,
      "full_text" : "OH: \"I'm the drink chick who used to drive all the pot chicks home.\"",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "retweeted" : false,
      "source" : "<a href=\"http://mobile.twitter.com\" rel=\"nofollow\">Mobile Web</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Daily",
            "screen_name" : "Daily",
            "indices" : [
              "24",
              "30"
            ],
            "id_str" : "213796133",
            "id" : "213796133"
          }
        ],
        "urls" : [
          {
            "url" : "http://t.co/pHondK0",
            "expanded_url" : "http://24ways.org/201009",
            "display_url" : "24ways.org/201009",
            "indices" : [
              "32",
              "51"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "51"
      ],
      "favorite_count" : "0",
      "id_str" : "67422515617734657",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "67422515617734657",
      "possibly_sensitive" : false,
      "created_at" : "Mon May 09 02:55:55 +0000 2011",
      "favorited" : false,
      "full_text" : "Extreme Design (thanks, @daily) http://t.co/pHondK0",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Crowd Fusion",
            "screen_name" : "crowdfusion",
            "indices" : [
              "3",
              "15"
            ],
            "id_str" : "8515252",
            "id" : "8515252"
          }
        ],
        "urls" : [
          {
            "url" : "http://t.co/R4BKF5V",
            "expanded_url" : "http://j.mp/fzVymM",
            "display_url" : "j.mp/fzVymM",
            "indices" : [
              "88",
              "107"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "107"
      ],
      "favorite_count" : "0",
      "id_str" : "58522223882936320",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "58522223882936320",
      "possibly_sensitive" : false,
      "created_at" : "Thu Apr 14 13:29:20 +0000 2011",
      "favorited" : false,
      "full_text" : "RT @crowdfusion: New Speakers for paidContent Mobile: Öhrvall, Caraeff, Harrison, Alvey http://t.co/R4BKF5V",
      "lang" : "de"
    }
  },
  {
    "tweet" : {
      "retweeted" : false,
      "source" : "<a href=\"https://dev.twitter.com/docs/tfw\" rel=\"nofollow\">Twitter for Websites</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "CMSWire.com",
            "screen_name" : "cmswire",
            "indices" : [
              "119",
              "127"
            ],
            "id_str" : "11104682",
            "id" : "11104682"
          }
        ],
        "urls" : [
          {
            "url" : "http://t.co/sMRSXN4",
            "expanded_url" : "http://www.cmswire.com/cms/web-cms/crowd-fusion-the-web-cms-behind-the-daily-010611.php",
            "display_url" : "cmswire.com/cms/web-cms/cr…",
            "indices" : [
              "95",
              "114"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "127"
      ],
      "favorite_count" : "0",
      "id_str" : "50241872614010880",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "50241872614010880",
      "possibly_sensitive" : false,
      "created_at" : "Tue Mar 22 17:06:10 +0000 2011",
      "favorited" : false,
      "full_text" : "What am I doing these days? I'm part of the team at Crowd Fusion: The Web CMS Behind The Daily http://t.co/sMRSXN4 via @cmswire",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Crowd Fusion",
            "screen_name" : "crowdfusion",
            "indices" : [
              "3",
              "15"
            ],
            "id_str" : "8515252",
            "id" : "8515252"
          }
        ],
        "urls" : [
          {
            "url" : "http://t.co/bxBKV4f",
            "expanded_url" : "http://www.crowdfusion.com/news/2011/03/16/crowd-fusion-announces-it-is-the-content-management-system-for-the-daily/",
            "display_url" : "crowdfusion.com/news/2011/03/1…",
            "indices" : [
              "105",
              "124"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "124"
      ],
      "favorite_count" : "0",
      "id_str" : "48116599336603648",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "48116599336603648",
      "possibly_sensitive" : false,
      "created_at" : "Wed Mar 16 20:21:05 +0000 2011",
      "favorited" : false,
      "full_text" : "RT @crowdfusion: Press Release: Crowd Fusion Announces it is the content management system for The Daily http://t.co/bxBKV4f",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "52"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "350057422859149312",
      "id_str" : "350070138797686784",
      "in_reply_to_user_id" : "792781716",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "350070138797686784",
      "in_reply_to_status_id" : "350057422859149312",
      "created_at" : "Thu Jun 27 01:56:39 +0000 2013",
      "favorited" : false,
      "full_text" : "@CHB_TVITD ok, I'll bite. what are we talking about?",
      "lang" : "en",
      "in_reply_to_screen_name" : "VoiceDarkness",
      "in_reply_to_user_id_str" : "792781716"
    }
  },
  {
    "tweet" : {
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Matter.",
            "screen_name" : "mattervc",
            "indices" : [
              "63",
              "72"
            ],
            "id_str" : "418837047",
            "id" : "418837047"
          }
        ],
        "urls" : [
          {
            "url" : "http://t.co/Wm28zGNkw0",
            "expanded_url" : "http://eepurl.com/A2591",
            "display_url" : "eepurl.com/A2591",
            "indices" : [
              "110",
              "132"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "132"
      ],
      "favorite_count" : "0",
      "id_str" : "346669153664524289",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "346669153664524289",
      "possibly_sensitive" : false,
      "created_at" : "Mon Jun 17 16:42:21 +0000 2013",
      "favorited" : false,
      "full_text" : "Up for a challenge? This has rocked my world. Applications for @mattervc are now open! Upcoming info session: http://t.co/Wm28zGNkw0",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "SpokenLayer",
            "screen_name" : "SpokenLayer",
            "indices" : [
              "3",
              "15"
            ],
            "id_str" : "339240135",
            "id" : "339240135"
          },
          {
            "name" : "Bonnier",
            "screen_name" : "bonnier",
            "indices" : [
              "65",
              "73"
            ],
            "id_str" : "87404064",
            "id" : "87404064"
          },
          {
            "name" : "SpokenLayer",
            "screen_name" : "SpokenLayer",
            "indices" : [
              "101",
              "113"
            ],
            "id_str" : "339240135",
            "id" : "339240135"
          }
        ],
        "urls" : [
          {
            "url" : "http://t.co/blYP76ad72",
            "expanded_url" : "http://www.bonnier.com/Growth-Media/rd/blog/2013/June/Mobile-Audio-Rising/",
            "display_url" : "bonnier.com/Growth-Media/r…",
            "indices" : [
              "74",
              "96"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "id_str" : "342701861876412416",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "342701861876412416",
      "possibly_sensitive" : false,
      "created_at" : "Thu Jun 06 17:57:45 +0000 2013",
      "favorited" : false,
      "full_text" : "RT @SpokenLayer: Mobile Audio Rising. Old Media in New Contexts. @bonnier http://t.co/blYP76ad72 How @SpokenLayer is helping publishers wit…",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Brian Alvey",
            "screen_name" : "brianalvey",
            "indices" : [
              "0",
              "11"
            ],
            "id_str" : "4119021",
            "id" : "4119021"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "122"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "335106041899520000",
      "id_str" : "336357319938039808",
      "in_reply_to_user_id" : "4119021",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "336357319938039808",
      "in_reply_to_status_id" : "335106041899520000",
      "created_at" : "Mon May 20 05:46:48 +0000 2013",
      "favorited" : false,
      "full_text" : "@brianalvey  surprise, mandatory interest payments on tech debt tend to come due at, ah, exponentially inconvenient times?",
      "lang" : "en",
      "in_reply_to_screen_name" : "brianalvey",
      "in_reply_to_user_id_str" : "4119021"
    }
  },
  {
    "tweet" : {
      "retweeted" : false,
      "source" : "<a href=\"http://www.apple.com\" rel=\"nofollow\">iOS</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "https://t.co/vmRdcCiea3",
            "expanded_url" : "https://openwatch.net/v/115",
            "display_url" : "openwatch.net/v/115",
            "indices" : [
              "37",
              "60"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "60"
      ],
      "favorite_count" : "0",
      "id_str" : "335878430321168384",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "335878430321168384",
      "possibly_sensitive" : false,
      "created_at" : "Sat May 18 22:03:52 +0000 2013",
      "favorited" : false,
      "full_text" : "beware of the lobster\nvia @OpenWatch https://t.co/vmRdcCiea3",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "retweeted" : false,
      "source" : "<a href=\"http://www.apple.com\" rel=\"nofollow\">Camera on iOS</a>",
      "entities" : {
        "user_mentions" : [
          {
            "name" : "Maker Faire",
            "screen_name" : "makerfaire",
            "indices" : [
              "0",
              "11"
            ],
            "id_str" : "1578141",
            "id" : "1578141"
          }
        ],
        "urls" : [ ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://twitter.com/kevinirlen/status/335850329830748160/photo/1",
            "indices" : [
              "12",
              "34"
            ],
            "url" : "http://t.co/qaZfUwqQHv",
            "media_url" : "http://pbs.twimg.com/media/BKkuGHeCcAAdWlV.jpg",
            "id_str" : "335850329834942464",
            "id" : "335850329834942464",
            "media_url_https" : "https://pbs.twimg.com/media/BKkuGHeCcAAdWlV.jpg",
            "sizes" : {
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "small" : {
                "w" : "510",
                "h" : "680",
                "resize" : "fit"
              },
              "large" : {
                "w" : "720",
                "h" : "960",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "720",
                "h" : "960",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/qaZfUwqQHv"
          }
        ],
        "hashtags" : [ ]
      },
      "display_text_range" : [
        "0",
        "34"
      ],
      "favorite_count" : "0",
      "id_str" : "335850329830748160",
      "in_reply_to_user_id" : "1578141",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "335850329830748160",
      "possibly_sensitive" : false,
      "created_at" : "Sat May 18 20:12:13 +0000 2013",
      "favorited" : false,
      "full_text" : "@makerfaire http://t.co/qaZfUwqQHv",
      "lang" : "und",
      "in_reply_to_screen_name" : "makerfaire",
      "in_reply_to_user_id_str" : "1578141",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://twitter.com/kevinirlen/status/335850329830748160/photo/1",
            "indices" : [
              "12",
              "34"
            ],
            "url" : "http://t.co/qaZfUwqQHv",
            "media_url" : "http://pbs.twimg.com/media/BKkuGHeCcAAdWlV.jpg",
            "id_str" : "335850329834942464",
            "id" : "335850329834942464",
            "media_url_https" : "https://pbs.twimg.com/media/BKkuGHeCcAAdWlV.jpg",
            "sizes" : {
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "small" : {
                "w" : "510",
                "h" : "680",
                "resize" : "fit"
              },
              "large" : {
                "w" : "720",
                "h" : "960",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "720",
                "h" : "960",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/qaZfUwqQHv"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "C.K. Sample III",
            "screen_name" : "cksample",
            "indices" : [
              "15",
              "24"
            ],
            "id_str" : "804863",
            "id" : "804863"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "53"
      ],
      "favorite_count" : "1",
      "in_reply_to_status_id_str" : "335079074819104768",
      "id_str" : "335106273244741632",
      "in_reply_to_user_id" : "23718842",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "335106273244741632",
      "in_reply_to_status_id" : "335079074819104768",
      "created_at" : "Thu May 16 18:55:36 +0000 2013",
      "favorited" : false,
      "full_text" : "@DavidJBallard @cksample OH in my head on occasion :)",
      "lang" : "en",
      "in_reply_to_user_id_str" : "23718842"
    }
  },
  {
    "tweet" : {
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Brian Alvey",
            "screen_name" : "brianalvey",
            "indices" : [
              "0",
              "11"
            ],
            "id_str" : "4119021",
            "id" : "4119021"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "16"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "335100577820340225",
      "id_str" : "335105610045591552",
      "in_reply_to_user_id" : "4119021",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "335105610045591552",
      "in_reply_to_status_id" : "335100577820340225",
      "created_at" : "Thu May 16 18:52:58 +0000 2013",
      "favorited" : false,
      "full_text" : "@brianalvey Hah!",
      "lang" : "und",
      "in_reply_to_screen_name" : "brianalvey",
      "in_reply_to_user_id_str" : "4119021"
    }
  },
  {
    "tweet" : {
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "makingof",
            "indices" : [
              "101",
              "110"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Zeega",
            "screen_name" : "Zeega",
            "indices" : [
              "3",
              "9"
            ],
            "id_str" : "356158929",
            "id" : "356158929"
          },
          {
            "name" : "SFMOMA",
            "screen_name" : "SFMOMA",
            "indices" : [
              "34",
              "41"
            ],
            "id_str" : "16536215",
            "id" : "16536215"
          },
          {
            "name" : "Zeega",
            "screen_name" : "Zeega",
            "indices" : [
              "68",
              "74"
            ],
            "id_str" : "356158929",
            "id" : "356158929"
          },
          {
            "name" : "The Kitchen Sisters",
            "screen_name" : "kitchensisters",
            "indices" : [
              "81",
              "96"
            ],
            "id_str" : "16459243",
            "id" : "16459243"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "144"
      ],
      "favorite_count" : "0",
      "id_str" : "335103054732988416",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "335103054732988416",
      "created_at" : "Thu May 16 18:42:48 +0000 2013",
      "favorited" : false,
      "full_text" : "RT @Zeega: Maker culture comes to @SFMOMA! Make the web you want w/ @zeega &amp; @kitchensisters for #makingof showcase in 2 wks! http://t.co/E…",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "retweeted" : false,
      "source" : "<a href=\"https://dev.twitter.com/docs/tfw\" rel=\"nofollow\">Twitter for Websites</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "http://t.co/a01TdYcdaa",
            "expanded_url" : "http://www.netnewscheck.com/article/25021/spokenlayer-taps-audios-potential-for-pubs#.UUc_gAshri0.twitter",
            "display_url" : "netnewscheck.com/article/25021/…",
            "indices" : [
              "44",
              "66"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "66"
      ],
      "favorite_count" : "1",
      "id_str" : "313687137130278912",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "313687137130278912",
      "possibly_sensitive" : false,
      "created_at" : "Mon Mar 18 16:23:36 +0000 2013",
      "favorited" : false,
      "full_text" : "SpokenLayer Taps Audio's Potential For Pubs http://t.co/a01TdYcdaa",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "124"
      ],
      "favorite_count" : "0",
      "id_str" : "310983169203638272",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "310983169203638272",
      "created_at" : "Mon Mar 11 05:18:59 +0000 2013",
      "favorited" : false,
      "full_text" : "upside to being knocked out by a cold for the past few days: read the classic Timeless Way of Building. thanks, @patkennel !",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Brian Alvey",
            "screen_name" : "brianalvey",
            "indices" : [
              "0",
              "11"
            ],
            "id_str" : "4119021",
            "id" : "4119021"
          },
          {
            "name" : "SpokenLayer",
            "screen_name" : "SpokenLayer",
            "indices" : [
              "53",
              "65"
            ],
            "id_str" : "339240135",
            "id" : "339240135"
          },
          {
            "name" : "Matter.",
            "screen_name" : "mattervc",
            "indices" : [
              "82",
              "91"
            ],
            "id_str" : "418837047",
            "id" : "418837047"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "118"
      ],
      "favorite_count" : "1",
      "in_reply_to_status_id_str" : "309379471985762304",
      "id_str" : "309394130079989763",
      "in_reply_to_user_id" : "4119021",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "309394130079989763",
      "in_reply_to_status_id" : "309379471985762304",
      "created_at" : "Wed Mar 06 20:04:43 +0000 2013",
      "favorited" : false,
      "full_text" : "@brianalvey super-excited about this (my new squeeze @spokenlayer and our mentors @mattervc -- not just the CF cameo!)",
      "lang" : "en",
      "in_reply_to_screen_name" : "brianalvey",
      "in_reply_to_user_id_str" : "4119021"
    }
  },
  {
    "tweet" : {
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "user_mentions" : [ ],
        "urls" : [ ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://twitter.com/kevinirlen/status/306089853257383936/photo/1",
            "indices" : [
              "16",
              "38"
            ],
            "url" : "http://t.co/9L09WNxOiF",
            "media_url" : "http://pbs.twimg.com/media/BD9zGY1CAAAwWn3.jpg",
            "id_str" : "306089853265772544",
            "id" : "306089853265772544",
            "media_url_https" : "https://pbs.twimg.com/media/BD9zGY1CAAAwWn3.jpg",
            "sizes" : {
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "medium" : {
                "w" : "768",
                "h" : "1024",
                "resize" : "fit"
              },
              "small" : {
                "w" : "510",
                "h" : "680",
                "resize" : "fit"
              },
              "large" : {
                "w" : "768",
                "h" : "1024",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/9L09WNxOiF"
          }
        ],
        "hashtags" : [ ]
      },
      "display_text_range" : [
        "0",
        "38"
      ],
      "favorite_count" : "0",
      "id_str" : "306089853257383936",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "306089853257383936",
      "possibly_sensitive" : false,
      "created_at" : "Mon Feb 25 17:14:42 +0000 2013",
      "favorited" : false,
      "full_text" : "first day in SF http://t.co/9L09WNxOiF",
      "lang" : "en",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://twitter.com/kevinirlen/status/306089853257383936/photo/1",
            "indices" : [
              "16",
              "38"
            ],
            "url" : "http://t.co/9L09WNxOiF",
            "media_url" : "http://pbs.twimg.com/media/BD9zGY1CAAAwWn3.jpg",
            "id_str" : "306089853265772544",
            "id" : "306089853265772544",
            "media_url_https" : "https://pbs.twimg.com/media/BD9zGY1CAAAwWn3.jpg",
            "sizes" : {
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "medium" : {
                "w" : "768",
                "h" : "1024",
                "resize" : "fit"
              },
              "small" : {
                "w" : "510",
                "h" : "680",
                "resize" : "fit"
              },
              "large" : {
                "w" : "768",
                "h" : "1024",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/9L09WNxOiF"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "retweeted" : false,
      "source" : "<a href=\"https://dev.twitter.com/docs/tfw\" rel=\"nofollow\">Twitter for Websites</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "C.K. Sample III",
            "screen_name" : "cksample",
            "indices" : [
              "0",
              "9"
            ],
            "id_str" : "804863",
            "id" : "804863"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "55"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "301701565503385601",
      "id_str" : "301702212541882370",
      "in_reply_to_user_id" : "804863",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "301702212541882370",
      "in_reply_to_status_id" : "301701565503385601",
      "created_at" : "Wed Feb 13 14:39:47 +0000 2013",
      "favorited" : false,
      "full_text" : "@cksample it's a little creepy - but loving the eyes...",
      "lang" : "en",
      "in_reply_to_screen_name" : "cksample",
      "in_reply_to_user_id_str" : "804863"
    }
  },
  {
    "tweet" : {
      "retweeted" : false,
      "source" : "<a href=\"https://dev.twitter.com/docs/tfw\" rel=\"nofollow\">Twitter for Websites</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Scott McNulty",
            "screen_name" : "blankbaby",
            "indices" : [
              "3",
              "13"
            ],
            "id_str" : "41693",
            "id" : "41693"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "133"
      ],
      "favorite_count" : "0",
      "id_str" : "282551548196835328",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "282551548196835328",
      "created_at" : "Sat Dec 22 18:21:53 +0000 2012",
      "favorited" : false,
      "full_text" : "RT @blankbaby: \"This is the beginning of a serious conversation. We won't be taking questions.\" Interesting use of conversation, NRA.",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Crowd Fusion",
            "screen_name" : "crowdfusion",
            "indices" : [
              "3",
              "15"
            ],
            "id_str" : "8515252",
            "id" : "8515252"
          }
        ],
        "urls" : [
          {
            "url" : "http://t.co/tzx7SXLj",
            "expanded_url" : "http://allthingsd.com/20120614/crowd-fusion-buys-ceros-and-changes-its-name-and-business-model/",
            "display_url" : "allthingsd.com/20120614/crowd…",
            "indices" : [
              "84",
              "104"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "104"
      ],
      "favorite_count" : "0",
      "id_str" : "213335429955596289",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "213335429955596289",
      "possibly_sensitive" : false,
      "created_at" : "Thu Jun 14 18:21:44 +0000 2012",
      "favorited" : false,
      "full_text" : "RT @crowdfusion: Crowd Fusion Buys Ceros — And Changes Its Name and Business Model  http://t.co/tzx7SXLj",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Crowd Fusion",
            "screen_name" : "crowdfusion",
            "indices" : [
              "3",
              "15"
            ],
            "id_str" : "8515252",
            "id" : "8515252"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "id_str" : "191979416988037120",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "191979416988037120",
      "created_at" : "Mon Apr 16 20:00:34 +0000 2012",
      "favorited" : false,
      "full_text" : "RT @crowdfusion: Congratulations to Essence on a well-deserved award. Crowd Fusion is proud to be working with their award-winning team! ...",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Crowd Fusion",
            "screen_name" : "crowdfusion",
            "indices" : [
              "3",
              "15"
            ],
            "id_str" : "8515252",
            "id" : "8515252"
          }
        ],
        "urls" : [
          {
            "url" : "http://t.co/rGFpt6VW",
            "expanded_url" : "http://su.pr/1PwUF8",
            "display_url" : "su.pr/1PwUF8",
            "indices" : [
              "91",
              "111"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "111"
      ],
      "favorite_count" : "0",
      "id_str" : "166887652669399041",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "166887652669399041",
      "possibly_sensitive" : false,
      "created_at" : "Tue Feb 07 14:14:51 +0000 2012",
      "favorited" : false,
      "full_text" : "RT @crowdfusion: Essence Music Festival website is now Crowd Fusion-powered! Check it out: http://t.co/rGFpt6VW",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "wnycsotu",
            "indices" : [
              "0",
              "9"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "79"
      ],
      "favorite_count" : "0",
      "id_str" : "161967427234701312",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "161967427234701312",
      "created_at" : "Wed Jan 25 00:23:38 +0000 2012",
      "favorited" : false,
      "full_text" : "#wnycsotu playing Jonathan Richman's 'We Need More Pa-Pa-Parties in the USA...'",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "retweeted" : false,
      "source" : "<a href=\"https://dev.twitter.com/docs/tfw\" rel=\"nofollow\">Twitter for Websites</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "ChooseIndependent",
            "indices" : [
              "55",
              "73"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "http://t.co/0nAfp9eb9t",
            "expanded_url" : "http://mzl.la/fx10",
            "display_url" : "mzl.la/fx10",
            "indices" : [
              "3",
              "25"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "138"
      ],
      "favorite_count" : "0",
      "id_str" : "538439203713851393",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "538439203713851393",
      "possibly_sensitive" : false,
      "created_at" : "Fri Nov 28 21:08:04 +0000 2014",
      "favorited" : false,
      "full_text" : "Is http://t.co/0nAfp9eb9t not a superb video ad by the #ChooseIndependent Mozilla folks depicting how sacred our web browsers have become?",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "user_mentions" : [
          {
            "name" : "Look For The Woman, Magazine",
            "screen_name" : "look4thewoman",
            "indices" : [
              "0",
              "14"
            ],
            "id_str" : "2442257604",
            "id" : "2442257604"
          }
        ],
        "urls" : [ ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://twitter.com/kevinirlen/status/532943585596170243/photo/1",
            "indices" : [
              "51",
              "73"
            ],
            "url" : "http://t.co/NAca7J2HTu",
            "media_url" : "http://pbs.twimg.com/media/B2VlUXLCcAALaLy.jpg",
            "id_str" : "532943531405373440",
            "id" : "532943531405373440",
            "media_url_https" : "https://pbs.twimg.com/media/B2VlUXLCcAALaLy.jpg",
            "sizes" : {
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "large" : {
                "w" : "1024",
                "h" : "768",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "1024",
                "h" : "768",
                "resize" : "fit"
              },
              "small" : {
                "w" : "680",
                "h" : "510",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/NAca7J2HTu"
          }
        ],
        "hashtags" : [ ]
      },
      "display_text_range" : [
        "0",
        "73"
      ],
      "favorite_count" : "1",
      "id_str" : "532943585596170243",
      "in_reply_to_user_id" : "2442257604",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "532943585596170243",
      "possibly_sensitive" : false,
      "created_at" : "Thu Nov 13 17:10:27 +0000 2014",
      "favorited" : false,
      "full_text" : "@look4thewoman care to comment on this dog's look? http://t.co/NAca7J2HTu",
      "lang" : "en",
      "in_reply_to_screen_name" : "look4thewoman",
      "in_reply_to_user_id_str" : "2442257604",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://twitter.com/kevinirlen/status/532943585596170243/photo/1",
            "indices" : [
              "51",
              "73"
            ],
            "url" : "http://t.co/NAca7J2HTu",
            "media_url" : "http://pbs.twimg.com/media/B2VlUXLCcAALaLy.jpg",
            "id_str" : "532943531405373440",
            "id" : "532943531405373440",
            "media_url_https" : "https://pbs.twimg.com/media/B2VlUXLCcAALaLy.jpg",
            "sizes" : {
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "large" : {
                "w" : "1024",
                "h" : "768",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "1024",
                "h" : "768",
                "resize" : "fit"
              },
              "small" : {
                "w" : "680",
                "h" : "510",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/NAca7J2HTu"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "WarOfTheWorlds",
            "indices" : [
              "54",
              "69"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Christopher H. Baum",
            "screen_name" : "VoiceDarkness",
            "indices" : [
              "3",
              "17"
            ],
            "id_str" : "792781716",
            "id" : "792781716"
          },
          {
            "name" : "Kevin Irlen",
            "screen_name" : "kevinirlen",
            "indices" : [
              "24",
              "35"
            ],
            "id_str" : "43527072",
            "id" : "43527072"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "134"
      ],
      "favorite_count" : "0",
      "id_str" : "522376453363884033",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "522376453363884033",
      "created_at" : "Wed Oct 15 13:20:26 +0000 2014",
      "favorited" : false,
      "full_text" : "RT @VoiceDarkness: Hear @kevinirlen as Mr. Winslow in #WarOfTheWorlds on @KryptonRadio #Halloween 6pm/3pm EDT/PDT and 1am/10pm EDT/PDT",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "TheBrightonBeat",
            "screen_name" : "TheBrightonBeat",
            "indices" : [
              "3",
              "19"
            ],
            "id_str" : "454371846",
            "id" : "454371846"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "id_str" : "520593837576945664",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "520593837576945664",
      "created_at" : "Fri Oct 10 15:16:57 +0000 2014",
      "favorited" : false,
      "full_text" : "RT @TheBrightonBeat: Brooklyn Bowl Tonight! 8pm sharp brings the funky afrobeat/gypsy marching band party we've all been waiting for!... ht…",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "user_mentions" : [ ],
        "urls" : [ ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://twitter.com/kevinirlen/status/519584397389869056/photo/1",
            "indices" : [
              "89",
              "111"
            ],
            "url" : "http://t.co/TiauKO5kfk",
            "media_url" : "http://pbs.twimg.com/media/BzXvQU1CcAMMCZe.jpg",
            "id_str" : "519584395779272707",
            "id" : "519584395779272707",
            "media_url_https" : "https://pbs.twimg.com/media/BzXvQU1CcAMMCZe.jpg",
            "sizes" : {
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "small" : {
                "w" : "510",
                "h" : "680",
                "resize" : "fit"
              },
              "large" : {
                "w" : "768",
                "h" : "1024",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "768",
                "h" : "1024",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/TiauKO5kfk"
          }
        ],
        "hashtags" : [
          {
            "text" : "chefwatson",
            "indices" : [
              "77",
              "88"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "111"
      ],
      "favorite_count" : "1",
      "id_str" : "519584397389869056",
      "truncated" : false,
      "retweet_count" : "1",
      "id" : "519584397389869056",
      "possibly_sensitive" : false,
      "created_at" : "Tue Oct 07 20:25:48 +0000 2014",
      "favorited" : false,
      "full_text" : "my Latvian wife says \"Loves me some Baltic Pork! Baltic is in. Finally.\" yay #chefwatson http://t.co/TiauKO5kfk",
      "lang" : "en",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://twitter.com/kevinirlen/status/519584397389869056/photo/1",
            "indices" : [
              "89",
              "111"
            ],
            "url" : "http://t.co/TiauKO5kfk",
            "media_url" : "http://pbs.twimg.com/media/BzXvQU1CcAMMCZe.jpg",
            "id_str" : "519584395779272707",
            "id" : "519584395779272707",
            "media_url_https" : "https://pbs.twimg.com/media/BzXvQU1CcAMMCZe.jpg",
            "sizes" : {
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "small" : {
                "w" : "510",
                "h" : "680",
                "resize" : "fit"
              },
              "large" : {
                "w" : "768",
                "h" : "1024",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "768",
                "h" : "1024",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/TiauKO5kfk"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "id_str" : "489810441489494016",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "489810441489494016",
      "created_at" : "Thu Jul 17 16:34:44 +0000 2014",
      "favorited" : false,
      "full_text" : "the Russian military have apparently shot down a Malaysian Airlines flight of 300 people over the Ukraine. Another great day for the planet.",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Look For The Woman, Magazine",
            "screen_name" : "look4thewoman",
            "indices" : [
              "0",
              "14"
            ],
            "id_str" : "2442257604",
            "id" : "2442257604"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "24"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "474557404630089729",
      "id_str" : "474558849060306944",
      "in_reply_to_user_id" : "2442257604",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "474558849060306944",
      "in_reply_to_status_id" : "474557404630089729",
      "created_at" : "Thu Jun 05 14:30:21 +0000 2014",
      "favorited" : false,
      "full_text" : "@look4thewoman always :)",
      "lang" : "en",
      "in_reply_to_screen_name" : "look4thewoman",
      "in_reply_to_user_id_str" : "2442257604"
    }
  },
  {
    "tweet" : {
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "user_mentions" : [
          {
            "name" : "Anita Irlen",
            "screen_name" : "anitairlen",
            "indices" : [
              "0",
              "11"
            ],
            "id_str" : "43525546",
            "id" : "43525546"
          },
          {
            "name" : "Look For The Woman, Magazine",
            "screen_name" : "look4thewoman",
            "indices" : [
              "12",
              "26"
            ],
            "id_str" : "2442257604",
            "id" : "2442257604"
          }
        ],
        "urls" : [ ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://twitter.com/kevinirlen/status/469915662870409216/photo/1",
            "indices" : [
              "27",
              "49"
            ],
            "url" : "http://t.co/XQAuuOGNTO",
            "media_url" : "http://pbs.twimg.com/media/BoV5yxkCYAEOQFz.jpg",
            "id_str" : "469915649334992897",
            "id" : "469915649334992897",
            "media_url_https" : "https://pbs.twimg.com/media/BoV5yxkCYAEOQFz.jpg",
            "sizes" : {
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "small" : {
                "w" : "510",
                "h" : "680",
                "resize" : "fit"
              },
              "large" : {
                "w" : "768",
                "h" : "1024",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "768",
                "h" : "1024",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/XQAuuOGNTO"
          }
        ],
        "hashtags" : [ ]
      },
      "display_text_range" : [
        "0",
        "49"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "469910130688294912",
      "id_str" : "469915662870409216",
      "in_reply_to_user_id" : "43527072",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "469915662870409216",
      "in_reply_to_status_id" : "469910130688294912",
      "possibly_sensitive" : false,
      "created_at" : "Fri May 23 18:59:59 +0000 2014",
      "favorited" : false,
      "full_text" : "@anitairlen @look4thewoman http://t.co/XQAuuOGNTO",
      "lang" : "und",
      "in_reply_to_screen_name" : "kevinirlen",
      "in_reply_to_user_id_str" : "43527072",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://twitter.com/kevinirlen/status/469915662870409216/photo/1",
            "indices" : [
              "27",
              "49"
            ],
            "url" : "http://t.co/XQAuuOGNTO",
            "media_url" : "http://pbs.twimg.com/media/BoV5yxkCYAEOQFz.jpg",
            "id_str" : "469915649334992897",
            "id" : "469915649334992897",
            "media_url_https" : "https://pbs.twimg.com/media/BoV5yxkCYAEOQFz.jpg",
            "sizes" : {
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "small" : {
                "w" : "510",
                "h" : "680",
                "resize" : "fit"
              },
              "large" : {
                "w" : "768",
                "h" : "1024",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "768",
                "h" : "1024",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/XQAuuOGNTO"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Anita Irlen",
            "screen_name" : "anitairlen",
            "indices" : [
              "0",
              "11"
            ],
            "id_str" : "43525546",
            "id" : "43525546"
          },
          {
            "name" : "Look For The Woman, Magazine",
            "screen_name" : "look4thewoman",
            "indices" : [
              "12",
              "26"
            ],
            "id_str" : "2442257604",
            "id" : "2442257604"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "93"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "469909847539212289",
      "id_str" : "469910130688294912",
      "in_reply_to_user_id" : "43527072",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "469910130688294912",
      "in_reply_to_status_id" : "469909847539212289",
      "created_at" : "Fri May 23 18:38:00 +0000 2014",
      "favorited" : false,
      "full_text" : "@anitairlen @look4thewoman and about to start walking to the place where i'll be squawking :)",
      "lang" : "en",
      "in_reply_to_screen_name" : "kevinirlen",
      "in_reply_to_user_id_str" : "43527072"
    }
  },
  {
    "tweet" : {
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Anita Irlen",
            "screen_name" : "anitairlen",
            "indices" : [
              "0",
              "11"
            ],
            "id_str" : "43525546",
            "id" : "43525546"
          },
          {
            "name" : "Look For The Woman, Magazine",
            "screen_name" : "look4thewoman",
            "indices" : [
              "12",
              "26"
            ],
            "id_str" : "2442257604",
            "id" : "2442257604"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "42"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "469909554939969536",
      "id_str" : "469909847539212289",
      "in_reply_to_user_id" : "43525546",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "469909847539212289",
      "in_reply_to_status_id" : "469909554939969536",
      "created_at" : "Fri May 23 18:36:52 +0000 2014",
      "favorited" : false,
      "full_text" : "@anitairlen @look4thewoman nah, jus talkin",
      "lang" : "en",
      "in_reply_to_screen_name" : "anitairlen",
      "in_reply_to_user_id_str" : "43525546"
    }
  },
  {
    "tweet" : {
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Look For The Woman, Magazine",
            "screen_name" : "look4thewoman",
            "indices" : [
              "0",
              "14"
            ],
            "id_str" : "2442257604",
            "id" : "2442257604"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "41"
      ],
      "favorite_count" : "0",
      "id_str" : "469909276522455040",
      "in_reply_to_user_id" : "2442257604",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "469909276522455040",
      "created_at" : "Fri May 23 18:34:36 +0000 2014",
      "favorited" : false,
      "full_text" : "@look4thewoman here i am, following her..",
      "lang" : "en",
      "in_reply_to_screen_name" : "look4thewoman",
      "in_reply_to_user_id_str" : "2442257604"
    }
  },
  {
    "tweet" : {
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/#!/download/ipad\" rel=\"nofollow\">Twitter for iPad</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "crossfire",
            "indices" : [
              "5",
              "15"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "15"
      ],
      "favorite_count" : "0",
      "id_str" : "438461755233402881",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "438461755233402881",
      "created_at" : "Tue Feb 25 23:53:23 +0000 2014",
      "favorited" : false,
      "full_text" : "Veto #crossfire",
      "lang" : "pt"
    }
  },
  {
    "tweet" : {
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "C.K. Sample III",
            "screen_name" : "cksample",
            "indices" : [
              "0",
              "9"
            ],
            "id_str" : "804863",
            "id" : "804863"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "48"
      ],
      "favorite_count" : "1",
      "in_reply_to_status_id_str" : "422845223656755200",
      "id_str" : "422854107821404160",
      "in_reply_to_user_id" : "804863",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "422854107821404160",
      "in_reply_to_status_id" : "422845223656755200",
      "created_at" : "Mon Jan 13 22:14:10 +0000 2014",
      "favorited" : false,
      "full_text" : "@cksample Awww! Congrats! Love the name Darcy...",
      "lang" : "en",
      "in_reply_to_screen_name" : "cksample",
      "in_reply_to_user_id_str" : "804863"
    }
  },
  {
    "tweet" : {
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "user_mentions" : [ ],
        "urls" : [ ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://twitter.com/kevinirlen/status/399623847559049216/photo/1",
            "indices" : [
              "29",
              "51"
            ],
            "url" : "http://t.co/WnRBajnAc4",
            "media_url" : "http://pbs.twimg.com/media/BYu_xaAIMAEHKLr.jpg",
            "id_str" : "399623847466774529",
            "id" : "399623847466774529",
            "media_url_https" : "https://pbs.twimg.com/media/BYu_xaAIMAEHKLr.jpg",
            "sizes" : {
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "large" : {
                "w" : "1024",
                "h" : "768",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "1024",
                "h" : "768",
                "resize" : "fit"
              },
              "small" : {
                "w" : "680",
                "h" : "510",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/WnRBajnAc4"
          }
        ],
        "hashtags" : [ ]
      },
      "display_text_range" : [
        "0",
        "51"
      ],
      "favorite_count" : "0",
      "id_str" : "399623847559049216",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "399623847559049216",
      "possibly_sensitive" : false,
      "created_at" : "Sun Nov 10 19:45:24 +0000 2013",
      "favorited" : false,
      "full_text" : "autumn light, Sesuit Harbor. http://t.co/WnRBajnAc4",
      "lang" : "en",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://twitter.com/kevinirlen/status/399623847559049216/photo/1",
            "indices" : [
              "29",
              "51"
            ],
            "url" : "http://t.co/WnRBajnAc4",
            "media_url" : "http://pbs.twimg.com/media/BYu_xaAIMAEHKLr.jpg",
            "id_str" : "399623847466774529",
            "id" : "399623847466774529",
            "media_url_https" : "https://pbs.twimg.com/media/BYu_xaAIMAEHKLr.jpg",
            "sizes" : {
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "large" : {
                "w" : "1024",
                "h" : "768",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "1024",
                "h" : "768",
                "resize" : "fit"
              },
              "small" : {
                "w" : "680",
                "h" : "510",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/WnRBajnAc4"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "retweeted" : false,
      "source" : "<a href=\"http://www.apple.com\" rel=\"nofollow\">iOS</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "http://t.co/OXS8LlmvkL",
            "expanded_url" : "http://youtu.be/YuVI6vlL5n4",
            "display_url" : "youtu.be/YuVI6vlL5n4",
            "indices" : [
              "33",
              "55"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "55"
      ],
      "favorite_count" : "0",
      "id_str" : "371739317376663552",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "371739317376663552",
      "possibly_sensitive" : false,
      "created_at" : "Sun Aug 25 21:02:14 +0000 2013",
      "favorited" : false,
      "full_text" : "War of the Worlds Halloween 2013 http://t.co/OXS8LlmvkL",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "89"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "361633728092569600",
      "id_str" : "361969280675356673",
      "in_reply_to_user_id" : "792781716",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "361969280675356673",
      "in_reply_to_status_id" : "361633728092569600",
      "created_at" : "Mon Jul 29 21:59:36 +0000 2013",
      "favorited" : false,
      "full_text" : "@CHB_TVITD  hey, no prob. I should have a chance to re-record tonite or latest, tomorrow.",
      "lang" : "en",
      "in_reply_to_screen_name" : "VoiceDarkness",
      "in_reply_to_user_id_str" : "792781716"
    }
  },
  {
    "tweet" : {
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "127"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "361220349146312705",
      "id_str" : "361221248396697600",
      "in_reply_to_user_id" : "792781716",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "361221248396697600",
      "in_reply_to_status_id" : "361220349146312705",
      "created_at" : "Sat Jul 27 20:27:11 +0000 2013",
      "favorited" : false,
      "full_text" : "@CHB_TVITD yes I'll try. btw, no longer with spokenlayer :( so may  not have received your email. pls use kevin.irlen@gmail.com",
      "lang" : "en",
      "in_reply_to_screen_name" : "VoiceDarkness",
      "in_reply_to_user_id_str" : "792781716"
    }
  },
  {
    "tweet" : {
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "yesimonthetrain",
            "indices" : [
              "121",
              "137"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "137"
      ],
      "favorite_count" : "0",
      "id_str" : "360423893212725249",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "360423893212725249",
      "created_at" : "Thu Jul 25 15:38:47 +0000 2013",
      "favorited" : false,
      "full_text" : "what if you could meet fellow train riders online (and optionally stay there)? “Hey, @acela2154seat14D, I’m in 14F, Yo.” #yesimonthetrain",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "34"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "350071421428445184",
      "id_str" : "350079695766827010",
      "in_reply_to_user_id" : "792781716",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "350079695766827010",
      "in_reply_to_status_id" : "350071421428445184",
      "created_at" : "Thu Jun 27 02:34:38 +0000 2013",
      "favorited" : false,
      "full_text" : "@CHB_TVITD far out! kirlen@mac.com",
      "lang" : "en",
      "in_reply_to_screen_name" : "VoiceDarkness",
      "in_reply_to_user_id_str" : "792781716"
    }
  },
  {
    "tweet" : {
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Ethan Hein",
            "screen_name" : "ethanhein",
            "indices" : [
              "0",
              "10"
            ],
            "id_str" : "12559332",
            "id" : "12559332"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "53"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "670307784714493957",
      "id_str" : "670351154723844097",
      "in_reply_to_user_id" : "12559332",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "670351154723844097",
      "in_reply_to_status_id" : "670307784714493957",
      "created_at" : "Fri Nov 27 21:19:04 +0000 2015",
      "favorited" : false,
      "full_text" : "@ethanhein that was an awesome stream of Monk tweets!",
      "lang" : "en",
      "in_reply_to_screen_name" : "ethanhein",
      "in_reply_to_user_id_str" : "12559332"
    }
  },
  {
    "tweet" : {
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/#!/download/ipad\" rel=\"nofollow\">Twitter for iPad</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "C.K. Sample III",
            "screen_name" : "cksample",
            "indices" : [
              "3",
              "12"
            ],
            "id_str" : "804863",
            "id" : "804863"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/OpmDaIQjPq",
            "expanded_url" : "https://www.youcaring.com/michelle-johnson-473107#.VlCiU8qa2mY.twitter",
            "display_url" : "youcaring.com/michelle-johns…",
            "indices" : [
              "48",
              "71"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "119"
      ],
      "favorite_count" : "0",
      "id_str" : "668270083601473536",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "668270083601473536",
      "possibly_sensitive" : false,
      "created_at" : "Sun Nov 22 03:29:38 +0000 2015",
      "favorited" : false,
      "full_text" : "RT @cksample: Alex Johnson Family Memorial Fund https://t.co/OpmDaIQjPq for all of you who have been asking how to help",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Ethan Hein",
            "screen_name" : "ethanhein",
            "indices" : [
              "51",
              "61"
            ],
            "id_str" : "12559332",
            "id" : "12559332"
          }
        ],
        "urls" : [
          {
            "url" : "http://t.co/o9sOZa3h7K",
            "expanded_url" : "http://www.ethanhein.com/wp/2015/goodbye-soundcloud/",
            "display_url" : "ethanhein.com/wp/2015/goodby…",
            "indices" : [
              "24",
              "46"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "61"
      ],
      "favorite_count" : "0",
      "id_str" : "645327527267958785",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "645327527267958785",
      "possibly_sensitive" : false,
      "created_at" : "Sat Sep 19 20:04:06 +0000 2015",
      "favorited" : false,
      "full_text" : "another excellent post: http://t.co/o9sOZa3h7K via @ethanhein",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "retweeted" : false,
      "source" : "<a href=\"http://instagram.com\" rel=\"nofollow\">Instagram</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "https://t.co/UfQkraqLdA",
            "expanded_url" : "https://instagram.com/p/7ja7tnkPU3/",
            "display_url" : "instagram.com/p/7ja7tnkPU3/",
            "indices" : [
              "20",
              "43"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "43"
      ],
      "favorite_count" : "0",
      "id_str" : "642882400461172736",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "642882400461172736",
      "possibly_sensitive" : false,
      "created_at" : "Sun Sep 13 02:08:03 +0000 2015",
      "favorited" : false,
      "full_text" : "Just posted a photo https://t.co/UfQkraqLdA",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "retweeted" : false,
      "source" : "<a href=\"http://instagram.com\" rel=\"nofollow\">Instagram</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "https://t.co/D3uqAIHvIy",
            "expanded_url" : "https://instagram.com/p/6Tr6pXkPYN/",
            "display_url" : "instagram.com/p/6Tr6pXkPYN/",
            "indices" : [
              "20",
              "43"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "43"
      ],
      "favorite_count" : "0",
      "id_str" : "631660748180193281",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "631660748180193281",
      "possibly_sensitive" : false,
      "created_at" : "Thu Aug 13 02:57:12 +0000 2015",
      "favorited" : false,
      "full_text" : "Just posted a photo https://t.co/D3uqAIHvIy",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "retweeted" : false,
      "source" : "<a href=\"http://instagram.com\" rel=\"nofollow\">Instagram</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "https://t.co/v69VHcR5kB",
            "expanded_url" : "https://instagram.com/p/6TjQEkEPa6/",
            "display_url" : "instagram.com/p/6TjQEkEPa6/",
            "indices" : [
              "25",
              "48"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "48"
      ],
      "favorite_count" : "0",
      "id_str" : "631641703687041024",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "631641703687041024",
      "possibly_sensitive" : false,
      "created_at" : "Thu Aug 13 01:41:32 +0000 2015",
      "favorited" : false,
      "full_text" : "Arthur's band at Piano's https://t.co/v69VHcR5kB",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Music Hackathon / Music Community Lab",
            "screen_name" : "musichackathon",
            "indices" : [
              "3",
              "18"
            ],
            "id_str" : "623961772",
            "id" : "623961772"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "id_str" : "628977225417773056",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "628977225417773056",
      "created_at" : "Wed Aug 05 17:13:51 +0000 2015",
      "favorited" : false,
      "full_text" : "RT @musichackathon: When spiders make webs they pluck the threads and tune them to specific frequencies. Adam November demos a model. http:…",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "retweeted" : false,
      "source" : "<a href=\"http://instagram.com\" rel=\"nofollow\">Instagram</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "https://t.co/IqgrcK3twC",
            "expanded_url" : "https://instagram.com/p/5ZwDnukPUA/",
            "display_url" : "instagram.com/p/5ZwDnukPUA/",
            "indices" : [
              "36",
              "59"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "59"
      ],
      "favorite_count" : "0",
      "id_str" : "623507078775205888",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "623507078775205888",
      "possibly_sensitive" : false,
      "created_at" : "Tue Jul 21 14:57:26 +0000 2015",
      "favorited" : false,
      "full_text" : "repairing the standard to repairing https://t.co/IqgrcK3twC",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "Smartbomb",
            "indices" : [
              "30",
              "40"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Michael Wiggins",
            "screen_name" : "teachingartist",
            "indices" : [
              "3",
              "18"
            ],
            "id_str" : "18076356",
            "id" : "18076356"
          },
          {
            "name" : "NYU MusEDLab",
            "screen_name" : "MusEDLab",
            "indices" : [
              "122",
              "131"
            ],
            "id_str" : "1890964813",
            "id" : "1890964813"
          },
          {
            "name" : "UrbanArtsPartnership",
            "screen_name" : "UAPNYC",
            "indices" : [
              "132",
              "139"
            ],
            "id_str" : "3242397663",
            "id" : "3242397663"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "144"
      ],
      "favorite_count" : "0",
      "id_str" : "618435473426513924",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "618435473426513924",
      "created_at" : "Tue Jul 07 15:04:41 +0000 2015",
      "favorited" : false,
      "full_text" : "RT @teachingartist: Week 2 of #Smartbomb Labs is underway! Middle school &amp; HS students are in a design thinking class @MusEDLab @UAPNYC htt…",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Ceros",
            "screen_name" : "Cerosdotcom",
            "indices" : [
              "3",
              "15"
            ],
            "id_str" : "21846523",
            "id" : "21846523"
          }
        ],
        "urls" : [
          {
            "url" : "http://t.co/rrx73BPAOA",
            "expanded_url" : "http://bit.ly/1J2icwe",
            "display_url" : "bit.ly/1J2icwe",
            "indices" : [
              "98",
              "120"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "id_str" : "618435363518947328",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "618435363518947328",
      "possibly_sensitive" : false,
      "created_at" : "Tue Jul 07 15:04:15 +0000 2015",
      "favorited" : false,
      "full_text" : "RT @Cerosdotcom: The brand new Ceros Font Explorer is here! Learn more in our July release notes: http://t.co/rrx73BPAOA http://t.co/G39lmQ…",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "retweeted" : false,
      "source" : "<a href=\"http://instagram.com\" rel=\"nofollow\">Instagram</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "https://t.co/yvGvPNCMkm",
            "expanded_url" : "https://instagram.com/p/4zvL8sEPaa/",
            "display_url" : "instagram.com/p/4zvL8sEPaa/",
            "indices" : [
              "25",
              "48"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "48"
      ],
      "favorite_count" : "0",
      "id_str" : "618157186880008193",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "618157186880008193",
      "possibly_sensitive" : false,
      "created_at" : "Mon Jul 06 20:38:52 +0000 2015",
      "favorited" : false,
      "full_text" : "W 4th St - Home of Hoops https://t.co/yvGvPNCMkm",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "retweeted" : false,
      "source" : "<a href=\"http://www.linkedin.com/\" rel=\"nofollow\">LinkedIn</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "http://t.co/Nma38sczy9",
            "expanded_url" : "http://bit.ly/1GGkGUg",
            "display_url" : "bit.ly/1GGkGUg",
            "indices" : [
              "58",
              "80"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "80"
      ],
      "favorite_count" : "0",
      "id_str" : "603947102478077953",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "603947102478077953",
      "possibly_sensitive" : false,
      "created_at" : "Thu May 28 15:33:04 +0000 2015",
      "favorited" : false,
      "full_text" : "Brand Marketing Evolution: The Future of Content Creation http://t.co/Nma38sczy9",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "69"
      ],
      "favorite_count" : "0",
      "id_str" : "601035672548286464",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "601035672548286464",
      "created_at" : "Wed May 20 14:44:05 +0000 2015",
      "favorited" : false,
      "full_text" : "rabbi, is there a blessing for sending an email, tweet, texting, etc?",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/#!/download/ipad\" rel=\"nofollow\">Twitter for iPad</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Ethan Hein",
            "screen_name" : "ethanhein",
            "indices" : [
              "0",
              "10"
            ],
            "id_str" : "12559332",
            "id" : "12559332"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "110"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "598871047505637377",
      "id_str" : "599051832565080065",
      "in_reply_to_user_id" : "12559332",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "599051832565080065",
      "in_reply_to_status_id" : "598871047505637377",
      "created_at" : "Fri May 15 03:21:01 +0000 2015",
      "favorited" : false,
      "full_text" : "@ethanhein I don't mind telling you, not just fine writing but fine teaching, research, and analysis. rock on!",
      "lang" : "en",
      "in_reply_to_screen_name" : "ethanhein",
      "in_reply_to_user_id_str" : "12559332"
    }
  },
  {
    "tweet" : {
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/#!/download/ipad\" rel=\"nofollow\">Twitter for iPad</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Ethan Hein",
            "screen_name" : "ethanhein",
            "indices" : [
              "3",
              "13"
            ],
            "id_str" : "12559332",
            "id" : "12559332"
          }
        ],
        "urls" : [
          {
            "url" : "http://t.co/XxCSxqFX4T",
            "expanded_url" : "http://www.ethanhein.com/wp/2015/a-history-of-pop-production-in-three-tracks/",
            "display_url" : "ethanhein.com/wp/2015/a-hist…",
            "indices" : [
              "82",
              "104"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "104"
      ],
      "favorite_count" : "0",
      "id_str" : "599050108651581441",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "599050108651581441",
      "possibly_sensitive" : false,
      "created_at" : "Fri May 15 03:14:10 +0000 2015",
      "favorited" : false,
      "full_text" : "RT @ethanhein: I don't mind telling you, this is some of my finest music writing. http://t.co/XxCSxqFX4T",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/#!/download/ipad\" rel=\"nofollow\">Twitter for iPad</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "P Shoe",
            "screen_name" : "PavelShoe",
            "indices" : [
              "0",
              "10"
            ],
            "id_str" : "3075915867",
            "id" : "3075915867"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "48"
      ],
      "favorite_count" : "0",
      "id_str" : "598641845959286785",
      "in_reply_to_user_id" : "3075915867",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "598641845959286785",
      "created_at" : "Thu May 14 00:11:52 +0000 2015",
      "favorited" : false,
      "full_text" : "@PavelShoe what a tweet to see you on Twitter ;)",
      "lang" : "en",
      "in_reply_to_screen_name" : "PavelShoe",
      "in_reply_to_user_id_str" : "3075915867"
    }
  },
  {
    "tweet" : {
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "https://t.co/ZZngDmwInG",
            "expanded_url" : "https://twitter.com/usemuzli/status/597163125184430081",
            "display_url" : "twitter.com/usemuzli/statu…",
            "indices" : [
              "83",
              "106"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "106"
      ],
      "favorite_count" : "3",
      "id_str" : "598532636525666305",
      "truncated" : false,
      "retweet_count" : "2",
      "id" : "598532636525666305",
      "possibly_sensitive" : false,
      "created_at" : "Wed May 13 16:57:55 +0000 2015",
      "favorited" : false,
      "full_text" : "great to be back working on the amazing Ceros product with the amazing Ceros team! https://t.co/ZZngDmwInG",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Ethan Hein",
            "screen_name" : "ethanhein",
            "indices" : [
              "3",
              "13"
            ],
            "id_str" : "12559332",
            "id" : "12559332"
          },
          {
            "name" : "Instapaper",
            "screen_name" : "instapaper",
            "indices" : [
              "108",
              "119"
            ],
            "id_str" : "16240267",
            "id" : "16240267"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/qXU8ys1bzN",
            "expanded_url" : "https://medium.com/cuepoint/ultimate-breaks-beats-an-oral-history-74937f932026",
            "display_url" : "medium.com/cuepoint/ultim…",
            "indices" : [
              "80",
              "103"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "119"
      ],
      "favorite_count" : "0",
      "id_str" : "577127168586706946",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "577127168586706946",
      "possibly_sensitive" : false,
      "created_at" : "Sun Mar 15 15:20:14 +0000 2015",
      "favorited" : false,
      "full_text" : "RT @ethanhein: Ultimate Breaks &amp; Beats: An Oral History — Cuepoint — Medium https://t.co/qXU8ys1bzN via @instapaper",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Alex Ruthmann",
            "screen_name" : "alexruthmann",
            "indices" : [
              "0",
              "13"
            ],
            "id_str" : "8663482",
            "id" : "8663482"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "48"
      ],
      "favorite_count" : "0",
      "id_str" : "567431144606797826",
      "in_reply_to_user_id" : "8663482",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "567431144606797826",
      "created_at" : "Mon Feb 16 21:11:41 +0000 2015",
      "favorited" : false,
      "full_text" : "@alexruthmann how have i not been following you?",
      "lang" : "en",
      "in_reply_to_screen_name" : "alexruthmann",
      "in_reply_to_user_id_str" : "8663482"
    }
  },
  {
    "tweet" : {
      "retweeted" : false,
      "source" : "<a href=\"http://instagram.com\" rel=\"nofollow\">Instagram</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "http://t.co/r3JEFiiMnf",
            "expanded_url" : "http://instagram.com/p/ykMYq4EPYI/",
            "display_url" : "instagram.com/p/ykMYq4EPYI/",
            "indices" : [
              "24",
              "46"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "46"
      ],
      "favorite_count" : "0",
      "id_str" : "561926353558466561",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "561926353558466561",
      "possibly_sensitive" : false,
      "created_at" : "Sun Feb 01 16:37:37 +0000 2015",
      "favorited" : false,
      "full_text" : "Trio Globo at Drom, NYC http://t.co/r3JEFiiMnf",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "https://t.co/gh2H84aflK",
            "expanded_url" : "https://twitter.com/ukmoments/status/786532283545165824",
            "display_url" : "twitter.com/ukmoments/stat…",
            "indices" : [
              "45",
              "68"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "68"
      ],
      "favorite_count" : "0",
      "id_str" : "786547831607812096",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "786547831607812096",
      "possibly_sensitive" : false,
      "created_at" : "Thu Oct 13 12:43:11 +0000 2016",
      "favorited" : false,
      "full_text" : "what great news to wake up to. love ya, Bob! https://t.co/gh2H84aflK",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "user_mentions" : [
          {
            "name" : "Sylvia Naples",
            "screen_name" : "sylviawhoa",
            "indices" : [
              "3",
              "14"
            ],
            "id_str" : "733870768254124033",
            "id" : "733870768254124033"
          },
          {
            "name" : "surreal jason sigal",
            "screen_name" : "therewasaguy",
            "indices" : [
              "41",
              "54"
            ],
            "id_str" : "17653842",
            "id" : "17653842"
          }
        ],
        "urls" : [ ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://twitter.com/sylviawhoa/status/785913217012867072/video/1",
            "source_status_id" : "785913217012867072",
            "indices" : [
              "55",
              "78"
            ],
            "url" : "https://t.co/BJDGoE7Tuj",
            "media_url" : "http://pbs.twimg.com/ext_tw_video_thumb/785913210541117440/pu/img/iYj4XWiRLhlWQole.jpg",
            "id_str" : "785913210541117440",
            "source_user_id" : "733870768254124033",
            "id" : "785913210541117440",
            "media_url_https" : "https://pbs.twimg.com/ext_tw_video_thumb/785913210541117440/pu/img/iYj4XWiRLhlWQole.jpg",
            "source_user_id_str" : "733870768254124033",
            "sizes" : {
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "large" : {
                "w" : "400",
                "h" : "400",
                "resize" : "fit"
              },
              "small" : {
                "w" : "400",
                "h" : "400",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "400",
                "h" : "400",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "source_status_id_str" : "785913217012867072",
            "display_url" : "pic.twitter.com/BJDGoE7Tuj"
          }
        ],
        "hashtags" : [ ]
      },
      "display_text_range" : [
        "0",
        "78"
      ],
      "favorite_count" : "0",
      "id_str" : "785946198016491524",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "785946198016491524",
      "possibly_sensitive" : false,
      "created_at" : "Tue Oct 11 20:52:30 +0000 2016",
      "favorited" : false,
      "full_text" : "RT @sylviawhoa: Thanks for hooking it up @therewasaguy https://t.co/BJDGoE7Tuj",
      "lang" : "en",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://twitter.com/sylviawhoa/status/785913217012867072/video/1",
            "source_status_id" : "785913217012867072",
            "indices" : [
              "55",
              "78"
            ],
            "url" : "https://t.co/BJDGoE7Tuj",
            "media_url" : "http://pbs.twimg.com/ext_tw_video_thumb/785913210541117440/pu/img/iYj4XWiRLhlWQole.jpg",
            "id_str" : "785913210541117440",
            "video_info" : {
              "aspect_ratio" : [
                "1",
                "1"
              ],
              "duration_millis" : "5400",
              "variants" : [
                {
                  "bitrate" : "320000",
                  "content_type" : "video/mp4",
                  "url" : "https://video.twimg.com/ext_tw_video/785913210541117440/pu/vid/240x240/axrCgdgKuk8Y2FFh.mp4"
                },
                {
                  "content_type" : "application/x-mpegURL",
                  "url" : "https://video.twimg.com/ext_tw_video/785913210541117440/pu/pl/EXS_koJjdGR8BIgW.m3u8"
                }
              ]
            },
            "source_user_id" : "733870768254124033",
            "additional_media_info" : {
              "monetizable" : false
            },
            "id" : "785913210541117440",
            "media_url_https" : "https://pbs.twimg.com/ext_tw_video_thumb/785913210541117440/pu/img/iYj4XWiRLhlWQole.jpg",
            "source_user_id_str" : "733870768254124033",
            "sizes" : {
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "large" : {
                "w" : "400",
                "h" : "400",
                "resize" : "fit"
              },
              "small" : {
                "w" : "400",
                "h" : "400",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "400",
                "h" : "400",
                "resize" : "fit"
              }
            },
            "type" : "video",
            "source_status_id_str" : "785913217012867072",
            "display_url" : "pic.twitter.com/BJDGoE7Tuj"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Trevor Noah",
            "screen_name" : "Trevornoah",
            "indices" : [
              "3",
              "14"
            ],
            "id_str" : "46335511",
            "id" : "46335511"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "54"
      ],
      "favorite_count" : "0",
      "id_str" : "785301880100585472",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "785301880100585472",
      "created_at" : "Mon Oct 10 02:12:13 +0000 2016",
      "favorited" : false,
      "full_text" : "RT @Trevornoah: Is Martha Raddatz winning this debate?",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "coordinates" : {
        "type" : "Point",
        "coordinates" : [
          "-73.96766769",
          "40.78317629"
        ]
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "ImWithHer",
            "indices" : [
              "0",
              "10"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "10"
      ],
      "favorite_count" : "0",
      "geo" : {
        "type" : "Point",
        "coordinates" : [
          "40.78317629",
          "-73.96766769"
        ]
      },
      "id_str" : "780586379688501248",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "780586379688501248",
      "created_at" : "Tue Sep 27 01:54:30 +0000 2016",
      "favorited" : false,
      "full_text" : "#ImWithHer",
      "lang" : "und"
    }
  },
  {
    "tweet" : {
      "coordinates" : {
        "type" : "Point",
        "coordinates" : [
          "-73.96766769",
          "40.78317629"
        ]
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "trumpflailing",
            "indices" : [
              "0",
              "14"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "14"
      ],
      "favorite_count" : "1",
      "geo" : {
        "type" : "Point",
        "coordinates" : [
          "40.78317629",
          "-73.96766769"
        ]
      },
      "id_str" : "780583588962168832",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "780583588962168832",
      "created_at" : "Tue Sep 27 01:43:24 +0000 2016",
      "favorited" : false,
      "full_text" : "#trumpflailing",
      "lang" : "und"
    }
  },
  {
    "tweet" : {
      "coordinates" : {
        "type" : "Point",
        "coordinates" : [
          "-73.96766769",
          "40.78317629"
        ]
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "debatenight",
            "indices" : [
              "22",
              "34"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "34"
      ],
      "favorite_count" : "0",
      "geo" : {
        "type" : "Point",
        "coordinates" : [
          "40.78317629",
          "-73.96766769"
        ]
      },
      "id_str" : "780570490662453248",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "780570490662453248",
      "created_at" : "Tue Sep 27 00:51:21 +0000 2016",
      "favorited" : false,
      "full_text" : "omg, so nervous about #debatenight",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "coordinates" : {
        "type" : "Point",
        "coordinates" : [
          "-73.972216",
          "40.77274259"
        ]
      },
      "retweeted" : false,
      "source" : "<a href=\"http://instagram.com\" rel=\"nofollow\">Instagram</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "theautumnleaves",
            "indices" : [
              "0",
              "16"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "https://t.co/MAQskUGPzu",
            "expanded_url" : "https://www.instagram.com/p/BKybXALj_cD/",
            "display_url" : "instagram.com/p/BKybXALj_cD/",
            "indices" : [
              "32",
              "55"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "55"
      ],
      "favorite_count" : "0",
      "geo" : {
        "type" : "Point",
        "coordinates" : [
          "40.77274259",
          "-73.972216"
        ]
      },
      "id_str" : "780102391815401472",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "780102391815401472",
      "possibly_sensitive" : false,
      "created_at" : "Sun Sep 25 17:51:18 +0000 2016",
      "favorited" : false,
      "full_text" : "#theautumnleaves @ Central Park https://t.co/MAQskUGPzu",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "https://t.co/Wnut7SbBz4",
            "expanded_url" : "https://twitter.com/egruen/status/779007279693717504",
            "display_url" : "twitter.com/egruen/status/…",
            "indices" : [
              "34",
              "57"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "57"
      ],
      "favorite_count" : "3",
      "id_str" : "779062225923411968",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "779062225923411968",
      "possibly_sensitive" : false,
      "created_at" : "Thu Sep 22 20:58:03 +0000 2016",
      "favorited" : false,
      "full_text" : "so proud to be part of this team! https://t.co/Wnut7SbBz4",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "coordinates" : {
        "type" : "Point",
        "coordinates" : [
          "-73.96766304",
          "40.78286707"
        ]
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "https://t.co/PcZGuWzKHj",
            "expanded_url" : "http://ColoringCam.com",
            "display_url" : "ColoringCam.com",
            "indices" : [
              "33",
              "56"
            ]
          }
        ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://twitter.com/kevinirlen/status/776789709334933504/photo/1",
            "indices" : [
              "57",
              "80"
            ],
            "url" : "https://t.co/5GpGdXTrD5",
            "media_url" : "http://pbs.twimg.com/media/Cse2HkpWAAAogwf.jpg",
            "id_str" : "776789701957124096",
            "id" : "776789701957124096",
            "media_url_https" : "https://pbs.twimg.com/media/Cse2HkpWAAAogwf.jpg",
            "sizes" : {
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "small" : {
                "w" : "510",
                "h" : "680",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "720",
                "h" : "960",
                "resize" : "fit"
              },
              "large" : {
                "w" : "720",
                "h" : "960",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/5GpGdXTrD5"
          }
        ],
        "hashtags" : [
          {
            "text" : "ColoringCam",
            "indices" : [
              "20",
              "32"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "80"
      ],
      "favorite_count" : "2",
      "geo" : {
        "type" : "Point",
        "coordinates" : [
          "40.78286707",
          "-73.96766304"
        ]
      },
      "id_str" : "776789709334933504",
      "truncated" : false,
      "retweet_count" : "1",
      "id" : "776789709334933504",
      "possibly_sensitive" : false,
      "created_at" : "Fri Sep 16 14:27:53 +0000 2016",
      "favorited" : false,
      "full_text" : "I colored this with #ColoringCam https://t.co/PcZGuWzKHj https://t.co/5GpGdXTrD5",
      "lang" : "en",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://twitter.com/kevinirlen/status/776789709334933504/photo/1",
            "indices" : [
              "57",
              "80"
            ],
            "url" : "https://t.co/5GpGdXTrD5",
            "media_url" : "http://pbs.twimg.com/media/Cse2HkpWAAAogwf.jpg",
            "id_str" : "776789701957124096",
            "id" : "776789701957124096",
            "media_url_https" : "https://pbs.twimg.com/media/Cse2HkpWAAAogwf.jpg",
            "sizes" : {
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "small" : {
                "w" : "510",
                "h" : "680",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "720",
                "h" : "960",
                "resize" : "fit"
              },
              "large" : {
                "w" : "720",
                "h" : "960",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/5GpGdXTrD5"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Startup Grind",
            "screen_name" : "StartupGrind",
            "indices" : [
              "3",
              "16"
            ],
            "id_str" : "108698830",
            "id" : "108698830"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "96"
      ],
      "favorite_count" : "0",
      "id_str" : "764572460733915136",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "764572460733915136",
      "created_at" : "Sat Aug 13 21:20:54 +0000 2016",
      "favorited" : false,
      "full_text" : "RT @StartupGrind: \"It does not matter how slowly you go as long as you do not stop.\"  -Confucius",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Corey Ford",
            "screen_name" : "coreyford",
            "indices" : [
              "0",
              "10"
            ],
            "id_str" : "17478565",
            "id" : "17478565"
          },
          {
            "name" : "Matter.",
            "screen_name" : "mattervc",
            "indices" : [
              "11",
              "20"
            ],
            "id_str" : "418837047",
            "id" : "418837047"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "30"
      ],
      "favorite_count" : "1",
      "in_reply_to_status_id_str" : "729313265088483329",
      "id_str" : "729421715852398592",
      "in_reply_to_user_id" : "17478565",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "729421715852398592",
      "in_reply_to_status_id" : "729313265088483329",
      "created_at" : "Sun May 08 21:24:23 +0000 2016",
      "favorited" : false,
      "full_text" : "@coreyford @mattervc congrats!",
      "lang" : "en",
      "in_reply_to_screen_name" : "coreyford",
      "in_reply_to_user_id_str" : "17478565"
    }
  },
  {
    "tweet" : {
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Alex Ruthmann",
            "screen_name" : "alexruthmann",
            "indices" : [
              "3",
              "16"
            ],
            "id_str" : "8663482",
            "id" : "8663482"
          },
          {
            "name" : "Julian Lennon",
            "screen_name" : "JulianLennon",
            "indices" : [
              "25",
              "38"
            ],
            "id_str" : "92636901",
            "id" : "92636901"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/JizdZYiMYP",
            "expanded_url" : "https://twitter.com/JulianLennon/status/725638231241412609",
            "display_url" : "twitter.com/JulianLennon/s…",
            "indices" : [
              "41",
              "64"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "64"
      ],
      "favorite_count" : "0",
      "id_str" : "727207231712800769",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "727207231712800769",
      "possibly_sensitive" : false,
      "created_at" : "Mon May 02 18:44:49 +0000 2016",
      "favorited" : false,
      "full_text" : "RT @alexruthmann: Thanks @JulianLennon!  https://t.co/JizdZYiMYP",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "https://t.co/ihtx3WUSvw",
            "expanded_url" : "https://open.spotify.com/track/5rGgG7YL5ZolmCqg6ZW5TD",
            "display_url" : "open.spotify.com/track/5rGgG7YL…",
            "indices" : [
              "63",
              "86"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "86"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "726044536967933952",
      "id_str" : "726048731532001280",
      "in_reply_to_user_id" : "43527072",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "726048731532001280",
      "in_reply_to_status_id" : "726044536967933952",
      "possibly_sensitive" : false,
      "created_at" : "Fri Apr 29 14:01:21 +0000 2016",
      "favorited" : false,
      "full_text" : "worth 3min30s, a blast from the punk ? past: \"Great Republic\"  https://t.co/ihtx3WUSvw",
      "lang" : "en",
      "in_reply_to_screen_name" : "kevinirlen",
      "in_reply_to_user_id_str" : "43527072"
    }
  },
  {
    "tweet" : {
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "surreal jason sigal",
            "screen_name" : "therewasaguy",
            "indices" : [
              "64",
              "77"
            ],
            "id_str" : "17653842",
            "id" : "17653842"
          },
          {
            "name" : "InternationalJazzDay",
            "screen_name" : "IntlJazzDay",
            "indices" : [
              "104",
              "116"
            ],
            "id_str" : "494485268",
            "id" : "494485268"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/v5upSTXWrJ",
            "expanded_url" : "https://open.spotify.com/album/1EpE0aPpKaTP8oHsHPpNkW",
            "display_url" : "open.spotify.com/album/1EpE0aPp…",
            "indices" : [
              "80",
              "103"
            ]
          },
          {
            "url" : "https://t.co/664FS8h9DW",
            "expanded_url" : "https://twitter.com/therewasaguy/status/725798341783764992",
            "display_url" : "twitter.com/therewasaguy/s…",
            "indices" : [
              "117",
              "140"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "1",
      "id_str" : "726044536967933952",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "726044536967933952",
      "possibly_sensitive" : false,
      "created_at" : "Fri Apr 29 13:44:41 +0000 2016",
      "favorited" : false,
      "full_text" : "now listening to \"Barbarians\" by Richard Davies, thx 4 the tip, @therewasaguy ! https://t.co/v5upSTXWrJ @IntlJazzDay https://t.co/664FS8h9DW",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "education",
            "indices" : [
              "103",
              "113"
            ]
          },
          {
            "text" : "jazzday",
            "indices" : [
              "114",
              "122"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Anne Ruthmann",
            "screen_name" : "AnneRuthmann",
            "indices" : [
              "3",
              "16"
            ],
            "id_str" : "10766842",
            "id" : "10766842"
          },
          {
            "name" : "Herbie Hancock",
            "screen_name" : "herbiehancock",
            "indices" : [
              "19",
              "33"
            ],
            "id_str" : "75361610",
            "id" : "75361610"
          },
          {
            "name" : "U.S. Department of Education",
            "screen_name" : "usedgov",
            "indices" : [
              "41",
              "49"
            ],
            "id_str" : "20437286",
            "id" : "20437286"
          },
          {
            "name" : "mathsciencemusic",
            "screen_name" : "MathSciMusic",
            "indices" : [
              "62",
              "75"
            ],
            "id_str" : "4861305239",
            "id" : "4861305239"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "id_str" : "725005983936864256",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "725005983936864256",
      "created_at" : "Tue Apr 26 16:57:51 +0000 2016",
      "favorited" : false,
      "full_text" : "RT @AnneRuthmann: .@herbiehancock at the @usedgov sharing how @MathSciMusic and can transform learning #education #jazzday https://t.co/PYu…",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "user_mentions" : [
          {
            "name" : "Alex Ruthmann",
            "screen_name" : "alexruthmann",
            "indices" : [
              "3",
              "16"
            ],
            "id_str" : "8663482",
            "id" : "8663482"
          },
          {
            "name" : "NYU MusEDLab",
            "screen_name" : "MusEDLab",
            "indices" : [
              "63",
              "72"
            ],
            "id_str" : "1890964813",
            "id" : "1890964813"
          },
          {
            "name" : "Ethan Hein",
            "screen_name" : "ethanhein",
            "indices" : [
              "73",
              "83"
            ],
            "id_str" : "12559332",
            "id" : "12559332"
          }
        ],
        "urls" : [ ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://twitter.com/alexruthmann/status/724609368768057344/photo/1",
            "source_status_id" : "724609368768057344",
            "indices" : [
              "84",
              "107"
            ],
            "url" : "https://t.co/sI8qPZLWQ4",
            "media_url" : "http://pbs.twimg.com/media/Cg5UXwgW4AAT6xX.jpg",
            "id_str" : "724609357187571712",
            "source_user_id" : "8663482",
            "id" : "724609357187571712",
            "media_url_https" : "https://pbs.twimg.com/media/Cg5UXwgW4AAT6xX.jpg",
            "source_user_id_str" : "8663482",
            "sizes" : {
              "small" : {
                "w" : "382",
                "h" : "680",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "medium" : {
                "w" : "675",
                "h" : "1200",
                "resize" : "fit"
              },
              "large" : {
                "w" : "750",
                "h" : "1334",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "source_status_id_str" : "724609368768057344",
            "display_url" : "pic.twitter.com/sI8qPZLWQ4"
          }
        ],
        "hashtags" : [
          {
            "text" : "groovepizza",
            "indices" : [
              "32",
              "44"
            ]
          },
          {
            "text" : "mathsciencemusic",
            "indices" : [
              "45",
              "62"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "107"
      ],
      "favorite_count" : "0",
      "id_str" : "725005911819952128",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "725005911819952128",
      "possibly_sensitive" : false,
      "created_at" : "Tue Apr 26 16:57:33 +0000 2016",
      "favorited" : false,
      "full_text" : "RT @alexruthmann: Sneak peek... #groovepizza #mathsciencemusic @MusEDLab @ethanhein https://t.co/sI8qPZLWQ4",
      "lang" : "en",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://twitter.com/alexruthmann/status/724609368768057344/photo/1",
            "source_status_id" : "724609368768057344",
            "indices" : [
              "84",
              "107"
            ],
            "url" : "https://t.co/sI8qPZLWQ4",
            "media_url" : "http://pbs.twimg.com/media/Cg5UXwgW4AAT6xX.jpg",
            "id_str" : "724609357187571712",
            "source_user_id" : "8663482",
            "id" : "724609357187571712",
            "media_url_https" : "https://pbs.twimg.com/media/Cg5UXwgW4AAT6xX.jpg",
            "source_user_id_str" : "8663482",
            "sizes" : {
              "small" : {
                "w" : "382",
                "h" : "680",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "medium" : {
                "w" : "675",
                "h" : "1200",
                "resize" : "fit"
              },
              "large" : {
                "w" : "750",
                "h" : "1334",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "source_status_id_str" : "724609368768057344",
            "display_url" : "pic.twitter.com/sI8qPZLWQ4"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "https://t.co/XbvKfXgLoV",
            "expanded_url" : "https://twitter.com/AstroCoastie/status/723507817089478659",
            "display_url" : "twitter.com/AstroCoastie/s…",
            "indices" : [
              "15",
              "38"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "38"
      ],
      "favorite_count" : "0",
      "id_str" : "723681634629869568",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "723681634629869568",
      "possibly_sensitive" : false,
      "created_at" : "Sat Apr 23 01:15:21 +0000 2016",
      "favorited" : false,
      "full_text" : "Right on, Dan! https://t.co/XbvKfXgLoV",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Ethan Hein",
            "screen_name" : "ethanhein",
            "indices" : [
              "0",
              "10"
            ],
            "id_str" : "12559332",
            "id" : "12559332"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "20"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "720998101612408832",
      "id_str" : "721070143439310849",
      "in_reply_to_user_id" : "12559332",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "721070143439310849",
      "in_reply_to_status_id" : "720998101612408832",
      "created_at" : "Fri Apr 15 20:18:13 +0000 2016",
      "favorited" : false,
      "full_text" : "@ethanhein congrats!",
      "lang" : "en",
      "in_reply_to_screen_name" : "ethanhein",
      "in_reply_to_user_id_str" : "12559332"
    }
  },
  {
    "tweet" : {
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Shocklee ⚡️",
            "screen_name" : "Shocklee",
            "indices" : [
              "3",
              "12"
            ],
            "id_str" : "15831401",
            "id" : "15831401"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/tmvPhhngYN",
            "expanded_url" : "http://ow.ly/3bp9SO",
            "display_url" : "ow.ly/3bp9SO",
            "indices" : [
              "94",
              "117"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "117"
      ],
      "favorite_count" : "0",
      "id_str" : "700671727349530624",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "700671727349530624",
      "possibly_sensitive" : false,
      "created_at" : "Fri Feb 19 13:22:12 +0000 2016",
      "favorited" : false,
      "full_text" : "RT @Shocklee: This Free Course in Music Production and Theory Teaches You With Tunes You Love https://t.co/tmvPhhngYN",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Ana Navarro-Cárdenas",
            "screen_name" : "ananavarro",
            "indices" : [
              "3",
              "14"
            ],
            "id_str" : "19568591",
            "id" : "19568591"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "148"
      ],
      "favorite_count" : "0",
      "id_str" : "825715032801558528",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "825715032801558528",
      "created_at" : "Sun Jan 29 14:39:39 +0000 2017",
      "favorited" : false,
      "full_text" : "RT @ananavarro: Please don't. America not defined by 1 President. But by our values, rights &amp; people. Like the many protesting &amp; helping at…",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Monica Byrne",
            "screen_name" : "monicabyrne13",
            "indices" : [
              "3",
              "17"
            ],
            "id_str" : "261991370",
            "id" : "261991370"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/Sim51sQ1N4",
            "expanded_url" : "https://twitter.com/hannahdinhd/status/825481847035555840",
            "display_url" : "twitter.com/hannahdinhd/st…",
            "indices" : [
              "106",
              "129"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "129"
      ],
      "favorite_count" : "0",
      "id_str" : "825510130976452608",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "825510130976452608",
      "possibly_sensitive" : false,
      "created_at" : "Sun Jan 29 01:05:27 +0000 2017",
      "favorited" : false,
      "full_text" : "RT @monicabyrne13: This is America. THIS is what America was founded on. THIS is the America I fight for. https://t.co/Sim51sQ1N4",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Katrina vandenHeuvel",
            "screen_name" : "KatrinaNation",
            "indices" : [
              "3",
              "17"
            ],
            "id_str" : "59159771",
            "id" : "59159771"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "123"
      ],
      "favorite_count" : "0",
      "id_str" : "825507146548785152",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "825507146548785152",
      "created_at" : "Sun Jan 29 00:53:35 +0000 2017",
      "favorited" : false,
      "full_text" : "RT @KatrinaNation: The NYC Taxi Workers just called for a work stoppage, starting at 6 pm. No pick ups or drop offs to JFK.",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "JFK",
            "indices" : [
              "32",
              "36"
            ]
          },
          {
            "text" : "LAX",
            "indices" : [
              "38",
              "42"
            ]
          },
          {
            "text" : "SFO",
            "indices" : [
              "44",
              "48"
            ]
          },
          {
            "text" : "NoMuslimBan",
            "indices" : [
              "78",
              "90"
            ]
          },
          {
            "text" : "NoBanNoWall",
            "indices" : [
              "91",
              "103"
            ]
          },
          {
            "text" : "Syria",
            "indices" : [
              "104",
              "110"
            ]
          },
          {
            "text" : "RefugeesWelcome",
            "indices" : [
              "111",
              "127"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "",
            "screen_name" : "GerV29",
            "indices" : [
              "3",
              "10"
            ],
            "id_str" : "-1",
            "id" : "-1"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "id_str" : "825505132481826816",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "825505132481826816",
      "created_at" : "Sun Jan 29 00:45:35 +0000 2017",
      "favorited" : false,
      "full_text" : "RT @GerV29: Airport protests at #JFK, #LAX, #SFO, Dulles, O'Hare and growing. #NoMuslimBan #NoBanNoWall #Syria #RefugeesWelcome https://t.c…",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Michael Moore",
            "screen_name" : "MMFlint",
            "indices" : [
              "3",
              "11"
            ],
            "id_str" : "20479813",
            "id" : "20479813"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "144"
      ],
      "favorite_count" : "0",
      "id_str" : "825501743651889152",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "825501743651889152",
      "created_at" : "Sun Jan 29 00:32:07 +0000 2017",
      "favorited" : false,
      "full_text" : "RT @MMFlint: To our Muslim neighbors in the world: I &amp; tens of millions of others are so very sorry. The majority of Americans did not vote…",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "About a Bully",
            "screen_name" : "insultingdonald",
            "indices" : [
              "3",
              "19"
            ],
            "id_str" : "822683181187035137",
            "id" : "822683181187035137"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "72"
      ],
      "favorite_count" : "0",
      "id_str" : "825370415816126465",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "825370415816126465",
      "created_at" : "Sat Jan 28 15:50:16 +0000 2017",
      "favorited" : false,
      "full_text" : "RT @insultingdonald: Trump is incapable of understanding foreign policy.",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "David Slack",
            "screen_name" : "slack2thefuture",
            "indices" : [
              "3",
              "19"
            ],
            "id_str" : "215501778",
            "id" : "215501778"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "id_str" : "825370210232315905",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "825370210232315905",
      "created_at" : "Sat Jan 28 15:49:27 +0000 2017",
      "favorited" : false,
      "full_text" : "RT @slack2thefuture: Remember sitting in history, thinking “If I was alive then, I would’ve…”\n\nYou’re alive now. Whatever you’re doing is w…",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Sam Morris",
            "screen_name" : "SamMorrisDesign",
            "indices" : [
              "3",
              "19"
            ],
            "id_str" : "8604152",
            "id" : "8604152"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "id_str" : "824981857481654272",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "824981857481654272",
      "created_at" : "Fri Jan 27 14:06:16 +0000 2017",
      "favorited" : false,
      "full_text" : "RT @SamMorrisDesign: This photo of an Eagle taking a hard look at itself is not a metaphor for anything that's been in the news recently ht…",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "https://t.co/z3vEDk8I6w",
            "expanded_url" : "https://www.splcenter.org/stephen-bannon-has-no-business-white-house#.WItQNe57ss4.twitter",
            "display_url" : "splcenter.org/stephen-bannon…",
            "indices" : [
              "80",
              "103"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "103"
      ],
      "favorite_count" : "0",
      "id_str" : "824977972411166720",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "824977972411166720",
      "possibly_sensitive" : false,
      "created_at" : "Fri Jan 27 13:50:50 +0000 2017",
      "favorited" : false,
      "full_text" : "Stephen Bannon Has No Business In The White House - Southern Poverty Law Center https://t.co/z3vEDk8I6w",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "https://t.co/D4zzfDJxlV",
            "expanded_url" : "https://www.aclu.org/trumpFOIATW",
            "display_url" : "aclu.org/trumpFOIATW",
            "indices" : [
              "111",
              "134"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "134"
      ],
      "favorite_count" : "0",
      "id_str" : "823319420063911938",
      "truncated" : false,
      "retweet_count" : "1",
      "id" : "823319420063911938",
      "possibly_sensitive" : false,
      "created_at" : "Mon Jan 23 00:00:20 +0000 2017",
      "favorited" : false,
      "full_text" : "Day 1 of Trump Administration: ACLU demands documents related to Trump's conflicts of interest. Add your name: https://t.co/D4zzfDJxlV",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Ana Navarro-Cárdenas",
            "screen_name" : "ananavarro",
            "indices" : [
              "3",
              "14"
            ],
            "id_str" : "19568591",
            "id" : "19568591"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/AmJRVRyC7j",
            "expanded_url" : "https://twitter.com/alastairjam/status/823171893901611008",
            "display_url" : "twitter.com/alastairjam/st…",
            "indices" : [
              "102",
              "125"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "125"
      ],
      "favorite_count" : "0",
      "id_str" : "823306138133397505",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "823306138133397505",
      "possibly_sensitive" : false,
      "created_at" : "Sun Jan 22 23:07:34 +0000 2017",
      "favorited" : false,
      "full_text" : "RT @ananavarro: \"Alternative facts\"??? Is that the new name for those things we used to call, \"lies\"? https://t.co/AmJRVRyC7j",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "factsmatter",
            "indices" : [
              "15",
              "27"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Corey Ford",
            "screen_name" : "coreyford",
            "indices" : [
              "3",
              "13"
            ],
            "id_str" : "17478565",
            "id" : "17478565"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/oxsJoUn9zf",
            "expanded_url" : "https://twitter.com/ananavarro/status/823179089586569216",
            "display_url" : "twitter.com/ananavarro/sta…",
            "indices" : [
              "28",
              "51"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "51"
      ],
      "favorite_count" : "0",
      "id_str" : "823305995162099713",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "823305995162099713",
      "possibly_sensitive" : false,
      "created_at" : "Sun Jan 22 23:07:00 +0000 2017",
      "favorited" : false,
      "full_text" : "RT @coreyford: #factsmatter https://t.co/oxsJoUn9zf",
      "lang" : "und"
    }
  },
  {
    "tweet" : {
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Garry Kasparov",
            "screen_name" : "Kasparov63",
            "indices" : [
              "3",
              "14"
            ],
            "id_str" : "449588356",
            "id" : "449588356"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "id_str" : "823304865392852992",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "823304865392852992",
      "created_at" : "Sun Jan 22 23:02:30 +0000 2017",
      "favorited" : false,
      "full_text" : "RT @Kasparov63: Obvious lies serve a purpose for an administration. They watch who challenges them and who loyally repeats them. The people…",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "altfacts",
            "indices" : [
              "0",
              "9"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "11"
      ],
      "favorite_count" : "0",
      "id_str" : "823225031148892162",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "823225031148892162",
      "created_at" : "Sun Jan 22 17:45:16 +0000 2017",
      "favorited" : false,
      "full_text" : "#altfacts ?",
      "lang" : "und"
    }
  },
  {
    "tweet" : {
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "GroovePizza",
            "indices" : [
              "80",
              "92"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Alex Ruthmann",
            "screen_name" : "alexruthmann",
            "indices" : [
              "3",
              "16"
            ],
            "id_str" : "8663482",
            "id" : "8663482"
          },
          {
            "name" : "iZotope",
            "screen_name" : "iZotopeInc",
            "indices" : [
              "27",
              "38"
            ],
            "id_str" : "87020265",
            "id" : "87020265"
          },
          {
            "name" : "NAMM TEC Awards",
            "screen_name" : "NAMMTECAwards",
            "indices" : [
              "46",
              "60"
            ],
            "id_str" : "775734056478580736",
            "id" : "775734056478580736"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "id_str" : "823181688427659264",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "823181688427659264",
      "created_at" : "Sun Jan 22 14:53:03 +0000 2017",
      "favorited" : false,
      "full_text" : "RT @alexruthmann: Congrats @iZotopeInc on the @NAMMTECAwards win! Was awesome 4 #GroovePizza to be nominated alongside you! Thanks @MusEDLa…",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Ethan Hein",
            "screen_name" : "ethanhein",
            "indices" : [
              "3",
              "13"
            ],
            "id_str" : "12559332",
            "id" : "12559332"
          },
          {
            "name" : "NYU MusEDLab",
            "screen_name" : "MusEDLab",
            "indices" : [
              "19",
              "28"
            ],
            "id_str" : "1890964813",
            "id" : "1890964813"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "id_str" : "822947466752430080",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "822947466752430080",
      "created_at" : "Sat Jan 21 23:22:20 +0000 2017",
      "favorited" : false,
      "full_text" : "RT @ethanhein: The @MusEDLab is delighted to announce upgrades to the aQWERTYon - smart accidentals and way more sounds! Try it: https://t.…",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "musedlab",
            "indices" : [
              "26",
              "35"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "https://t.co/ZRbRkXn5Aq",
            "expanded_url" : "https://twitter.com/playtronica/status/806616626648989696",
            "display_url" : "twitter.com/playtronica/st…",
            "indices" : [
              "36",
              "59"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "59"
      ],
      "favorite_count" : "1",
      "id_str" : "806660480379056128",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "806660480379056128",
      "possibly_sensitive" : false,
      "created_at" : "Thu Dec 08 00:43:40 +0000 2016",
      "favorited" : false,
      "full_text" : "another day at the office #musedlab https://t.co/ZRbRkXn5Aq",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "https://t.co/ZFUKLSaH9V",
            "expanded_url" : "http://www.yciw.net/1/giving-tuesday/",
            "display_url" : "yciw.net/1/giving-tuesd…",
            "indices" : [
              "26",
              "49"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "49"
      ],
      "favorite_count" : "0",
      "id_str" : "803596733531979782",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "803596733531979782",
      "possibly_sensitive" : false,
      "created_at" : "Tue Nov 29 13:49:26 +0000 2016",
      "favorited" : false,
      "full_text" : "great stuff happens here: https://t.co/ZFUKLSaH9V",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "Soundbreaking",
            "indices" : [
              "64",
              "78"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "TeachRock.org",
            "screen_name" : "TeachRock",
            "indices" : [
              "3",
              "13"
            ],
            "id_str" : "836962477",
            "id" : "836962477"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/OkCFJML774",
            "expanded_url" : "http://bit.ly/2g0aKfj",
            "display_url" : "bit.ly/2g0aKfj",
            "indices" : [
              "112",
              "135"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "id_str" : "801262866724573185",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "801262866724573185",
      "possibly_sensitive" : false,
      "created_at" : "Wed Nov 23 03:15:28 +0000 2016",
      "favorited" : false,
      "full_text" : "RT @TeachRock: Students can experience Hip Hop technology w/the #Soundbreaking Sampler TechTool in this lesson: https://t.co/OkCFJML774 @Mu…",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "TeachRock.org",
            "screen_name" : "TeachRock",
            "indices" : [
              "3",
              "13"
            ],
            "id_str" : "836962477",
            "id" : "836962477"
          },
          {
            "name" : "NYU MusEDLab",
            "screen_name" : "MusEDLab",
            "indices" : [
              "22",
              "31"
            ],
            "id_str" : "1890964813",
            "id" : "1890964813"
          },
          {
            "name" : "Soundbreaking",
            "screen_name" : "soundbreaking",
            "indices" : [
              "72",
              "86"
            ],
            "id_str" : "144545955",
            "id" : "144545955"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/rMldcvfIag",
            "expanded_url" : "http://TeachRock.org",
            "display_url" : "TeachRock.org",
            "indices" : [
              "102",
              "125"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "139"
      ],
      "favorite_count" : "0",
      "id_str" : "799004612145664001",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "799004612145664001",
      "possibly_sensitive" : false,
      "created_at" : "Wed Nov 16 21:41:58 +0000 2016",
      "favorited" : false,
      "full_text" : "RT @TeachRock: Thanks @MusEDLab for creating fun TechTools for our free @soundbreaking lessons! Go to https://t.co/rMldcvfIag each day for…",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "American",
            "indices" : [
              "32",
              "41"
            ]
          },
          {
            "text" : "technology",
            "indices" : [
              "58",
              "69"
            ]
          },
          {
            "text" : "MadeInAmerica",
            "indices" : [
              "70",
              "84"
            ]
          },
          {
            "text" : "pride",
            "indices" : [
              "85",
              "91"
            ]
          },
          {
            "text" : "Resistance",
            "indices" : [
              "92",
              "103"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Look For The Woman, Magazine",
            "screen_name" : "look4thewoman",
            "indices" : [
              "3",
              "17"
            ],
            "id_str" : "2442257604",
            "id" : "2442257604"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/oakagWoEcP",
            "expanded_url" : "https://twitter.com/france4hillary/status/828653296781053952",
            "display_url" : "twitter.com/france4hillary…",
            "indices" : [
              "104",
              "127"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "127"
      ],
      "favorite_count" : "0",
      "id_str" : "828768608780242946",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "828768608780242946",
      "possibly_sensitive" : false,
      "created_at" : "Tue Feb 07 00:53:28 +0000 2017",
      "favorited" : false,
      "full_text" : "RT @look4thewoman: Proud of our #American tech companies! #technology #MadeInAmerica #pride #Resistance https://t.co/oakagWoEcP",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Mr.Norell",
            "screen_name" : "mr_norell",
            "indices" : [
              "3",
              "13"
            ],
            "id_str" : "4919055286",
            "id" : "4919055286"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/TQRUfxAlzQ",
            "expanded_url" : "https://apps.musedlab.org/groovepizza/",
            "display_url" : "apps.musedlab.org/groovepizza/",
            "indices" : [
              "77",
              "100"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "100"
      ],
      "favorite_count" : "0",
      "id_str" : "828452969662259200",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "828452969662259200",
      "possibly_sensitive" : false,
      "created_at" : "Mon Feb 06 03:59:14 +0000 2017",
      "favorited" : false,
      "full_text" : "RT @mr_norell: UH, NEW FAVORITE ONLINE MUSIC MAKING GAME/TOOL?!\n\nGROOVEPIZZA https://t.co/TQRUfxAlzQ",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Michael Moore",
            "screen_name" : "MMFlint",
            "indices" : [
              "3",
              "11"
            ],
            "id_str" : "20479813",
            "id" : "20479813"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "139"
      ],
      "favorite_count" : "0",
      "id_str" : "828448178345230336",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "828448178345230336",
      "created_at" : "Mon Feb 06 03:40:12 +0000 2017",
      "favorited" : false,
      "full_text" : "RT @MMFlint: Thank you, So-Called President Trump! I've been struggling for 2 weeks over what to call you, and your tweet here gave us the…",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "W. Kamau Bell",
            "screen_name" : "wkamaubell",
            "indices" : [
              "3",
              "14"
            ],
            "id_str" : "19119809",
            "id" : "19119809"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/6fPKvP8gEf",
            "expanded_url" : "https://twitter.com/realDonaldTrump/status/827981079042805761",
            "display_url" : "twitter.com/realDonaldTrum…",
            "indices" : [
              "60",
              "83"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "83"
      ],
      "favorite_count" : "0",
      "id_str" : "828447420346429441",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "828447420346429441",
      "possibly_sensitive" : false,
      "created_at" : "Mon Feb 06 03:37:11 +0000 2017",
      "favorited" : false,
      "full_text" : "RT @wkamaubell: What is our country coming to?\n\nIts senses. https://t.co/6fPKvP8gEf",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "resist",
            "indices" : [
              "41",
              "48"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Michael Wiggins",
            "screen_name" : "teachingartist",
            "indices" : [
              "3",
              "18"
            ],
            "id_str" : "18076356",
            "id" : "18076356"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/ra8lYdK3af",
            "expanded_url" : "https://twitter.com/billmoyershq/status/828086501544226817",
            "display_url" : "twitter.com/billmoyershq/s…",
            "indices" : [
              "49",
              "72"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "72"
      ],
      "favorite_count" : "0",
      "id_str" : "828447039616847874",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "828447039616847874",
      "possibly_sensitive" : false,
      "created_at" : "Mon Feb 06 03:35:40 +0000 2017",
      "favorited" : false,
      "full_text" : "RT @teachingartist: Unshakeable resolve. #resist https://t.co/ra8lYdK3af",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "user_mentions" : [
          {
            "name" : "Anne Ruthmann",
            "screen_name" : "AnneRuthmann",
            "indices" : [
              "3",
              "16"
            ],
            "id_str" : "10766842",
            "id" : "10766842"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/HW2gvG7mgO",
            "expanded_url" : "https://www.yelp.com/biz/starr-bar-brooklyn?pt=check_in&ref=twitter&utm_campaign=CheckIn&utm_content=moment_checkin&utm_medium=twitter&utm_source=ishare&v=4b",
            "display_url" : "yelp.com/biz/starr-bar-…",
            "indices" : [
              "80",
              "103"
            ]
          }
        ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://twitter.com/AnneRuthmann/status/828092301373239296/photo/1",
            "source_status_id" : "828092301373239296",
            "indices" : [
              "104",
              "127"
            ],
            "url" : "https://t.co/7ck1vZhMe9",
            "media_url" : "http://pbs.twimg.com/media/C335jq_VMAACuVK.jpg",
            "id_str" : "828092297736695808",
            "source_user_id" : "10766842",
            "id" : "828092297736695808",
            "media_url_https" : "https://pbs.twimg.com/media/C335jq_VMAACuVK.jpg",
            "source_user_id_str" : "10766842",
            "sizes" : {
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "small" : {
                "w" : "510",
                "h" : "680",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "640",
                "h" : "853",
                "resize" : "fit"
              },
              "large" : {
                "w" : "640",
                "h" : "853",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "source_status_id_str" : "828092301373239296",
            "display_url" : "pic.twitter.com/7ck1vZhMe9"
          }
        ],
        "hashtags" : [
          {
            "text" : "Yelp",
            "indices" : [
              "66",
              "71"
            ]
          },
          {
            "text" : "Yelfie",
            "indices" : [
              "72",
              "79"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "127"
      ],
      "favorite_count" : "0",
      "id_str" : "828410207726424064",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "828410207726424064",
      "possibly_sensitive" : false,
      "created_at" : "Mon Feb 06 01:09:19 +0000 2017",
      "favorited" : false,
      "full_text" : "RT @AnneRuthmann: Bar with a social justice mission (@ Starr Bar) #Yelp #Yelfie https://t.co/HW2gvG7mgO https://t.co/7ck1vZhMe9",
      "lang" : "en",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://twitter.com/AnneRuthmann/status/828092301373239296/photo/1",
            "source_status_id" : "828092301373239296",
            "indices" : [
              "104",
              "127"
            ],
            "url" : "https://t.co/7ck1vZhMe9",
            "media_url" : "http://pbs.twimg.com/media/C335jq_VMAACuVK.jpg",
            "id_str" : "828092297736695808",
            "source_user_id" : "10766842",
            "id" : "828092297736695808",
            "media_url_https" : "https://pbs.twimg.com/media/C335jq_VMAACuVK.jpg",
            "source_user_id_str" : "10766842",
            "sizes" : {
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "small" : {
                "w" : "510",
                "h" : "680",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "640",
                "h" : "853",
                "resize" : "fit"
              },
              "large" : {
                "w" : "640",
                "h" : "853",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "source_status_id_str" : "828092301373239296",
            "display_url" : "pic.twitter.com/7ck1vZhMe9"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Beau Willimon",
            "screen_name" : "BeauWillimon",
            "indices" : [
              "3",
              "16"
            ],
            "id_str" : "28185163",
            "id" : "28185163"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "id_str" : "828408542201835520",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "828408542201835520",
      "created_at" : "Mon Feb 06 01:02:42 +0000 2017",
      "favorited" : false,
      "full_text" : "RT @BeauWillimon: 1. DECLARATION OF RESISTANCE\n\nWhen in the course of American history it becomes necessary for the people to save our Nati…",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "Beyonce",
            "indices" : [
              "24",
              "32"
            ]
          },
          {
            "text" : "lessonplan",
            "indices" : [
              "85",
              "96"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "TeachRock.org",
            "screen_name" : "TeachRock",
            "indices" : [
              "3",
              "13"
            ],
            "id_str" : "836962477",
            "id" : "836962477"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "id_str" : "828407821452591106",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "828407821452591106",
      "created_at" : "Mon Feb 06 00:59:50 +0000 2017",
      "favorited" : false,
      "full_text" : "RT @TeachRock: Bringing #Beyonce into the classroom with a well-researched TeachRock #lessonplan is a meaningful way to celebrate #BlackHis…",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "TeachRock",
            "indices" : [
              "15",
              "25"
            ]
          },
          {
            "text" : "DaveGrohl",
            "indices" : [
              "51",
              "61"
            ]
          },
          {
            "text" : "WhoopiGoldberg",
            "indices" : [
              "66",
              "81"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "TeachRock.org",
            "screen_name" : "TeachRock",
            "indices" : [
              "3",
              "13"
            ],
            "id_str" : "836962477",
            "id" : "836962477"
          },
          {
            "name" : "Stevie Van Zandt",
            "screen_name" : "StevieVanZandt",
            "indices" : [
              "34",
              "49"
            ],
            "id_str" : "23908002",
            "id" : "23908002"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "id_str" : "828407785264148482",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "828407785264148482",
      "created_at" : "Mon Feb 06 00:59:41 +0000 2017",
      "favorited" : false,
      "full_text" : "RT @TeachRock: #TeachRock founder @StevieVanZandt, #DaveGrohl and #WhoopiGoldberg discuss The Beatles and American culture in the 1960s. ht…",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Ethan Hein",
            "screen_name" : "ethanhein",
            "indices" : [
              "3",
              "13"
            ],
            "id_str" : "12559332",
            "id" : "12559332"
          },
          {
            "name" : "Instapaper",
            "screen_name" : "instapaper",
            "indices" : [
              "108",
              "119"
            ],
            "id_str" : "16240267",
            "id" : "16240267"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/1o40nt58kc",
            "expanded_url" : "http://www.msnbc.com/rachel-maddow-show/progressive-activism-takes-its-toll-congressional-republicans",
            "display_url" : "msnbc.com/rachel-maddow-…",
            "indices" : [
              "80",
              "103"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "119"
      ],
      "favorite_count" : "0",
      "id_str" : "828407311387467776",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "828407311387467776",
      "possibly_sensitive" : false,
      "created_at" : "Mon Feb 06 00:57:48 +0000 2017",
      "favorited" : false,
      "full_text" : "RT @ethanhein: Progressive activism takes its toll on congressional Republicans https://t.co/1o40nt58kc via @instapaper",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Ana Navarro-Cárdenas",
            "screen_name" : "ananavarro",
            "indices" : [
              "3",
              "14"
            ],
            "id_str" : "19568591",
            "id" : "19568591"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "id_str" : "828405100548935681",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "828405100548935681",
      "created_at" : "Mon Feb 06 00:49:01 +0000 2017",
      "favorited" : false,
      "full_text" : "RT @ananavarro: The opinion of this so-called President, does not reflect or respect co-equal judicial branch of government in our country,…",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Jake Tapper",
            "screen_name" : "jaketapper",
            "indices" : [
              "3",
              "14"
            ],
            "id_str" : "14529929",
            "id" : "14529929"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/JQZWqEArkm",
            "expanded_url" : "http://mobile.reuters.com/article/idUSKBN15F276",
            "display_url" : "mobile.reuters.com/article/idUSKB…",
            "indices" : [
              "80",
              "103"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "103"
      ],
      "favorite_count" : "0",
      "id_str" : "826958368212385795",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "826958368212385795",
      "possibly_sensitive" : false,
      "created_at" : "Thu Feb 02 01:00:13 +0000 2017",
      "favorited" : false,
      "full_text" : "RT @jaketapper: Reuters offers guidelines on \"Covering Trump the Reuters Way\"\n\n https://t.co/JQZWqEArkm",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Corey Ford",
            "screen_name" : "coreyford",
            "indices" : [
              "0",
              "10"
            ],
            "id_str" : "17478565",
            "id" : "17478565"
          },
          {
            "name" : "Matter.",
            "screen_name" : "mattervc",
            "indices" : [
              "11",
              "20"
            ],
            "id_str" : "418837047",
            "id" : "418837047"
          },
          {
            "name" : "Medium",
            "screen_name" : "Medium",
            "indices" : [
              "21",
              "28"
            ],
            "id_str" : "571202103",
            "id" : "571202103"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "38"
      ],
      "favorite_count" : "2",
      "in_reply_to_status_id_str" : "826913623272464391",
      "id_str" : "826957622867787777",
      "in_reply_to_user_id" : "17478565",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "826957622867787777",
      "in_reply_to_status_id" : "826913623272464391",
      "created_at" : "Thu Feb 02 00:57:16 +0000 2017",
      "favorited" : false,
      "full_text" : "@coreyford @mattervc @Medium congrats!",
      "lang" : "en",
      "in_reply_to_screen_name" : "coreyford",
      "in_reply_to_user_id_str" : "17478565"
    }
  },
  {
    "tweet" : {
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Ethan Hein",
            "screen_name" : "ethanhein",
            "indices" : [
              "3",
              "13"
            ],
            "id_str" : "12559332",
            "id" : "12559332"
          },
          {
            "name" : "Instapaper",
            "screen_name" : "instapaper",
            "indices" : [
              "68",
              "79"
            ],
            "id_str" : "16240267",
            "id" : "16240267"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/BYBnZKHLLe",
            "expanded_url" : "https://newrepublic.com/article/140268/americas-new-opposition-left-resistance-trump",
            "display_url" : "newrepublic.com/article/140268…",
            "indices" : [
              "40",
              "63"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "79"
      ],
      "favorite_count" : "0",
      "id_str" : "826954734158356480",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "826954734158356480",
      "possibly_sensitive" : false,
      "created_at" : "Thu Feb 02 00:45:47 +0000 2017",
      "favorited" : false,
      "full_text" : "RT @ethanhein: America’s New Resistance https://t.co/BYBnZKHLLe via @instapaper",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Ethan Hein",
            "screen_name" : "ethanhein",
            "indices" : [
              "3",
              "13"
            ],
            "id_str" : "12559332",
            "id" : "12559332"
          },
          {
            "name" : "Instapaper",
            "screen_name" : "instapaper",
            "indices" : [
              "123",
              "134"
            ],
            "id_str" : "16240267",
            "id" : "16240267"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/9ySEsOB5zz",
            "expanded_url" : "http://theweek.com/articles/675240/how-kellyanne-conway-became-greatest-spin-doctor-modern-american-history",
            "display_url" : "theweek.com/articles/67524…",
            "indices" : [
              "95",
              "118"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "134"
      ],
      "favorite_count" : "0",
      "id_str" : "826950442127069184",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "826950442127069184",
      "possibly_sensitive" : false,
      "created_at" : "Thu Feb 02 00:28:44 +0000 2017",
      "favorited" : false,
      "full_text" : "RT @ethanhein: How Kellyanne Conway became the greatest spin doctor in modern American history https://t.co/9ySEsOB5zz via @instapaper",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Bernie Sanders",
            "screen_name" : "SenSanders",
            "indices" : [
              "3",
              "14"
            ],
            "id_str" : "29442313",
            "id" : "29442313"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "id_str" : "826292636050939904",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "826292636050939904",
      "created_at" : "Tue Jan 31 04:54:50 +0000 2017",
      "favorited" : false,
      "full_text" : "RT @SenSanders: On virtually every major issue, Trump represents a minority of Americans. Our job now is to bring the majority together and…",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Senator Bob Casey",
            "screen_name" : "SenBobCasey",
            "indices" : [
              "3",
              "15"
            ],
            "id_str" : "171598736",
            "id" : "171598736"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "id_str" : "826292183393239045",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "826292183393239045",
      "created_at" : "Tue Jan 31 04:53:02 +0000 2017",
      "favorited" : false,
      "full_text" : "RT @SenBobCasey: Sally Yates did not betray the Justice Department, she honored its greatest traditions by defending our Constitution. http…",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "siri s.",
            "screen_name" : "sirisrnsn",
            "indices" : [
              "3",
              "13"
            ],
            "id_str" : "14841692",
            "id" : "14841692"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/lGp2eyiyBV",
            "expanded_url" : "http://www.nybooks.com/daily/2016/11/10/trump-election-autocracy-rules-for-survival/",
            "display_url" : "nybooks.com/daily/2016/11/…",
            "indices" : [
              "45",
              "68"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "68"
      ],
      "favorite_count" : "0",
      "id_str" : "826289556752306176",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "826289556752306176",
      "possibly_sensitive" : false,
      "created_at" : "Tue Jan 31 04:42:36 +0000 2017",
      "favorited" : false,
      "full_text" : "RT @sirisrnsn: Autocracy: Rules for Survival https://t.co/lGp2eyiyBV",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "Teachers",
            "indices" : [
              "15",
              "24"
            ]
          },
          {
            "text" : "BlackHistoryMonth",
            "indices" : [
              "31",
              "49"
            ]
          },
          {
            "text" : "hiphop",
            "indices" : [
              "90",
              "97"
            ]
          },
          {
            "text" : "PBS",
            "indices" : [
              "114",
              "118"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "TeachRock.org",
            "screen_name" : "TeachRock",
            "indices" : [
              "3",
              "13"
            ],
            "id_str" : "836962477",
            "id" : "836962477"
          },
          {
            "name" : "Wu Tang Clan",
            "screen_name" : "WuTangClan",
            "indices" : [
              "67",
              "78"
            ],
            "id_str" : "26946348",
            "id" : "26946348"
          },
          {
            "name" : "RZA!",
            "screen_name" : "RZA",
            "indices" : [
              "79",
              "83"
            ],
            "id_str" : "29663668",
            "id" : "29663668"
          },
          {
            "name" : "Soundbreaking",
            "screen_name" : "soundbreaking",
            "indices" : [
              "119",
              "133"
            ],
            "id_str" : "144545955",
            "id" : "144545955"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "144"
      ],
      "favorite_count" : "0",
      "id_str" : "826234222134296576",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "826234222134296576",
      "created_at" : "Tue Jan 31 01:02:43 +0000 2017",
      "favorited" : false,
      "full_text" : "RT @TeachRock: #Teachers! This #BlackHistoryMonth TeachRock brings @WuTangClan @RZA &amp; #hiphop to your class w #PBS @soundbreaking https://t…",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "https://t.co/BPgNZWLTdQ",
            "expanded_url" : "https://twitter.com/lawrence/status/825812405494173697",
            "display_url" : "twitter.com/lawrence/statu…",
            "indices" : [
              "14",
              "37"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "37"
      ],
      "favorite_count" : "0",
      "id_str" : "826227806883500032",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "826227806883500032",
      "possibly_sensitive" : false,
      "created_at" : "Tue Jan 31 00:37:14 +0000 2017",
      "favorited" : false,
      "full_text" : "great article https://t.co/BPgNZWLTdQ",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "https://t.co/jDkPNDddF7",
            "expanded_url" : "https://twitter.com/gierschv/status/892786528958730240",
            "display_url" : "twitter.com/gierschv/statu…",
            "indices" : [
              "7",
              "30"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "30"
      ],
      "favorite_count" : "1",
      "id_str" : "892938168164638721",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "892938168164638721",
      "possibly_sensitive" : false,
      "created_at" : "Thu Aug 03 02:40:23 +0000 2017",
      "favorited" : false,
      "full_text" : "sweet! https://t.co/jDkPNDddF7",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Jamie Ehrenfeld",
            "screen_name" : "artseducation",
            "indices" : [
              "3",
              "17"
            ],
            "id_str" : "17332098",
            "id" : "17332098"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/UnVmnnG1Pk",
            "expanded_url" : "https://www.instagram.com/p/BWtZmVJBI5B/",
            "display_url" : "instagram.com/p/BWtZmVJBI5B/",
            "indices" : [
              "117",
              "140"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "id_str" : "889129660063379456",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "889129660063379456",
      "possibly_sensitive" : false,
      "created_at" : "Sun Jul 23 14:26:44 +0000 2017",
      "favorited" : false,
      "full_text" : "RT @artseducation: TICKETS NOW AVAILABLE: link in bio! \n8.4.17 Music for the People- an Ed Sullivan Fellows Benefit… https://t.co/UnVmnnG1Pk",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "retweeted" : false,
      "source" : "<a href=\"http://spotify.com\" rel=\"nofollow\">Spotify</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "NowPlaying",
            "indices" : [
              "0",
              "11"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "https://t.co/WF2SBYyc9f",
            "expanded_url" : "http://spoti.fi/2tAee2j",
            "display_url" : "spoti.fi/2tAee2j",
            "indices" : [
              "42",
              "65"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "65"
      ],
      "favorite_count" : "1",
      "id_str" : "888905539429814273",
      "truncated" : false,
      "retweet_count" : "1",
      "id" : "888905539429814273",
      "possibly_sensitive" : false,
      "created_at" : "Sat Jul 22 23:36:10 +0000 2017",
      "favorited" : false,
      "full_text" : "#NowPlaying Power of Love by Steff Reed ♫ https://t.co/WF2SBYyc9f",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "HeistStudios",
            "indices" : [
              "98",
              "111"
            ]
          },
          {
            "text" : "Ivanka",
            "indices" : [
              "112",
              "119"
            ]
          },
          {
            "text" : "zine",
            "indices" : [
              "120",
              "125"
            ]
          },
          {
            "text" : "ilovenewyrok",
            "indices" : [
              "126",
              "139"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Look For The Woman, Magazine",
            "screen_name" : "look4thewoman",
            "indices" : [
              "3",
              "17"
            ],
            "id_str" : "2442257604",
            "id" : "2442257604"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/uZcNw2WzA1",
            "expanded_url" : "http://lookforthewoman.com/mittwoch/",
            "display_url" : "lookforthewoman.com/mittwoch/",
            "indices" : [
              "74",
              "97"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "139"
      ],
      "favorite_count" : "0",
      "id_str" : "888400371047170048",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "888400371047170048",
      "possibly_sensitive" : false,
      "created_at" : "Fri Jul 21 14:08:48 +0000 2017",
      "favorited" : false,
      "full_text" : "RT @look4thewoman: Mittwoch: Heist, Ivanka Trump, Drips, Drops...mittwoch https://t.co/uZcNw2WzA1 #HeistStudios #Ivanka #zine #ilovenewyrok",
      "lang" : "de"
    }
  },
  {
    "tweet" : {
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "https://t.co/Pcdcm0wa6q",
            "expanded_url" : "https://twitter.com/ethanhein/status/873328974188826624",
            "display_url" : "twitter.com/ethanhein/stat…",
            "indices" : [
              "106",
              "129"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "129"
      ],
      "favorite_count" : "0",
      "id_str" : "874969715189460992",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "874969715189460992",
      "possibly_sensitive" : false,
      "created_at" : "Wed Jun 14 12:40:10 +0000 2017",
      "favorited" : false,
      "full_text" : "superbly written commentary. make sure phone battery charged - you'll want to read from beginning to end. https://t.co/Pcdcm0wa6q",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "climatechange",
            "indices" : [
              "56",
              "70"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "NYU MusEDLab",
            "screen_name" : "MusEDLab",
            "indices" : [
              "3",
              "12"
            ],
            "id_str" : "1890964813",
            "id" : "1890964813"
          },
          {
            "name" : "CleanGrnMusicMachine",
            "screen_name" : "CleanGreenMM",
            "indices" : [
              "25",
              "38"
            ],
            "id_str" : "865052508657524736",
            "id" : "865052508657524736"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "id_str" : "869658330305896450",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "869658330305896450",
      "created_at" : "Tue May 30 20:54:38 +0000 2017",
      "favorited" : false,
      "full_text" : "RT @MusEDLab: Great show @CleanGreenMM! Educating about #climatechange through music with students in Lawrence, MA. Learn more at https://t…",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "jupitertrack",
            "indices" : [
              "11",
              "24"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Neil deGrasse Tyson",
            "screen_name" : "neiltyson",
            "indices" : [
              "0",
              "10"
            ],
            "id_str" : "19725644",
            "id" : "19725644"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/zPa5UBc10E",
            "expanded_url" : "https://twitter.com/wchsstudios/status/858097612263759873",
            "display_url" : "twitter.com/wchsstudios/st…",
            "indices" : [
              "25",
              "48"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "48"
      ],
      "favorite_count" : "1",
      "id_str" : "858464299215355904",
      "in_reply_to_user_id" : "19725644",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "858464299215355904",
      "possibly_sensitive" : false,
      "created_at" : "Sat Apr 29 23:33:33 +0000 2017",
      "favorited" : false,
      "full_text" : "@neiltyson #jupitertrack https://t.co/zPa5UBc10E",
      "lang" : "und",
      "in_reply_to_screen_name" : "neiltyson",
      "in_reply_to_user_id_str" : "19725644"
    }
  },
  {
    "tweet" : {
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "user_mentions" : [
          {
            "name" : "Ethan Hein",
            "screen_name" : "ethanhein",
            "indices" : [
              "3",
              "13"
            ],
            "id_str" : "12559332",
            "id" : "12559332"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/ERR7SX9gyA",
            "expanded_url" : "http://www.ethanhein.com/wp/2017/the-groove-pizza-now-exports-midi/",
            "display_url" : "ethanhein.com/wp/2017/the-gr…",
            "indices" : [
              "49",
              "72"
            ]
          }
        ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://twitter.com/ethanhein/status/851433898617835520/photo/1",
            "source_status_id" : "851433898617835520",
            "indices" : [
              "73",
              "96"
            ],
            "url" : "https://t.co/YK9san0KE0",
            "media_url" : "http://pbs.twimg.com/media/C9DmnfcV0AAm7J8.jpg",
            "id_str" : "851433895702679552",
            "source_user_id" : "12559332",
            "id" : "851433895702679552",
            "media_url_https" : "https://pbs.twimg.com/media/C9DmnfcV0AAm7J8.jpg",
            "source_user_id_str" : "12559332",
            "sizes" : {
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "small" : {
                "w" : "680",
                "h" : "440",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "724",
                "h" : "469",
                "resize" : "fit"
              },
              "large" : {
                "w" : "724",
                "h" : "469",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "source_status_id_str" : "851433898617835520",
            "display_url" : "pic.twitter.com/YK9san0KE0"
          }
        ],
        "hashtags" : [ ]
      },
      "display_text_range" : [
        "0",
        "96"
      ],
      "favorite_count" : "0",
      "id_str" : "852696693892055041",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "852696693892055041",
      "possibly_sensitive" : false,
      "created_at" : "Fri Apr 14 01:35:08 +0000 2017",
      "favorited" : false,
      "full_text" : "RT @ethanhein: The Groove Pizza now exports MIDI https://t.co/ERR7SX9gyA https://t.co/YK9san0KE0",
      "lang" : "en",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://twitter.com/ethanhein/status/851433898617835520/photo/1",
            "source_status_id" : "851433898617835520",
            "indices" : [
              "73",
              "96"
            ],
            "url" : "https://t.co/YK9san0KE0",
            "media_url" : "http://pbs.twimg.com/media/C9DmnfcV0AAm7J8.jpg",
            "id_str" : "851433895702679552",
            "source_user_id" : "12559332",
            "id" : "851433895702679552",
            "media_url_https" : "https://pbs.twimg.com/media/C9DmnfcV0AAm7J8.jpg",
            "source_user_id_str" : "12559332",
            "sizes" : {
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "small" : {
                "w" : "680",
                "h" : "440",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "724",
                "h" : "469",
                "resize" : "fit"
              },
              "large" : {
                "w" : "724",
                "h" : "469",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "source_status_id_str" : "851433898617835520",
            "display_url" : "pic.twitter.com/YK9san0KE0"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "user_mentions" : [ ],
        "urls" : [ ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://twitter.com/kevinirlen/status/847171510682963969/photo/1",
            "indices" : [
              "15",
              "38"
            ],
            "url" : "https://t.co/JsyNDXzj8D",
            "media_url" : "http://pbs.twimg.com/media/C8HB_ePUQAAWReN.jpg",
            "id_str" : "847171501115588608",
            "id" : "847171501115588608",
            "media_url_https" : "https://pbs.twimg.com/media/C8HB_ePUQAAWReN.jpg",
            "sizes" : {
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "medium" : {
                "w" : "1200",
                "h" : "900",
                "resize" : "fit"
              },
              "small" : {
                "w" : "680",
                "h" : "510",
                "resize" : "fit"
              },
              "large" : {
                "w" : "2048",
                "h" : "1536",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/JsyNDXzj8D"
          }
        ],
        "hashtags" : [
          {
            "text" : "thanksmrtrump",
            "indices" : [
              "0",
              "14"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "38"
      ],
      "favorite_count" : "0",
      "id_str" : "847171510682963969",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "847171510682963969",
      "possibly_sensitive" : false,
      "created_at" : "Wed Mar 29 19:40:02 +0000 2017",
      "favorited" : false,
      "full_text" : "#thanksmrtrump https://t.co/JsyNDXzj8D",
      "lang" : "und",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://twitter.com/kevinirlen/status/847171510682963969/photo/1",
            "indices" : [
              "15",
              "38"
            ],
            "url" : "https://t.co/JsyNDXzj8D",
            "media_url" : "http://pbs.twimg.com/media/C8HB_ePUQAAWReN.jpg",
            "id_str" : "847171501115588608",
            "id" : "847171501115588608",
            "media_url_https" : "https://pbs.twimg.com/media/C8HB_ePUQAAWReN.jpg",
            "sizes" : {
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "medium" : {
                "w" : "1200",
                "h" : "900",
                "resize" : "fit"
              },
              "small" : {
                "w" : "680",
                "h" : "510",
                "resize" : "fit"
              },
              "large" : {
                "w" : "2048",
                "h" : "1536",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/JsyNDXzj8D"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "resistance",
            "indices" : [
              "75",
              "86"
            ]
          },
          {
            "text" : "shepersisted",
            "indices" : [
              "87",
              "100"
            ]
          },
          {
            "text" : "whattowear",
            "indices" : [
              "101",
              "112"
            ]
          },
          {
            "text" : "womensmarch",
            "indices" : [
              "113",
              "125"
            ]
          },
          {
            "text" : "marching",
            "indices" : [
              "126",
              "135"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Look For The Woman, Magazine",
            "screen_name" : "look4thewoman",
            "indices" : [
              "3",
              "17"
            ],
            "id_str" : "2442257604",
            "id" : "2442257604"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/8n3B462t3T",
            "expanded_url" : "http://lookforthewoman.com/what-to-wear-to-the-resistance/",
            "display_url" : "lookforthewoman.com/what-to-wear-t…",
            "indices" : [
              "51",
              "74"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "id_str" : "835875727459381248",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "835875727459381248",
      "possibly_sensitive" : false,
      "created_at" : "Sun Feb 26 15:34:37 +0000 2017",
      "favorited" : false,
      "full_text" : "RT @look4thewoman: What to wear to the resistance. https://t.co/8n3B462t3T #resistance #shepersisted #whattowear #womensmarch #marching #re…",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "eweek2017",
            "indices" : [
              "57",
              "67"
            ]
          },
          {
            "text" : "PBS",
            "indices" : [
              "91",
              "95"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "TeachRock.org",
            "screen_name" : "TeachRock",
            "indices" : [
              "3",
              "13"
            ],
            "id_str" : "836962477",
            "id" : "836962477"
          },
          {
            "name" : "Soundbreaking",
            "screen_name" : "soundbreaking",
            "indices" : [
              "96",
              "110"
            ],
            "id_str" : "144545955",
            "id" : "144545955"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "id_str" : "834195106211172354",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "834195106211172354",
      "created_at" : "Wed Feb 22 00:16:26 +0000 2017",
      "favorited" : false,
      "full_text" : "RT @TeachRock: Explore the science of the microphone for #eweek2017 using a free TeachRock #PBS @soundbreaking lesson https://t.co/m4TQgVYV…",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "NYU MusEDLab",
            "screen_name" : "MusEDLab",
            "indices" : [
              "3",
              "12"
            ],
            "id_str" : "1890964813",
            "id" : "1890964813"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/NW7l1izZF6",
            "expanded_url" : "http://fb.me/6E5cSYG5s",
            "display_url" : "fb.me/6E5cSYG5s",
            "indices" : [
              "73",
              "96"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "96"
      ],
      "favorite_count" : "0",
      "id_str" : "833177532333703168",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "833177532333703168",
      "possibly_sensitive" : false,
      "created_at" : "Sun Feb 19 04:52:58 +0000 2017",
      "favorited" : false,
      "full_text" : "RT @MusEDLab: Our aQWERTYon and GroovePizza apps are in good company.... https://t.co/NW7l1izZF6",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Matthew Kaney",
            "screen_name" : "mindofmatthew",
            "indices" : [
              "0",
              "14"
            ],
            "id_str" : "28945021",
            "id" : "28945021"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/xXyfOYWN2K",
            "expanded_url" : "https://twitter.com/ethanhein/status/833122948298989570",
            "display_url" : "twitter.com/ethanhein/stat…",
            "indices" : [
              "39",
              "62"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "62"
      ],
      "favorite_count" : "0",
      "id_str" : "833134265948856321",
      "in_reply_to_user_id" : "28945021",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "833134265948856321",
      "possibly_sensitive" : false,
      "created_at" : "Sun Feb 19 02:01:02 +0000 2017",
      "favorited" : false,
      "full_text" : "@mindofmatthew makes the magic happen! https://t.co/xXyfOYWN2K",
      "lang" : "en",
      "in_reply_to_screen_name" : "mindofmatthew",
      "in_reply_to_user_id_str" : "28945021"
    }
  },
  {
    "tweet" : {
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "immortal",
            "indices" : [
              "0",
              "9"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "https://t.co/puQKwGr06U",
            "expanded_url" : "https://twitter.com/pitchfork/status/833060479941632000",
            "display_url" : "twitter.com/pitchfork/stat…",
            "indices" : [
              "10",
              "33"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "33"
      ],
      "favorite_count" : "0",
      "id_str" : "833132246697639936",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "833132246697639936",
      "possibly_sensitive" : false,
      "created_at" : "Sun Feb 19 01:53:01 +0000 2017",
      "favorited" : false,
      "full_text" : "#immortal https://t.co/puQKwGr06U",
      "lang" : "und"
    }
  },
  {
    "tweet" : {
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "user_mentions" : [
          {
            "name" : "Sover",
            "screen_name" : "Alifaith55",
            "indices" : [
              "3",
              "14"
            ],
            "id_str" : "864264541424758785",
            "id" : "864264541424758785"
          }
        ],
        "urls" : [ ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://twitter.com/Alifaith55/status/830594784863645699/photo/1",
            "source_status_id" : "830594784863645699",
            "indices" : [
              "48",
              "71"
            ],
            "url" : "https://t.co/KpCTQjN8zz",
            "media_url" : "http://pbs.twimg.com/media/C4bdjceWIAAgerw.jpg",
            "id_str" : "830594782305067008",
            "source_user_id" : "810619093749559296",
            "id" : "830594782305067008",
            "media_url_https" : "https://pbs.twimg.com/media/C4bdjceWIAAgerw.jpg",
            "source_user_id_str" : "810619093749559296",
            "sizes" : {
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "large" : {
                "w" : "573",
                "h" : "515",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "573",
                "h" : "515",
                "resize" : "fit"
              },
              "small" : {
                "w" : "573",
                "h" : "515",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "source_status_id_str" : "830594784863645699",
            "display_url" : "pic.twitter.com/KpCTQjN8zz"
          }
        ],
        "hashtags" : [ ]
      },
      "display_text_range" : [
        "0",
        "71"
      ],
      "favorite_count" : "0",
      "id_str" : "830881603740106753",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "830881603740106753",
      "possibly_sensitive" : false,
      "created_at" : "Sun Feb 12 20:49:46 +0000 2017",
      "favorited" : false,
      "full_text" : "RT @Alifaith55: I CANNOT RETWEET THIS ENOUGH ❤❤ https://t.co/KpCTQjN8zz",
      "lang" : "en",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://twitter.com/Alifaith55/status/830594784863645699/photo/1",
            "source_status_id" : "830594784863645699",
            "indices" : [
              "48",
              "71"
            ],
            "url" : "https://t.co/KpCTQjN8zz",
            "media_url" : "http://pbs.twimg.com/media/C4bdjceWIAAgerw.jpg",
            "id_str" : "830594782305067008",
            "source_user_id" : "810619093749559296",
            "id" : "830594782305067008",
            "media_url_https" : "https://pbs.twimg.com/media/C4bdjceWIAAgerw.jpg",
            "source_user_id_str" : "810619093749559296",
            "sizes" : {
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "large" : {
                "w" : "573",
                "h" : "515",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "573",
                "h" : "515",
                "resize" : "fit"
              },
              "small" : {
                "w" : "573",
                "h" : "515",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "source_status_id_str" : "830594784863645699",
            "display_url" : "pic.twitter.com/KpCTQjN8zz"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "David Axelrod",
            "screen_name" : "davidaxelrod",
            "indices" : [
              "3",
              "16"
            ],
            "id_str" : "244655353",
            "id" : "244655353"
          },
          {
            "name" : "Frank Bruni",
            "screen_name" : "FrankBruni",
            "indices" : [
              "34",
              "45"
            ],
            "id_str" : "37291805",
            "id" : "37291805"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "148"
      ],
      "favorite_count" : "0",
      "id_str" : "830879215994228737",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "830879215994228737",
      "created_at" : "Sun Feb 12 20:40:16 +0000 2017",
      "favorited" : false,
      "full_text" : "RT @davidaxelrod: Wise words from @FrankBruni to Ds: Protest &amp; process aren't enough; clear vision &amp; fresh voices matter. https://t.co/MMUI…",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "user_mentions" : [ ],
        "urls" : [ ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://twitter.com/kevinirlen/status/830577711844319238/video/1",
            "indices" : [
              "42",
              "65"
            ],
            "url" : "https://t.co/yDD3K1bbPI",
            "media_url" : "http://pbs.twimg.com/ext_tw_video_thumb/830577555136602113/pu/img/hPDXWp1J7ziv-Nii.jpg",
            "id_str" : "830577555136602113",
            "id" : "830577555136602113",
            "media_url_https" : "https://pbs.twimg.com/ext_tw_video_thumb/830577555136602113/pu/img/hPDXWp1J7ziv-Nii.jpg",
            "sizes" : {
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "medium" : {
                "w" : "1200",
                "h" : "675",
                "resize" : "fit"
              },
              "small" : {
                "w" : "680",
                "h" : "383",
                "resize" : "fit"
              },
              "large" : {
                "w" : "1280",
                "h" : "720",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/yDD3K1bbPI"
          }
        ],
        "hashtags" : [
          {
            "text" : "DefendPlannedParenthood",
            "indices" : [
              "0",
              "24"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "65"
      ],
      "favorite_count" : "2",
      "id_str" : "830577711844319238",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "830577711844319238",
      "possibly_sensitive" : false,
      "created_at" : "Sun Feb 12 00:42:12 +0000 2017",
      "favorited" : false,
      "full_text" : "#DefendPlannedParenthood Washington Sq Pk https://t.co/yDD3K1bbPI",
      "lang" : "en",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://twitter.com/kevinirlen/status/830577711844319238/video/1",
            "indices" : [
              "42",
              "65"
            ],
            "url" : "https://t.co/yDD3K1bbPI",
            "media_url" : "http://pbs.twimg.com/ext_tw_video_thumb/830577555136602113/pu/img/hPDXWp1J7ziv-Nii.jpg",
            "id_str" : "830577555136602113",
            "video_info" : {
              "aspect_ratio" : [
                "16",
                "9"
              ],
              "duration_millis" : "59920",
              "variants" : [
                {
                  "bitrate" : "832000",
                  "content_type" : "video/mp4",
                  "url" : "https://video.twimg.com/ext_tw_video/830577555136602113/pu/vid/640x360/4_6KAoVCxtnHJU1v.mp4"
                },
                {
                  "bitrate" : "2176000",
                  "content_type" : "video/mp4",
                  "url" : "https://video.twimg.com/ext_tw_video/830577555136602113/pu/vid/1280x720/6x2Ok2Sz9IYUn0Ky.mp4"
                },
                {
                  "content_type" : "application/x-mpegURL",
                  "url" : "https://video.twimg.com/ext_tw_video/830577555136602113/pu/pl/YFblbAw34BSbsPOp.m3u8"
                },
                {
                  "bitrate" : "256000",
                  "content_type" : "video/mp4",
                  "url" : "https://video.twimg.com/ext_tw_video/830577555136602113/pu/vid/320x180/L5sOZavRe_RghH5i.mp4"
                }
              ]
            },
            "additional_media_info" : {
              "monetizable" : false
            },
            "id" : "830577555136602113",
            "media_url_https" : "https://pbs.twimg.com/ext_tw_video_thumb/830577555136602113/pu/img/hPDXWp1J7ziv-Nii.jpg",
            "sizes" : {
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "medium" : {
                "w" : "1200",
                "h" : "675",
                "resize" : "fit"
              },
              "small" : {
                "w" : "680",
                "h" : "383",
                "resize" : "fit"
              },
              "large" : {
                "w" : "1280",
                "h" : "720",
                "resize" : "fit"
              }
            },
            "type" : "video",
            "display_url" : "pic.twitter.com/yDD3K1bbPI"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "user_mentions" : [
          {
            "name" : "Jay Rosen",
            "screen_name" : "jayrosen_nyu",
            "indices" : [
              "3",
              "16"
            ],
            "id_str" : "14834340",
            "id" : "14834340"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/5NkUdiHji7",
            "expanded_url" : "http://nymag.com/daily/intelligencer/2017/02/andrew-sullivan-the-madness-of-king-donald.html",
            "display_url" : "nymag.com/daily/intellig…",
            "indices" : [
              "47",
              "70"
            ]
          }
        ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://twitter.com/jayrosen_nyu/status/830233648356016129/photo/1",
            "source_status_id" : "830233648356016129",
            "indices" : [
              "71",
              "94"
            ],
            "url" : "https://t.co/6fq72kvPmj",
            "media_url" : "http://pbs.twimg.com/media/C4WU__uWcAEPDUe.jpg",
            "id_str" : "830233533478236161",
            "source_user_id" : "14834340",
            "id" : "830233533478236161",
            "media_url_https" : "https://pbs.twimg.com/media/C4WU__uWcAEPDUe.jpg",
            "source_user_id_str" : "14834340",
            "sizes" : {
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "large" : {
                "w" : "1076",
                "h" : "652",
                "resize" : "fit"
              },
              "small" : {
                "w" : "680",
                "h" : "412",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "1076",
                "h" : "652",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "source_status_id_str" : "830233648356016129",
            "display_url" : "pic.twitter.com/6fq72kvPmj"
          }
        ],
        "hashtags" : [ ]
      },
      "display_text_range" : [
        "0",
        "94"
      ],
      "favorite_count" : "0",
      "id_str" : "830419262409932800",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "830419262409932800",
      "possibly_sensitive" : false,
      "created_at" : "Sat Feb 11 14:12:35 +0000 2017",
      "favorited" : false,
      "full_text" : "RT @jayrosen_nyu: This is a brilliant passage. https://t.co/5NkUdiHji7 https://t.co/6fq72kvPmj",
      "lang" : "en",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://twitter.com/jayrosen_nyu/status/830233648356016129/photo/1",
            "source_status_id" : "830233648356016129",
            "indices" : [
              "71",
              "94"
            ],
            "url" : "https://t.co/6fq72kvPmj",
            "media_url" : "http://pbs.twimg.com/media/C4WU__uWcAEPDUe.jpg",
            "id_str" : "830233533478236161",
            "source_user_id" : "14834340",
            "id" : "830233533478236161",
            "media_url_https" : "https://pbs.twimg.com/media/C4WU__uWcAEPDUe.jpg",
            "source_user_id_str" : "14834340",
            "sizes" : {
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "large" : {
                "w" : "1076",
                "h" : "652",
                "resize" : "fit"
              },
              "small" : {
                "w" : "680",
                "h" : "412",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "1076",
                "h" : "652",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "source_status_id_str" : "830233648356016129",
            "display_url" : "pic.twitter.com/6fq72kvPmj"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "38"
      ],
      "favorite_count" : "0",
      "id_str" : "829846035816181761",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "829846035816181761",
      "created_at" : "Fri Feb 10 00:14:47 +0000 2017",
      "favorited" : false,
      "full_text" : "kudos to Washington State AG's office!",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Harshini J. Karunaratne",
            "screen_name" : "HarshiniJK",
            "indices" : [
              "0",
              "11"
            ],
            "id_str" : "4301063243",
            "id" : "4301063243"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "31"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1476796937806483456",
      "id_str" : "1479468890921095170",
      "in_reply_to_user_id" : "4301063243",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1479468890921095170",
      "in_reply_to_status_id" : "1476796937806483456",
      "created_at" : "Fri Jan 07 15:04:05 +0000 2022",
      "favorited" : false,
      "full_text" : "@HarshiniJK Love these. u rock!",
      "lang" : "en",
      "in_reply_to_screen_name" : "HarshiniJK",
      "in_reply_to_user_id_str" : "4301063243"
    }
  },
  {
    "tweet" : {
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "NASA Universe",
            "screen_name" : "NASAUniverse",
            "indices" : [
              "3",
              "16"
            ],
            "id_str" : "26853548",
            "id" : "26853548"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "137"
      ],
      "favorite_count" : "0",
      "id_str" : "1387333816516333570",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1387333816516333570",
      "created_at" : "Wed Apr 28 09:12:11 +0000 2021",
      "favorited" : false,
      "full_text" : "RT @NASAUniverse: ... .--. . -.-. - .-. --- ... -.-. --- .--. -.--     .. ...     .-- .... .- -     .- ... - .-. --- -. --- -- . .-. ...…",
      "lang" : "und"
    }
  },
  {
    "tweet" : {
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "https://t.co/dUAdktC203",
            "expanded_url" : "https://www.theguardian.com/books/2021/mar/06/everything-inhabitable-a-poem-by-marieke-lucas-rijneveld",
            "display_url" : "theguardian.com/books/2021/mar…",
            "indices" : [
              "58",
              "81"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "81"
      ],
      "favorite_count" : "1",
      "id_str" : "1368097327110569986",
      "truncated" : false,
      "retweet_count" : "1",
      "id" : "1368097327110569986",
      "possibly_sensitive" : false,
      "created_at" : "Sat Mar 06 07:13:15 +0000 2021",
      "favorited" : false,
      "full_text" : "Everything inhabitable: a poem by Marieke Lucas Rijneveld https://t.co/dUAdktC203",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "user_mentions" : [
          {
            "name" : "Manny Jones",
            "screen_name" : "MannyJones87",
            "indices" : [
              "3",
              "16"
            ],
            "id_str" : "160479649",
            "id" : "160479649"
          }
        ],
        "urls" : [ ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://twitter.com/atrupar/status/1351881415852490754/video/1",
            "source_status_id" : "1351881415852490754",
            "indices" : [
              "110",
              "133"
            ],
            "url" : "https://t.co/xdWtqlMRuB",
            "media_url" : "http://pbs.twimg.com/ext_tw_video_thumb/1351881359694958603/pu/img/SuusGG0DsGj1UNRM.jpg",
            "id_str" : "1351881359694958603",
            "source_user_id" : "288277167",
            "id" : "1351881359694958603",
            "media_url_https" : "https://pbs.twimg.com/ext_tw_video_thumb/1351881359694958603/pu/img/SuusGG0DsGj1UNRM.jpg",
            "source_user_id_str" : "288277167",
            "sizes" : {
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "medium" : {
                "w" : "1200",
                "h" : "675",
                "resize" : "fit"
              },
              "small" : {
                "w" : "680",
                "h" : "383",
                "resize" : "fit"
              },
              "large" : {
                "w" : "1280",
                "h" : "720",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "source_status_id_str" : "1351881415852490754",
            "display_url" : "pic.twitter.com/xdWtqlMRuB"
          }
        ],
        "hashtags" : [
          {
            "text" : "ByeTrump",
            "indices" : [
              "86",
              "95"
            ]
          },
          {
            "text" : "ByeFelicia",
            "indices" : [
              "97",
              "108"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "133"
      ],
      "favorite_count" : "0",
      "id_str" : "1351891317941530625",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1351891317941530625",
      "possibly_sensitive" : false,
      "created_at" : "Wed Jan 20 13:56:21 +0000 2021",
      "favorited" : false,
      "full_text" : "RT @MannyJones87: Oh God, I can’t contain my excitement Good Fucking Riddance MF!! 🤣😂 #ByeTrump  #ByeFelicia  https://t.co/xdWtqlMRuB",
      "lang" : "en",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://twitter.com/atrupar/status/1351881415852490754/video/1",
            "source_status_id" : "1351881415852490754",
            "indices" : [
              "110",
              "133"
            ],
            "url" : "https://t.co/xdWtqlMRuB",
            "media_url" : "http://pbs.twimg.com/ext_tw_video_thumb/1351881359694958603/pu/img/SuusGG0DsGj1UNRM.jpg",
            "id_str" : "1351881359694958603",
            "video_info" : {
              "aspect_ratio" : [
                "16",
                "9"
              ],
              "duration_millis" : "45146",
              "variants" : [
                {
                  "content_type" : "application/x-mpegURL",
                  "url" : "https://video.twimg.com/ext_tw_video/1351881359694958603/pu/pl/uqfsc3RnpkAw8a1P.m3u8?tag=10&v=ad4"
                },
                {
                  "bitrate" : "832000",
                  "content_type" : "video/mp4",
                  "url" : "https://video.twimg.com/ext_tw_video/1351881359694958603/pu/vid/640x360/sHafXZpIt3aW9LDh.mp4?tag=10"
                },
                {
                  "bitrate" : "256000",
                  "content_type" : "video/mp4",
                  "url" : "https://video.twimg.com/ext_tw_video/1351881359694958603/pu/vid/480x270/Ey1KsBGiJ77D9mAc.mp4?tag=10"
                },
                {
                  "bitrate" : "2176000",
                  "content_type" : "video/mp4",
                  "url" : "https://video.twimg.com/ext_tw_video/1351881359694958603/pu/vid/1280x720/BJLkVkfavJX5iZEW.mp4?tag=10"
                }
              ]
            },
            "source_user_id" : "288277167",
            "additional_media_info" : {
              "monetizable" : false
            },
            "id" : "1351881359694958603",
            "media_url_https" : "https://pbs.twimg.com/ext_tw_video_thumb/1351881359694958603/pu/img/SuusGG0DsGj1UNRM.jpg",
            "source_user_id_str" : "288277167",
            "sizes" : {
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "medium" : {
                "w" : "1200",
                "h" : "675",
                "resize" : "fit"
              },
              "small" : {
                "w" : "680",
                "h" : "383",
                "resize" : "fit"
              },
              "large" : {
                "w" : "1280",
                "h" : "720",
                "resize" : "fit"
              }
            },
            "type" : "video",
            "source_status_id_str" : "1351881415852490754",
            "display_url" : "pic.twitter.com/xdWtqlMRuB"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Dana Bash",
            "screen_name" : "DanaBashCNN",
            "indices" : [
              "0",
              "12"
            ],
            "id_str" : "108617810",
            "id" : "108617810"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "186"
      ],
      "favorite_count" : "0",
      "id_str" : "1251284083356971008",
      "in_reply_to_user_id" : "108617810",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1251284083356971008",
      "created_at" : "Fri Apr 17 22:59:07 +0000 2020",
      "favorited" : false,
      "full_text" : "@DanaBashCNN happened to glimpse the contents of your home bookshelf mirroring mine right next to the TV you are regularly on - hoping u loved My Brilliant Friend as much as I did. ciao!",
      "lang" : "en",
      "in_reply_to_screen_name" : "DanaBashCNN",
      "in_reply_to_user_id_str" : "108617810"
    }
  },
  {
    "tweet" : {
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Keisha Lance Bottoms",
            "screen_name" : "KeishaBottoms",
            "indices" : [
              "0",
              "14"
            ],
            "id_str" : "305818748",
            "id" : "305818748"
          },
          {
            "name" : "Joy-Ann (Pro-Democracy) Reid 😷",
            "screen_name" : "JoyAnnReid",
            "indices" : [
              "39",
              "50"
            ],
            "id_str" : "49698134",
            "id" : "49698134"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "74"
      ],
      "favorite_count" : "0",
      "id_str" : "1248758789781798912",
      "in_reply_to_user_id" : "305818748",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1248758789781798912",
      "created_at" : "Fri Apr 10 23:44:30 +0000 2020",
      "favorited" : false,
      "full_text" : "@KeishaBottoms you rock. just saw u on @JoyAnnReid. god bless *you* child.",
      "lang" : "en",
      "in_reply_to_screen_name" : "KeishaBottoms",
      "in_reply_to_user_id_str" : "305818748"
    }
  },
  {
    "tweet" : {
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "The Beat with Ari Melber on MSNBC 📺",
            "screen_name" : "TheBeatWithAri",
            "indices" : [
              "0",
              "15"
            ],
            "id_str" : "887418059501305858",
            "id" : "887418059501305858"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "88"
      ],
      "favorite_count" : "0",
      "id_str" : "1245497350015062017",
      "in_reply_to_user_id" : "887418059501305858",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1245497350015062017",
      "created_at" : "Wed Apr 01 23:44:43 +0000 2020",
      "favorited" : false,
      "full_text" : "@TheBeatWithAri mayor Bria Clark from Norman, OK has best attitude everyone should have!",
      "lang" : "en",
      "in_reply_to_screen_name" : "TheBeatWithAri",
      "in_reply_to_user_id_str" : "887418059501305858"
    }
  },
  {
    "tweet" : {
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Kickstarter",
            "screen_name" : "Kickstarter",
            "indices" : [
              "112",
              "124"
            ],
            "id_str" : "16186995",
            "id" : "16186995"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/NnCvSwosQb",
            "expanded_url" : "https://www.kickstarter.com/projects/2092705582/tumaini-new-album-by-berta-moreno-afro-jazz-soul-project?ref=thanks-tweet",
            "display_url" : "kickstarter.com/projects/20927…",
            "indices" : [
              "125",
              "148"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "148"
      ],
      "favorite_count" : "0",
      "id_str" : "1186004951912407040",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1186004951912407040",
      "possibly_sensitive" : false,
      "created_at" : "Sun Oct 20 19:43:10 +0000 2019",
      "favorited" : false,
      "full_text" : "Excited to support Tumaini - a new album from my wonderful sax teacher Berta Moreno's Afro-Jazz Soul Project on @Kickstarter https://t.co/NnCvSwosQb",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "standup4impeachment",
            "indices" : [
              "50",
              "70"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Ben & Jerry's",
            "screen_name" : "benandjerrys",
            "indices" : [
              "9",
              "22"
            ],
            "id_str" : "18949610",
            "id" : "18949610"
          },
          {
            "name" : "Ben & Jerry's UK 🧡",
            "screen_name" : "benandjerrysUK",
            "indices" : [
              "33",
              "48"
            ],
            "id_str" : "104141145",
            "id" : "104141145"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/diRUy9ZQGs",
            "expanded_url" : "https://twitter.com/kevinirlen/status/1127963289131081728",
            "display_url" : "twitter.com/kevinirlen/sta…",
            "indices" : [
              "71",
              "94"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "94"
      ],
      "favorite_count" : "2",
      "id_str" : "1176642064253145088",
      "truncated" : false,
      "retweet_count" : "1",
      "id" : "1176642064253145088",
      "possibly_sensitive" : false,
      "created_at" : "Tue Sep 24 23:38:23 +0000 2019",
      "favorited" : false,
      "full_text" : "time now @benandjerrys? or maybe @benandjerrysUK? #standup4impeachment https://t.co/diRUy9ZQGs",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Greta Thunberg",
            "screen_name" : "GretaThunberg",
            "indices" : [
              "3",
              "17"
            ],
            "id_str" : "1006419421244678144",
            "id" : "1006419421244678144"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "id_str" : "1176209358532816896",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1176209358532816896",
      "created_at" : "Mon Sep 23 18:58:58 +0000 2019",
      "favorited" : false,
      "full_text" : "RT @GretaThunberg: “People are suffering. People are dying. Entire ecosystems are collapsing. We are in the beginning of a mass extinction.…",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Ben & Jerry's",
            "screen_name" : "benandjerrys",
            "indices" : [
              "0",
              "13"
            ],
            "id_str" : "18949610",
            "id" : "18949610"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "60"
      ],
      "favorite_count" : "1",
      "id_str" : "1127963289131081728",
      "in_reply_to_user_id" : "18949610",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1127963289131081728",
      "created_at" : "Mon May 13 15:46:19 +0000 2019",
      "favorited" : false,
      "full_text" : "@benandjerrys urgent flavor suggestion: I’m Peachy Mint Chip",
      "lang" : "en",
      "in_reply_to_screen_name" : "benandjerrys",
      "in_reply_to_user_id_str" : "18949610"
    }
  },
  {
    "tweet" : {
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "brotherwest",
            "indices" : [
              "57",
              "69"
            ]
          },
          {
            "text" : "cornelwest",
            "indices" : [
              "70",
              "81"
            ]
          },
          {
            "text" : "cnn",
            "indices" : [
              "82",
              "86"
            ]
          },
          {
            "text" : "AndersonCooper",
            "indices" : [
              "87",
              "102"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Look For The Woman, Magazine",
            "screen_name" : "look4thewoman",
            "indices" : [
              "3",
              "17"
            ],
            "id_str" : "2442257604",
            "id" : "2442257604"
          },
          {
            "name" : "Cornel West",
            "screen_name" : "CornelWest",
            "indices" : [
              "19",
              "30"
            ],
            "id_str" : "36743910",
            "id" : "36743910"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "102"
      ],
      "favorite_count" : "0",
      "id_str" : "1032792474819993600",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1032792474819993600",
      "created_at" : "Fri Aug 24 00:51:29 +0000 2018",
      "favorited" : false,
      "full_text" : "RT @look4thewoman: @CornelWest Thank you brother West. 🙏 #brotherwest #cornelwest #cnn #AndersonCooper",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "John O. Brennan",
            "screen_name" : "JohnBrennan",
            "indices" : [
              "3",
              "15"
            ],
            "id_str" : "910492003359760384",
            "id" : "910492003359760384"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "id_str" : "975027100137742338",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "975027100137742338",
      "created_at" : "Sat Mar 17 15:12:30 +0000 2018",
      "favorited" : false,
      "full_text" : "RT @JohnBrennan: When the full extent of your venality, moral turpitude, and political corruption becomes known, you will take your rightfu…",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Ethan Hein",
            "screen_name" : "ethanhein",
            "indices" : [
              "3",
              "13"
            ],
            "id_str" : "12559332",
            "id" : "12559332"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "132"
      ],
      "favorite_count" : "0",
      "id_str" : "896344313726152705",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "896344313726152705",
      "created_at" : "Sat Aug 12 12:15:12 +0000 2017",
      "favorited" : false,
      "full_text" : "RT @ethanhein: Dear makers of music production tools: I know \"master/slave\" is a conventional term, but it's time to find a new one.",
      "lang" : "en"
    }
  }
]