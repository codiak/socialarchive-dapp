window.YTD.mute.part0 = [
  {
    "muting" : {
      "accountId" : "822683181187035137",
      "userLink" : "https://twitter.com/intent/user?user_id=822683181187035137"
    }
  }
]