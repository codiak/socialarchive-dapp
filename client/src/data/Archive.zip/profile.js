export const PROFILE = {
  "profile" : {
    "description" : {
      "bio" : "Wetware with aspirations\n// Engineer / Designer",
      "website" : "https://t.co/lQZxTOGarZ",
      "location" : "Mars"
    },
    "avatarMediaUrl" : "https://pbs.twimg.com/profile_images/1404544885324189697/wzv9wUaO_200x200.jpg",
    "headerMediaUrl" : "https://pbs.twimg.com/profile_banners/14321476/1614531558"
  }
};
