export const TWEET_SUBSET = [ {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NASA's Perseverance Mars Rover",
        "screen_name" : "NASAPersevere",
        "indices" : [ "16", "30" ],
        "id_str" : "1232783237623119872",
        "id" : "1232783237623119872"
      } ],
      "urls" : [ ],
      "symbols" : [ ],
      "media" : [ {
        "expanded_url" : "https://twitter.com/cybercody/status/1362458904375021573/photo/1",
        "indices" : [ "32", "55" ],
        "url" : "https://t.co/huRjNuzZNS",
        "media_url" : "http://pbs.twimg.com/media/EuhtJsFXEAAY_aQ.jpg",
        "id_str" : "1362458900499468288",
        "id" : "1362458900499468288",
        "media_url_https" : "https://pbs.twimg.com/media/EuhtJsFXEAAY_aQ.jpg",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "large" : {
            "w" : "1170",
            "h" : "1589",
            "resize" : "fit"
          },
          "small" : {
            "w" : "501",
            "h" : "680",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "884",
            "h" : "1200",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/huRjNuzZNS"
      },{
        "expanded_url" : "https://twitter.com/cybercody/status/1362458904375021573/photo/1",
        "indices" : [ "32", "55" ],
        "url" : "https://t.co/huRjNuzZNS",
        "media_url" : "http://pbs.twimg.com/media/EuhtJsFXEAAY_aQ.jpg",
        "id_str" : "1362458900499468288",
        "id" : "1362458900499468288",
        "media_url_https" : "https://pbs.twimg.com/media/EuhtJsFXEAAY_aQ.jpg",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "large" : {
            "w" : "1170",
            "h" : "1589",
            "resize" : "fit"
          },
          "small" : {
            "w" : "501",
            "h" : "680",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "884",
            "h" : "1200",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/huRjNuzZNS"
      } ],
      "hashtags" : [ ]
    },
    "display_text_range" : [ "0", "55" ],
    "favorite_count" : "2",
    "id_str" : "1362458904375021573",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1362458904375021573",
    "possibly_sensitive" : false,
    "created_at" : "Thu Feb 18 17:48:10 +0000 2021",
    "favorited" : false,
    "full_text" : "You’ve got this @NASAPersevere! https://t.co/huRjNuzZNS",
    "lang" : "en",
    "extended_entities" : {
      "media" : [ {
        "expanded_url" : "https://twitter.com/cybercody/status/1362458904375021573/photo/1",
        "indices" : [ "32", "55" ],
        "url" : "https://t.co/huRjNuzZNS",
        "media_url" : "http://pbs.twimg.com/media/EuhtJsFXEAAY_aQ.jpg",
        "id_str" : "1362458900499468288",
        "id" : "1362458900499468288",
        "media_url_https" : "https://pbs.twimg.com/media/EuhtJsFXEAAY_aQ.jpg",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "large" : {
            "w" : "1170",
            "h" : "1589",
            "resize" : "fit"
          },
          "small" : {
            "w" : "501",
            "h" : "680",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "884",
            "h" : "1200",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/huRjNuzZNS"
      } ]
    }
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "joNathan",
        "screen_name" : "joNathanBriG",
        "indices" : [ "0", "13" ],
        "id_str" : "365252466",
        "id" : "365252466"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "92" ],
    "favorite_count" : "1",
    "in_reply_to_status_id_str" : "1362444009675882498",
    "id_str" : "1362456743092113411",
    "in_reply_to_user_id" : "365252466",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1362456743092113411",
    "in_reply_to_status_id" : "1362444009675882498",
    "created_at" : "Thu Feb 18 17:39:35 +0000 2021",
    "favorited" : false,
    "full_text" : "@joNathanBriG CAN I RECOMMEND A HUMAN COMFORT SUCH AS GRILLED CHEESE\n(👀 /r/totallynotrobots)",
    "lang" : "en",
    "in_reply_to_screen_name" : "joNathanBriG",
    "in_reply_to_user_id_str" : "365252466"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "italian hand emoji 😙🥟",
        "screen_name" : "CannoliCamo",
        "indices" : [ "0", "12" ],
        "id_str" : "936353444",
        "id" : "936353444"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "34" ],
    "favorite_count" : "1",
    "in_reply_to_status_id_str" : "1362443385471193092",
    "id_str" : "1362456012742144002",
    "in_reply_to_user_id" : "936353444",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1362456012742144002",
    "in_reply_to_status_id" : "1362443385471193092",
    "created_at" : "Thu Feb 18 17:36:41 +0000 2021",
    "favorited" : false,
    "full_text" : "@CannoliCamo “Pro-skater robots” 🤘",
    "lang" : "en",
    "in_reply_to_screen_name" : "CannoliCamo",
    "in_reply_to_user_id_str" : "936353444"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/UvUT71z2SS",
        "expanded_url" : "https://ourworldindata.org/cheap-renewables-growth",
        "display_url" : "ourworldindata.org/cheap-renewabl…",
        "indices" : [ "105", "128" ]
      } ],
      "symbols" : [ ],
      "media" : [ {
        "expanded_url" : "https://twitter.com/cybercody/status/1360345296186839049/photo/1",
        "indices" : [ "129", "152" ],
        "url" : "https://t.co/3GnYbSqWI6",
        "media_url" : "http://pbs.twimg.com/media/EuDqduNXEAQ2w4s.jpg",
        "id_str" : "1360344883807064068",
        "id" : "1360344883807064068",
        "media_url_https" : "https://pbs.twimg.com/media/EuDqduNXEAQ2w4s.jpg",
        "sizes" : {
          "medium" : {
            "w" : "777",
            "h" : "1200",
            "resize" : "fit"
          },
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "small" : {
            "w" : "440",
            "h" : "680",
            "resize" : "fit"
          },
          "large" : {
            "w" : "1326",
            "h" : "2048",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/3GnYbSqWI6"
      } ],
      "hashtags" : [ ]
    },
    "display_text_range" : [ "0", "152" ],
    "favorite_count" : "1",
    "id_str" : "1360345296186839049",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1360345296186839049",
    "possibly_sensitive" : false,
    "created_at" : "Fri Feb 12 21:49:27 +0000 2021",
    "favorited" : false,
    "full_text" : "I keep thinking about this chart. Solar power isn't just affordable now, it's fast becoming ultra-cheap.\nhttps://t.co/UvUT71z2SS https://t.co/3GnYbSqWI6",
    "lang" : "en",
    "extended_entities" : {
      "media" : [ {
        "expanded_url" : "https://twitter.com/cybercody/status/1360345296186839049/photo/1",
        "indices" : [ "129", "152" ],
        "url" : "https://t.co/3GnYbSqWI6",
        "media_url" : "http://pbs.twimg.com/media/EuDqduNXEAQ2w4s.jpg",
        "id_str" : "1360344883807064068",
        "id" : "1360344883807064068",
        "media_url_https" : "https://pbs.twimg.com/media/EuDqduNXEAQ2w4s.jpg",
        "sizes" : {
          "medium" : {
            "w" : "777",
            "h" : "1200",
            "resize" : "fit"
          },
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "small" : {
            "w" : "440",
            "h" : "680",
            "resize" : "fit"
          },
          "large" : {
            "w" : "1326",
            "h" : "2048",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/3GnYbSqWI6"
      } ]
    }
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "Jayne Lee",
        "screen_name" : "maryjaynelee",
        "indices" : [ "0", "13" ],
        "id_str" : "442443571",
        "id" : "442443571"
      }, {
        "name" : "Robert Vinluan",
        "screen_name" : "RobertVinluan",
        "indices" : [ "14", "28" ],
        "id_str" : "461429820",
        "id" : "461429820"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "63" ],
    "favorite_count" : "2",
    "in_reply_to_status_id_str" : "1360042148368965633",
    "id_str" : "1360301254388436996",
    "in_reply_to_user_id" : "442443571",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1360301254388436996",
    "in_reply_to_status_id" : "1360042148368965633",
    "created_at" : "Fri Feb 12 18:54:26 +0000 2021",
    "favorited" : false,
    "full_text" : "@maryjaynelee @RobertVinluan I wasn’t brave enough to got for 4",
    "lang" : "en",
    "in_reply_to_screen_name" : "maryjaynelee",
    "in_reply_to_user_id_str" : "442443571"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/yftU2brEJo",
        "expanded_url" : "https://twitter.com/BBCNewsnight/status/1083298716700815360",
        "display_url" : "twitter.com/BBCNewsnight/s…",
        "indices" : [ "114", "137" ]
      } ]
    },
    "display_text_range" : [ "0", "137" ],
    "favorite_count" : "1",
    "id_str" : "1359891594183385089",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1359891594183385089",
    "possibly_sensitive" : false,
    "created_at" : "Thu Feb 11 15:46:36 +0000 2021",
    "favorited" : false,
    "full_text" : "Interviewer: \"[Internet] is just a tool though, isn't it?\"\nBowie: \"No it's not, no. No, it's an alien life form.\" https://t.co/yftU2brEJo",
    "lang" : "en"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "277" ],
    "favorite_count" : "1",
    "in_reply_to_status_id_str" : "1359722770381369344",
    "id_str" : "1359724385423290368",
    "in_reply_to_user_id" : "14321476",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1359724385423290368",
    "in_reply_to_status_id" : "1359722770381369344",
    "created_at" : "Thu Feb 11 04:42:10 +0000 2021",
    "favorited" : false,
    "full_text" : "Too late to bet that Clubhouse will succeed, it's happening.\n\nBut I will bet others will fail on the optional part. The sliding scale of participation.\n\nAnd I'll also bet that the media will struggle—caught between platform and creator—but individuals will get more spotlights.",
    "lang" : "en",
    "in_reply_to_screen_name" : "cybercody",
    "in_reply_to_user_id_str" : "14321476"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "277" ],
    "favorite_count" : "0",
    "in_reply_to_status_id_str" : "1359720142876336134",
    "id_str" : "1359722770381369344",
    "in_reply_to_user_id" : "14321476",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1359722770381369344",
    "in_reply_to_status_id" : "1359720142876336134",
    "created_at" : "Thu Feb 11 04:35:45 +0000 2021",
    "favorited" : false,
    "full_text" : "I also feel like it's part of a bigger trend towards optionally-active participation platforms.\n\nTwitch (&amp; other streaming sites), Kickstarter, Patreon, Fortnite Party &amp; Creative modes, and in a weird way Crypto, and definitely Gamestop\n\nUnited tribes, anti-clicktivism",
    "lang" : "en",
    "in_reply_to_screen_name" : "cybercody",
    "in_reply_to_user_id_str" : "14321476"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/mWXnraQmcw",
        "expanded_url" : "https://a16z.com/2020/12/07/social-strikes-back-social-plus/",
        "display_url" : "a16z.com/2020/12/07/soc…",
        "indices" : [ "122", "145" ]
      } ]
    },
    "display_text_range" : [ "0", "243" ],
    "favorite_count" : "2",
    "id_str" : "1359720142876336134",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1359720142876336134",
    "possibly_sensitive" : false,
    "created_at" : "Thu Feb 11 04:25:19 +0000 2021",
    "favorited" : false,
    "full_text" : "Clubhouse is cool, and growing extremely fast.\nHere's my take you didn't ask for:\n- Social is expanding to new verticals (https://t.co/mWXnraQmcw)\n- People like to be part of something\n(it's live AND you can potentially be pulled to the stage)",
    "lang" : "en"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "Bernard Ferguson",
        "screen_name" : "ProjectNard",
        "indices" : [ "0", "12" ],
        "id_str" : "123570976",
        "id" : "123570976"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "36" ],
    "favorite_count" : "1",
    "in_reply_to_status_id_str" : "1359569966111088641",
    "id_str" : "1359570765658673158",
    "in_reply_to_user_id" : "123570976",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1359570765658673158",
    "in_reply_to_status_id" : "1359569966111088641",
    "created_at" : "Wed Feb 10 18:31:44 +0000 2021",
    "favorited" : false,
    "full_text" : "@ProjectNard But how do I preorder 🙌",
    "lang" : "en",
    "in_reply_to_screen_name" : "ProjectNard",
    "in_reply_to_user_id_str" : "123570976"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "Paul",
        "screen_name" : "UniPaul",
        "indices" : [ "0", "8" ],
        "id_str" : "87030153",
        "id" : "87030153"
      }, {
        "name" : "Daniel Gross",
        "screen_name" : "danielgross",
        "indices" : [ "9", "21" ],
        "id_str" : "38190583",
        "id" : "38190583"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "115" ],
    "favorite_count" : "8",
    "in_reply_to_status_id_str" : "1359558602504159234",
    "id_str" : "1359559364013658112",
    "in_reply_to_user_id" : "87030153",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1359559364013658112",
    "in_reply_to_status_id" : "1359558602504159234",
    "created_at" : "Wed Feb 10 17:46:26 +0000 2021",
    "favorited" : false,
    "full_text" : "@UniPaul @danielgross You’ve heard of hosting in the Cloud. \n\nNow get ready for hosting in the...\n✨ Constellation ✨",
    "lang" : "en",
    "in_reply_to_screen_name" : "UniPaul",
    "in_reply_to_user_id_str" : "87030153"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ ],
      "urls" : [ ],
      "symbols" : [ ],
      "media" : [ {
        "expanded_url" : "https://twitter.com/cybercody/status/1358853011385311235/photo/1",
        "indices" : [ "34", "57" ],
        "url" : "https://t.co/NY7DCygApY",
        "media_url" : "http://pbs.twimg.com/media/EtudnIOXMAUiAHT.jpg",
        "id_str" : "1358853008130519045",
        "id" : "1358853008130519045",
        "media_url_https" : "https://pbs.twimg.com/media/EtudnIOXMAUiAHT.jpg",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "medium" : {
            "w" : "990",
            "h" : "1200",
            "resize" : "fit"
          },
          "small" : {
            "w" : "561",
            "h" : "680",
            "resize" : "fit"
          },
          "large" : {
            "w" : "1170",
            "h" : "1418",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/NY7DCygApY"
      } ],
      "hashtags" : [ ]
    },
    "display_text_range" : [ "0", "57" ],
    "favorite_count" : "3",
    "id_str" : "1358853011385311235",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1358853011385311235",
    "possibly_sensitive" : false,
    "created_at" : "Mon Feb 08 18:59:38 +0000 2021",
    "favorited" : false,
    "full_text" : "I need to debug GetSomeShitDone() https://t.co/NY7DCygApY",
    "lang" : "en",
    "extended_entities" : {
      "media" : [ {
        "expanded_url" : "https://twitter.com/cybercody/status/1358853011385311235/photo/1",
        "indices" : [ "34", "57" ],
        "url" : "https://t.co/NY7DCygApY",
        "media_url" : "http://pbs.twimg.com/media/EtudnIOXMAUiAHT.jpg",
        "id_str" : "1358853008130519045",
        "id" : "1358853008130519045",
        "media_url_https" : "https://pbs.twimg.com/media/EtudnIOXMAUiAHT.jpg",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "medium" : {
            "w" : "990",
            "h" : "1200",
            "resize" : "fit"
          },
          "small" : {
            "w" : "561",
            "h" : "680",
            "resize" : "fit"
          },
          "large" : {
            "w" : "1170",
            "h" : "1418",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/NY7DCygApY"
      } ]
    }
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "Julian Lehr",
        "screen_name" : "lehrjulian",
        "indices" : [ "0", "11" ],
        "id_str" : "79249821",
        "id" : "79249821"
      }, {
        "name" : "Li Jin",
        "screen_name" : "ljin18",
        "indices" : [ "12", "19" ],
        "id_str" : "774642558853009408",
        "id" : "774642558853009408"
      }, {
        "name" : "D’Arcy Coolican",
        "screen_name" : "DCoolican",
        "indices" : [ "20", "30" ],
        "id_str" : "366434437",
        "id" : "366434437"
      }, {
        "name" : "Kevin Kwok",
        "screen_name" : "kevinakwok",
        "indices" : [ "31", "42" ],
        "id_str" : "169791252",
        "id" : "169791252"
      }, {
        "name" : "Andrew Chen",
        "screen_name" : "andrewchen",
        "indices" : [ "43", "54" ],
        "id_str" : "3283901",
        "id" : "3283901"
      }, {
        "name" : "Tren Griffin",
        "screen_name" : "trengriffin",
        "indices" : [ "55", "67" ],
        "id_str" : "21271771",
        "id" : "21271771"
      }, {
        "name" : "James Currier",
        "screen_name" : "JamesCurrier",
        "indices" : [ "68", "81" ],
        "id_str" : "17088394",
        "id" : "17088394"
      }, {
        "name" : "Venkatesh Rao",
        "screen_name" : "vgr",
        "indices" : [ "119", "123" ],
        "id_str" : "8500962",
        "id" : "8500962"
      }, {
        "name" : "Breaking Smart",
        "screen_name" : "breaking_smart",
        "indices" : [ "157", "172" ],
        "id_str" : "3386589551",
        "id" : "3386589551"
      } ],
      "urls" : [ {
        "url" : "https://t.co/7IYYrMRWxK",
        "expanded_url" : "https://breakingsmart.substack.com/p/anti-network-effects",
        "display_url" : "breakingsmart.substack.com/p/anti-network…",
        "indices" : [ "175", "198" ]
      } ]
    },
    "display_text_range" : [ "0", "198" ],
    "favorite_count" : "1",
    "in_reply_to_status_id_str" : "1358444931359133697",
    "id_str" : "1358847945240625152",
    "in_reply_to_user_id" : "79249821",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1358847945240625152",
    "in_reply_to_status_id" : "1358444931359133697",
    "possibly_sensitive" : false,
    "created_at" : "Mon Feb 08 18:39:30 +0000 2021",
    "favorited" : false,
    "full_text" : "@lehrjulian @ljin18 @DCoolican @kevinakwok @andrewchen @trengriffin @JamesCurrier Most eye-opening for me recently was @vgr’s piece Anti-Network Effects (on @breaking_smart) \nhttps://t.co/7IYYrMRWxK",
    "lang" : "en",
    "in_reply_to_screen_name" : "lehrjulian",
    "in_reply_to_user_id_str" : "79249821"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "Sid Verma",
        "screen_name" : "_SidVerma",
        "indices" : [ "3", "13" ],
        "id_str" : "233998905",
        "id" : "233998905"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "109" ],
    "favorite_count" : "0",
    "id_str" : "1358793558900301827",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1358793558900301827",
    "created_at" : "Mon Feb 08 15:03:24 +0000 2021",
    "favorited" : false,
    "full_text" : "RT @_SidVerma: Elon Musk: See you later alligator \n\nTwitter: Haha, omg, outrageous, let's buy some alligators",
    "lang" : "en"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Internet of Shit",
        "screen_name" : "internetofshit",
        "indices" : [ "18", "33" ],
        "id_str" : "3356531254",
        "id" : "3356531254"
      } ],
      "urls" : [ ],
      "symbols" : [ ],
      "media" : [ {
        "expanded_url" : "https://twitter.com/cybercody/status/1357810929753325574/photo/1",
        "indices" : [ "91", "114" ],
        "url" : "https://t.co/TpO6cnDJHK",
        "media_url" : "http://pbs.twimg.com/media/Etfp1-sWYAANvtM.jpg",
        "id_str" : "1357810926246846464",
        "id" : "1357810926246846464",
        "media_url_https" : "https://pbs.twimg.com/media/Etfp1-sWYAANvtM.jpg",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "medium" : {
            "w" : "1036",
            "h" : "540",
            "resize" : "fit"
          },
          "small" : {
            "w" : "680",
            "h" : "354",
            "resize" : "fit"
          },
          "large" : {
            "w" : "1036",
            "h" : "540",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/TpO6cnDJHK"
      } ],
      "hashtags" : [ ]
    },
    "display_text_range" : [ "0", "114" ],
    "favorite_count" : "1",
    "id_str" : "1357810929753325574",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1357810929753325574",
    "possibly_sensitive" : false,
    "created_at" : "Fri Feb 05 21:58:47 +0000 2021",
    "favorited" : false,
    "full_text" : "Ubi-comp baby. ⁦\n\n@internetofshit⁩ is just getting started.\n\nSensors  e v e r y w h e r e. https://t.co/TpO6cnDJHK",
    "lang" : "en",
    "extended_entities" : {
      "media" : [ {
        "expanded_url" : "https://twitter.com/cybercody/status/1357810929753325574/photo/1",
        "indices" : [ "91", "114" ],
        "url" : "https://t.co/TpO6cnDJHK",
        "media_url" : "http://pbs.twimg.com/media/Etfp1-sWYAANvtM.jpg",
        "id_str" : "1357810926246846464",
        "id" : "1357810926246846464",
        "media_url_https" : "https://pbs.twimg.com/media/Etfp1-sWYAANvtM.jpg",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "medium" : {
            "w" : "1036",
            "h" : "540",
            "resize" : "fit"
          },
          "small" : {
            "w" : "680",
            "h" : "354",
            "resize" : "fit"
          },
          "large" : {
            "w" : "1036",
            "h" : "540",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/TpO6cnDJHK"
      } ]
    }
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "Joseph Alessio ☻",
        "screen_name" : "alessio_joseph",
        "indices" : [ "0", "15" ],
        "id_str" : "570260898",
        "id" : "570260898"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "35" ],
    "favorite_count" : "1",
    "in_reply_to_status_id_str" : "1357355930157871104",
    "id_str" : "1357385892839653377",
    "in_reply_to_user_id" : "570260898",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1357385892839653377",
    "in_reply_to_status_id" : "1357355930157871104",
    "created_at" : "Thu Feb 04 17:49:50 +0000 2021",
    "favorited" : false,
    "full_text" : "@alessio_joseph ✨👇✨\n👉🙂👈\n🪞📱🪞\n👉🙃👈\n✨👆✨",
    "lang" : "und",
    "in_reply_to_screen_name" : "alessio_joseph",
    "in_reply_to_user_id_str" : "570260898"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "Axios",
        "screen_name" : "axios",
        "indices" : [ "0", "6" ],
        "id_str" : "800707492346925056",
        "id" : "800707492346925056"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "44" ],
    "favorite_count" : "2",
    "in_reply_to_status_id_str" : "1354444621066207239",
    "id_str" : "1355251445818413056",
    "in_reply_to_user_id" : "800707492346925056",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1355251445818413056",
    "in_reply_to_status_id" : "1354444621066207239",
    "created_at" : "Fri Jan 29 20:28:18 +0000 2021",
    "favorited" : false,
    "full_text" : "@axios 🙌 Smart way to advertise a newsletter",
    "lang" : "en",
    "in_reply_to_screen_name" : "axios",
    "in_reply_to_user_id_str" : "800707492346925056"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ {
        "text" : "AMC",
        "indices" : [ "41", "45" ]
      } ],
      "user_mentions" : [ {
        "name" : "cline / knilly 🎮 🇵🇭",
        "screen_name" : "clineamb",
        "indices" : [ "0", "9" ],
        "id_str" : "306022732",
        "id" : "306022732"
      }, {
        "name" : "Cash App",
        "screen_name" : "CashApp",
        "indices" : [ "28", "36" ],
        "id_str" : "1445650784",
        "id" : "1445650784"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "103" ],
    "favorite_count" : "1",
    "in_reply_to_status_id_str" : "1354845631467151369",
    "id_str" : "1354876508356177922",
    "in_reply_to_user_id" : "306022732",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1354876508356177922",
    "in_reply_to_status_id" : "1354845631467151369",
    "created_at" : "Thu Jan 28 19:38:26 +0000 2021",
    "favorited" : false,
    "full_text" : "@clineamb I was able to use @CashApp for $AMC. They don’t have many stocks, but I wanted to take part 🥺",
    "lang" : "en",
    "in_reply_to_screen_name" : "clineamb",
    "in_reply_to_user_id_str" : "306022732"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "Trung Phan 🇨🇦",
        "screen_name" : "TrungTPhan",
        "indices" : [ "1", "12" ],
        "id_str" : "945817135816654848",
        "id" : "945817135816654848"
      } ],
      "urls" : [ {
        "url" : "https://t.co/XSzOJMX1au",
        "expanded_url" : "https://twitter.com/TrungTPhan/status/1354829791468298242",
        "display_url" : "twitter.com/TrungTPhan/sta…",
        "indices" : [ "30", "53" ]
      } ]
    },
    "display_text_range" : [ "0", "53" ],
    "favorite_count" : "1",
    "in_reply_to_status_id_str" : "1354812039915474951",
    "id_str" : "1354836765446705156",
    "in_reply_to_user_id" : "14321476",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1354836765446705156",
    "in_reply_to_status_id" : "1354812039915474951",
    "possibly_sensitive" : false,
    "created_at" : "Thu Jan 28 17:00:31 +0000 2021",
    "favorited" : false,
    "full_text" : ".@TrungTPhan found the answer\nhttps://t.co/XSzOJMX1au",
    "lang" : "en",
    "in_reply_to_screen_name" : "cybercody",
    "in_reply_to_user_id_str" : "14321476"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ ],
      "urls" : [ ],
      "symbols" : [ ],
      "media" : [ {
        "expanded_url" : "https://twitter.com/cybercody/status/1354812039915474951/photo/1",
        "indices" : [ "129", "152" ],
        "url" : "https://t.co/kOW0uFwTh6",
        "media_url" : "http://pbs.twimg.com/media/Es1CXggUwAAJYSf.jpg",
        "id_str" : "1354812034538323968",
        "id" : "1354812034538323968",
        "media_url_https" : "https://pbs.twimg.com/media/Es1CXggUwAAJYSf.jpg",
        "sizes" : {
          "medium" : {
            "w" : "1170",
            "h" : "929",
            "resize" : "fit"
          },
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "small" : {
            "w" : "680",
            "h" : "540",
            "resize" : "fit"
          },
          "large" : {
            "w" : "1170",
            "h" : "929",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/kOW0uFwTh6"
      } ],
      "hashtags" : [ ]
    },
    "display_text_range" : [ "0", "152" ],
    "favorite_count" : "4",
    "id_str" : "1354812039915474951",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1354812039915474951",
    "possibly_sensitive" : false,
    "created_at" : "Thu Jan 28 15:22:16 +0000 2021",
    "favorited" : false,
    "full_text" : "Robinhood better be getting bribed or blackmailed to stop the WSB trades, this coulda been their moment. Their ROBINHOOD moment. https://t.co/kOW0uFwTh6",
    "lang" : "en",
    "extended_entities" : {
      "media" : [ {
        "expanded_url" : "https://twitter.com/cybercody/status/1354812039915474951/photo/1",
        "indices" : [ "129", "152" ],
        "url" : "https://t.co/kOW0uFwTh6",
        "media_url" : "http://pbs.twimg.com/media/Es1CXggUwAAJYSf.jpg",
        "id_str" : "1354812034538323968",
        "id" : "1354812034538323968",
        "media_url_https" : "https://pbs.twimg.com/media/Es1CXggUwAAJYSf.jpg",
        "sizes" : {
          "medium" : {
            "w" : "1170",
            "h" : "929",
            "resize" : "fit"
          },
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "small" : {
            "w" : "680",
            "h" : "540",
            "resize" : "fit"
          },
          "large" : {
            "w" : "1170",
            "h" : "929",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/kOW0uFwTh6"
      } ]
    }
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "SIMD Crawford",
        "screen_name" : "omershapira",
        "indices" : [ "0", "12" ],
        "id_str" : "55855791",
        "id" : "55855791"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "88" ],
    "favorite_count" : "3",
    "in_reply_to_status_id_str" : "1367505812458008579",
    "id_str" : "1367508135196430346",
    "in_reply_to_user_id" : "55855791",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1367508135196430346",
    "in_reply_to_status_id" : "1367505812458008579",
    "created_at" : "Thu Mar 04 16:12:01 +0000 2021",
    "favorited" : false,
    "full_text" : "@omershapira If I cremate myself and mint an NFT of myself, is that how I upload myself?",
    "lang" : "en",
    "in_reply_to_screen_name" : "omershapira",
    "in_reply_to_user_id_str" : "55855791"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "SpaceX",
        "screen_name" : "SpaceX",
        "indices" : [ "12", "19" ],
        "id_str" : "34743251",
        "id" : "34743251"
      } ],
      "urls" : [ ],
      "symbols" : [ ],
      "media" : [ {
        "expanded_url" : "https://twitter.com/cybercody/status/1367277781856493570/video/1",
        "indices" : [ "49", "72" ],
        "url" : "https://t.co/rWIIAnJMbx",
        "media_url" : "http://pbs.twimg.com/ext_tw_video_thumb/1367276950704775168/pu/img/9ajFHTUtUAZBOtjU.jpg",
        "id_str" : "1367276950704775168",
        "id" : "1367276950704775168",
        "media_url_https" : "https://pbs.twimg.com/ext_tw_video_thumb/1367276950704775168/pu/img/9ajFHTUtUAZBOtjU.jpg",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "medium" : {
            "w" : "1182",
            "h" : "720",
            "resize" : "fit"
          },
          "small" : {
            "w" : "680",
            "h" : "414",
            "resize" : "fit"
          },
          "large" : {
            "w" : "1182",
            "h" : "720",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/rWIIAnJMbx"
      } ],
      "hashtags" : [ ]
    },
    "display_text_range" : [ "0", "72" ],
    "favorite_count" : "4",
    "id_str" : "1367277781856493570",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1367277781856493570",
    "possibly_sensitive" : false,
    "created_at" : "Thu Mar 04 00:56:40 +0000 2021",
    "favorited" : false,
    "full_text" : "Congrats to @SpaceX on this beautiful maneuver 🤯 https://t.co/rWIIAnJMbx",
    "lang" : "en",
    "extended_entities" : {
      "media" : [ {
        "expanded_url" : "https://twitter.com/cybercody/status/1367277781856493570/video/1",
        "indices" : [ "49", "72" ],
        "url" : "https://t.co/rWIIAnJMbx",
        "media_url" : "http://pbs.twimg.com/ext_tw_video_thumb/1367276950704775168/pu/img/9ajFHTUtUAZBOtjU.jpg",
        "id_str" : "1367276950704775168",
        "video_info" : {
          "aspect_ratio" : [ "197", "120" ],
          "duration_millis" : "28850",
          "variants" : [ {
            "content_type" : "application/x-mpegURL",
            "url" : "https://video.twimg.com/ext_tw_video/1367276950704775168/pu/pl/1gxDpzqbW1cWiMwa.m3u8?tag=10"
          }, {
            "bitrate" : "256000",
            "content_type" : "video/mp4",
            "url" : "https://video.twimg.com/ext_tw_video/1367276950704775168/pu/vid/442x270/rxxmz8PVsKun5qDS.mp4?tag=10"
          }, {
            "bitrate" : "832000",
            "content_type" : "video/mp4",
            "url" : "https://video.twimg.com/ext_tw_video/1367276950704775168/pu/vid/590x360/spEfWj6E-7PHwIk9.mp4?tag=10"
          }, {
            "bitrate" : "2176000",
            "content_type" : "video/mp4",
            "url" : "https://video.twimg.com/ext_tw_video/1367276950704775168/pu/vid/1182x720/5PogD38kQRFNCdT0.mp4?tag=10"
          } ]
        },
        "additional_media_info" : {
          "monetizable" : false
        },
        "id" : "1367276950704775168",
        "media_url_https" : "https://pbs.twimg.com/ext_tw_video_thumb/1367276950704775168/pu/img/9ajFHTUtUAZBOtjU.jpg",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "medium" : {
            "w" : "1182",
            "h" : "720",
            "resize" : "fit"
          },
          "small" : {
            "w" : "680",
            "h" : "414",
            "resize" : "fit"
          },
          "large" : {
            "w" : "1182",
            "h" : "720",
            "resize" : "fit"
          }
        },
        "type" : "video",
        "display_url" : "pic.twitter.com/rWIIAnJMbx"
      } ]
    }
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "PBS1982",
        "screen_name" : "PBS1982",
        "indices" : [ "0", "8" ],
        "id_str" : "56613353",
        "id" : "56613353"
      }, {
        "name" : "Give Tara Dublin Josh Hawley’s Book Deal",
        "screen_name" : "taradublinrocks",
        "indices" : [ "9", "25" ],
        "id_str" : "51241418",
        "id" : "51241418"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "184" ],
    "favorite_count" : "3",
    "in_reply_to_status_id_str" : "1366802021467234309",
    "id_str" : "1366811874948481035",
    "in_reply_to_user_id" : "56613353",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1366811874948481035",
    "in_reply_to_status_id" : "1366802021467234309",
    "created_at" : "Tue Mar 02 18:05:19 +0000 2021",
    "favorited" : false,
    "full_text" : "@PBS1982 @taradublinrocks There's a difference between the government banning/burning a book and a publisher no longer publishing a book. One is censorship, the other is a PR decision.",
    "lang" : "en",
    "in_reply_to_screen_name" : "PBS1982",
    "in_reply_to_user_id_str" : "56613353"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "57" ],
    "favorite_count" : "1",
    "id_str" : "1365409084967690244",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1365409084967690244",
    "created_at" : "Fri Feb 26 21:11:08 +0000 2021",
    "favorited" : false,
    "full_text" : "“Are we influencers yet? I sent my mom our photo.”\n- Mark",
    "lang" : "en"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "New York Times Opinion",
        "screen_name" : "nytopinion",
        "indices" : [ "3", "14" ],
        "id_str" : "16686144",
        "id" : "16686144"
      }, {
        "name" : "Sacha Baron Cohen",
        "screen_name" : "SachaBaronCohen",
        "indices" : [ "98", "114" ],
        "id_str" : "4185877812",
        "id" : "4185877812"
      }, {
        "name" : "Kara Swisher",
        "screen_name" : "karaswisher",
        "indices" : [ "121", "133" ],
        "id_str" : "5763262",
        "id" : "5763262"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "140" ],
    "favorite_count" : "0",
    "id_str" : "1365325696768294917",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1365325696768294917",
    "created_at" : "Fri Feb 26 15:39:47 +0000 2021",
    "favorited" : false,
    "full_text" : "RT @nytopinion: “When Mark Zuckerberg just says, ‘I'm the defender of free speech,’ he is lying,” @SachaBaronCohen tells @karaswisher on to…",
    "lang" : "en"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "Robert Vinluan",
        "screen_name" : "RobertVinluan",
        "indices" : [ "0", "14" ],
        "id_str" : "461429820",
        "id" : "461429820"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "53" ],
    "favorite_count" : "1",
    "in_reply_to_status_id_str" : "1364630885916631048",
    "id_str" : "1364679227585540097",
    "in_reply_to_user_id" : "461429820",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1364679227585540097",
    "in_reply_to_status_id" : "1364630885916631048",
    "created_at" : "Wed Feb 24 20:50:57 +0000 2021",
    "favorited" : false,
    "full_text" : "@RobertVinluan Damn, guess I better take more selfies",
    "lang" : "en",
    "in_reply_to_screen_name" : "RobertVinluan",
    "in_reply_to_user_id_str" : "461429820"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "vishal pundir",
        "screen_name" : "vishalpundir49",
        "indices" : [ "0", "15" ],
        "id_str" : "1256722164",
        "id" : "1256722164"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "151" ],
    "favorite_count" : "0",
    "in_reply_to_status_id_str" : "1363803155239038981",
    "id_str" : "1364638713892978692",
    "in_reply_to_user_id" : "1256722164",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1364638713892978692",
    "in_reply_to_status_id" : "1363803155239038981",
    "created_at" : "Wed Feb 24 18:09:57 +0000 2021",
    "favorited" : false,
    "full_text" : "@vishalpundir49 You're welcome to open a PR or fork! I no longer work in Angular, so I wouldn't know where to start in terms of updating to support 10.",
    "lang" : "en",
    "in_reply_to_screen_name" : "vishalpundir49",
    "in_reply_to_user_id_str" : "1256722164"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "Tyler Hall",
        "screen_name" : "tylerhall",
        "indices" : [ "0", "10" ],
        "id_str" : "979861",
        "id" : "979861"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "37" ],
    "favorite_count" : "1",
    "in_reply_to_status_id_str" : "1364342283227848704",
    "id_str" : "1364348671966515203",
    "in_reply_to_user_id" : "979861",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1364348671966515203",
    "in_reply_to_status_id" : "1364342283227848704",
    "created_at" : "Tue Feb 23 22:57:26 +0000 2021",
    "favorited" : false,
    "full_text" : "@tylerhall How very Doordash of them.",
    "lang" : "en",
    "in_reply_to_screen_name" : "tylerhall",
    "in_reply_to_user_id_str" : "979861"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Robert Vinluan",
        "screen_name" : "RobertVinluan",
        "indices" : [ "0", "14" ],
        "id_str" : "461429820",
        "id" : "461429820"
      } ],
      "urls" : [ ],
      "symbols" : [ ],
      "media" : [ {
        "expanded_url" : "https://twitter.com/cybercody/status/1364348318487351296/photo/1",
        "indices" : [ "15", "38" ],
        "url" : "https://t.co/IONrBMjR1K",
        "media_url" : "http://pbs.twimg.com/tweet_video_thumb/Eu8jj3kVkAAunF_.jpg",
        "id_str" : "1364348311235301376",
        "id" : "1364348311235301376",
        "media_url_https" : "https://pbs.twimg.com/tweet_video_thumb/Eu8jj3kVkAAunF_.jpg",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "medium" : {
            "w" : "244",
            "h" : "180",
            "resize" : "fit"
          },
          "small" : {
            "w" : "244",
            "h" : "180",
            "resize" : "fit"
          },
          "large" : {
            "w" : "244",
            "h" : "180",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/IONrBMjR1K"
      } ],
      "hashtags" : [ ]
    },
    "display_text_range" : [ "0", "38" ],
    "favorite_count" : "1",
    "in_reply_to_status_id_str" : "1364346060165021702",
    "id_str" : "1364348318487351296",
    "in_reply_to_user_id" : "461429820",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1364348318487351296",
    "in_reply_to_status_id" : "1364346060165021702",
    "possibly_sensitive" : false,
    "created_at" : "Tue Feb 23 22:56:02 +0000 2021",
    "favorited" : false,
    "full_text" : "@RobertVinluan https://t.co/IONrBMjR1K",
    "lang" : "und",
    "in_reply_to_screen_name" : "RobertVinluan",
    "in_reply_to_user_id_str" : "461429820",
    "extended_entities" : {
      "media" : [ {
        "expanded_url" : "https://twitter.com/cybercody/status/1364348318487351296/photo/1",
        "indices" : [ "15", "38" ],
        "url" : "https://t.co/IONrBMjR1K",
        "media_url" : "http://pbs.twimg.com/tweet_video_thumb/Eu8jj3kVkAAunF_.jpg",
        "id_str" : "1364348311235301376",
        "video_info" : {
          "aspect_ratio" : [ "61", "45" ],
          "variants" : [ {
            "bitrate" : "0",
            "content_type" : "video/mp4",
            "url" : "https://video.twimg.com/tweet_video/Eu8jj3kVkAAunF_.mp4"
          } ]
        },
        "id" : "1364348311235301376",
        "media_url_https" : "https://pbs.twimg.com/tweet_video_thumb/Eu8jj3kVkAAunF_.jpg",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "medium" : {
            "w" : "244",
            "h" : "180",
            "resize" : "fit"
          },
          "small" : {
            "w" : "244",
            "h" : "180",
            "resize" : "fit"
          },
          "large" : {
            "w" : "244",
            "h" : "180",
            "resize" : "fit"
          }
        },
        "type" : "animated_gif",
        "display_url" : "pic.twitter.com/IONrBMjR1K"
      } ]
    }
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Aizya Mc🐝✨",
        "screen_name" : "aizya_mc",
        "indices" : [ "0", "9" ],
        "id_str" : "518040577",
        "id" : "518040577"
      } ],
      "urls" : [ ],
      "symbols" : [ ],
      "media" : [ {
        "expanded_url" : "https://twitter.com/cybercody/status/1364048192992661505/photo/1",
        "indices" : [ "10", "33" ],
        "url" : "https://t.co/Izya7orNcR",
        "media_url" : "http://pbs.twimg.com/tweet_video_thumb/Eu4SmXZXAAIn5_a.jpg",
        "id_str" : "1364048187464548354",
        "id" : "1364048187464548354",
        "media_url_https" : "https://pbs.twimg.com/tweet_video_thumb/Eu4SmXZXAAIn5_a.jpg",
        "sizes" : {
          "small" : {
            "w" : "500",
            "h" : "282",
            "resize" : "fit"
          },
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "large" : {
            "w" : "500",
            "h" : "282",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "500",
            "h" : "282",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/Izya7orNcR"
      } ],
      "hashtags" : [ ]
    },
    "display_text_range" : [ "0", "33" ],
    "favorite_count" : "1",
    "in_reply_to_status_id_str" : "1364037332072980480",
    "id_str" : "1364048192992661505",
    "in_reply_to_user_id" : "518040577",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1364048192992661505",
    "in_reply_to_status_id" : "1364037332072980480",
    "possibly_sensitive" : false,
    "created_at" : "Tue Feb 23 03:03:26 +0000 2021",
    "favorited" : false,
    "full_text" : "@aizya_mc https://t.co/Izya7orNcR",
    "lang" : "und",
    "in_reply_to_screen_name" : "aizya_mc",
    "in_reply_to_user_id_str" : "518040577",
    "extended_entities" : {
      "media" : [ {
        "expanded_url" : "https://twitter.com/cybercody/status/1364048192992661505/photo/1",
        "indices" : [ "10", "33" ],
        "url" : "https://t.co/Izya7orNcR",
        "media_url" : "http://pbs.twimg.com/tweet_video_thumb/Eu4SmXZXAAIn5_a.jpg",
        "id_str" : "1364048187464548354",
        "video_info" : {
          "aspect_ratio" : [ "250", "141" ],
          "variants" : [ {
            "bitrate" : "0",
            "content_type" : "video/mp4",
            "url" : "https://video.twimg.com/tweet_video/Eu4SmXZXAAIn5_a.mp4"
          } ]
        },
        "id" : "1364048187464548354",
        "media_url_https" : "https://pbs.twimg.com/tweet_video_thumb/Eu4SmXZXAAIn5_a.jpg",
        "sizes" : {
          "small" : {
            "w" : "500",
            "h" : "282",
            "resize" : "fit"
          },
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "large" : {
            "w" : "500",
            "h" : "282",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "500",
            "h" : "282",
            "resize" : "fit"
          }
        },
        "type" : "animated_gif",
        "display_url" : "pic.twitter.com/Izya7orNcR"
      } ]
    }
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "Trung Phan 🇨🇦",
        "screen_name" : "TrungTPhan",
        "indices" : [ "0", "11" ],
        "id_str" : "945817135816654848",
        "id" : "945817135816654848"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "33" ],
    "favorite_count" : "0",
    "in_reply_to_status_id_str" : "1364011304629854208",
    "id_str" : "1364037552399859714",
    "in_reply_to_user_id" : "945817135816654848",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1364037552399859714",
    "in_reply_to_status_id" : "1364011304629854208",
    "created_at" : "Tue Feb 23 02:21:09 +0000 2021",
    "favorited" : false,
    "full_text" : "@TrungTPhan You didn’t have to 😂💀",
    "lang" : "en",
    "in_reply_to_screen_name" : "TrungTPhan",
    "in_reply_to_user_id_str" : "945817135816654848"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "Aizya Mc🐝✨",
        "screen_name" : "aizya_mc",
        "indices" : [ "0", "9" ],
        "id_str" : "518040577",
        "id" : "518040577"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "99" ],
    "favorite_count" : "0",
    "in_reply_to_status_id_str" : "1363991438187401217",
    "id_str" : "1364036697680412677",
    "in_reply_to_user_id" : "518040577",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1364036697680412677",
    "in_reply_to_status_id" : "1363991438187401217",
    "created_at" : "Tue Feb 23 02:17:45 +0000 2021",
    "favorited" : false,
    "full_text" : "@aizya_mc Is this what you call the need/want to move every few years, or are you actually moving??",
    "lang" : "en",
    "in_reply_to_screen_name" : "aizya_mc",
    "in_reply_to_user_id_str" : "518040577"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "Amanda Silver #BlackLivesMatter #ShiftLeft",
        "screen_name" : "amandaksilver",
        "indices" : [ "3", "17" ],
        "id_str" : "217129165",
        "id" : "217129165"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "84" ],
    "favorite_count" : "0",
    "id_str" : "1363991125556666374",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1363991125556666374",
    "created_at" : "Mon Feb 22 23:16:40 +0000 2021",
    "favorited" : false,
    "full_text" : "RT @amandaksilver: 4 yo: “Each time I learn something new, I become more beautiful.”",
    "lang" : "en"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Wow Bao",
        "screen_name" : "WowBao",
        "indices" : [ "0", "7" ],
        "id_str" : "20687198",
        "id" : "20687198"
      } ],
      "urls" : [ ],
      "symbols" : [ ],
      "media" : [ {
        "expanded_url" : "https://twitter.com/cybercody/status/1363646509733060613/photo/1",
        "indices" : [ "48", "71" ],
        "url" : "https://t.co/s9xIapSGbe",
        "media_url" : "http://pbs.twimg.com/media/EuylRcgXMAk2Wdi.jpg",
        "id_str" : "1363646506314706953",
        "id" : "1363646506314706953",
        "media_url_https" : "https://pbs.twimg.com/media/EuylRcgXMAk2Wdi.jpg",
        "sizes" : {
          "small" : {
            "w" : "680",
            "h" : "535",
            "resize" : "fit"
          },
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "medium" : {
            "w" : "1170",
            "h" : "921",
            "resize" : "fit"
          },
          "large" : {
            "w" : "1170",
            "h" : "921",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/s9xIapSGbe"
      } ],
      "hashtags" : [ ]
    },
    "display_text_range" : [ "0", "71" ],
    "favorite_count" : "0",
    "id_str" : "1363646509733060613",
    "in_reply_to_user_id" : "20687198",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1363646509733060613",
    "possibly_sensitive" : false,
    "created_at" : "Mon Feb 22 00:27:17 +0000 2021",
    "favorited" : false,
    "full_text" : "@WowBao Did your Minneapolis locations close? 😟 https://t.co/s9xIapSGbe",
    "lang" : "en",
    "in_reply_to_screen_name" : "WowBao",
    "in_reply_to_user_id_str" : "20687198",
    "extended_entities" : {
      "media" : [ {
        "expanded_url" : "https://twitter.com/cybercody/status/1363646509733060613/photo/1",
        "indices" : [ "48", "71" ],
        "url" : "https://t.co/s9xIapSGbe",
        "media_url" : "http://pbs.twimg.com/media/EuylRcgXMAk2Wdi.jpg",
        "id_str" : "1363646506314706953",
        "id" : "1363646506314706953",
        "media_url_https" : "https://pbs.twimg.com/media/EuylRcgXMAk2Wdi.jpg",
        "sizes" : {
          "small" : {
            "w" : "680",
            "h" : "535",
            "resize" : "fit"
          },
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "medium" : {
            "w" : "1170",
            "h" : "921",
            "resize" : "fit"
          },
          "large" : {
            "w" : "1170",
            "h" : "921",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/s9xIapSGbe"
      } ]
    }
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "Marcos Pereira",
        "screen_name" : "voxelbased",
        "indices" : [ "0", "11" ],
        "id_str" : "299806401",
        "id" : "299806401"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "281" ],
    "favorite_count" : "1",
    "in_reply_to_status_id_str" : "1363584189346545665",
    "id_str" : "1363626674676498439",
    "in_reply_to_user_id" : "299806401",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1363626674676498439",
    "in_reply_to_status_id" : "1363584189346545665",
    "created_at" : "Sun Feb 21 23:08:28 +0000 2021",
    "favorited" : false,
    "full_text" : "@voxelbased I’ve wondered along these lines before. A brute force search should theoretically be possible assuming:\n- Power/space to generate full problem space\n- Power to search problem space for best solution\nBut we’re behind by orders of magnitude in compute power/space. Right?",
    "lang" : "en",
    "in_reply_to_screen_name" : "voxelbased",
    "in_reply_to_user_id_str" : "299806401"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NASA's Perseverance Mars Rover",
        "screen_name" : "NASAPersevere",
        "indices" : [ "204", "218" ],
        "id_str" : "1232783237623119872",
        "id" : "1232783237623119872"
      } ],
      "urls" : [ {
        "url" : "https://t.co/bE4a8Ynvil",
        "expanded_url" : "https://www.youtube.com/watch?vSource5ZNopM",
        "display_url" : "youtube.com/watch?vSource5…",
        "indices" : [ "171", "194" ]
      } ],
      "symbols" : [ ],
      "media" : [ {
        "expanded_url" : "https://twitter.com/cybercody/status/1362829996096712708/photo/1",
        "indices" : [ "220", "243" ],
        "url" : "https://t.co/j0bSZewJiP",
        "media_url" : "http://pbs.twimg.com/media/Eum-qE4XMAIMHxF.jpg",
        "id_str" : "1362829992330211330",
        "id" : "1362829992330211330",
        "media_url_https" : "https://pbs.twimg.com/media/Eum-qE4XMAIMHxF.jpg",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "large" : {
            "w" : "1600",
            "h" : "1196",
            "resize" : "fit"
          },
          "small" : {
            "w" : "680",
            "h" : "508",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "1200",
            "h" : "897",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/j0bSZewJiP"
      } ],
      "hashtags" : [ ]
    },
    "display_text_range" : [ "0", "243" ],
    "favorite_count" : "0",
    "id_str" : "1362829996096712708",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1362829996096712708",
    "possibly_sensitive" : false,
    "created_at" : "Fri Feb 19 18:22:45 +0000 2021",
    "favorited" : false,
    "full_text" : "In today’s press conference, Pauline at NASA shared we can expect full resolution images from the Perseverance mast cam this weekend, but for now we have these ✨\n(source: https://t.co/bE4a8Ynvil, credit: @NASAPersevere) https://t.co/j0bSZewJiP",
    "lang" : "en",
    "extended_entities" : {
      "media" : [ {
        "expanded_url" : "https://twitter.com/cybercody/status/1362829996096712708/photo/1",
        "indices" : [ "220", "243" ],
        "url" : "https://t.co/j0bSZewJiP",
        "media_url" : "http://pbs.twimg.com/media/Eum-qE4XMAIMHxF.jpg",
        "id_str" : "1362829992330211330",
        "id" : "1362829992330211330",
        "media_url_https" : "https://pbs.twimg.com/media/Eum-qE4XMAIMHxF.jpg",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "large" : {
            "w" : "1600",
            "h" : "1196",
            "resize" : "fit"
          },
          "small" : {
            "w" : "680",
            "h" : "508",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "1200",
            "h" : "897",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/j0bSZewJiP"
      }, {
        "expanded_url" : "https://twitter.com/cybercody/status/1362829996096712708/photo/1",
        "indices" : [ "220", "243" ],
        "url" : "https://t.co/j0bSZewJiP",
        "media_url" : "http://pbs.twimg.com/media/Eum-qE7XUAEYmLf.jpg",
        "id_str" : "1362829992342802433",
        "id" : "1362829992342802433",
        "media_url_https" : "https://pbs.twimg.com/media/Eum-qE7XUAEYmLf.jpg",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "medium" : {
            "w" : "1200",
            "h" : "896",
            "resize" : "fit"
          },
          "large" : {
            "w" : "1588",
            "h" : "1186",
            "resize" : "fit"
          },
          "small" : {
            "w" : "680",
            "h" : "508",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/j0bSZewJiP"
      }, {
        "expanded_url" : "https://twitter.com/cybercody/status/1362829996096712708/photo/1",
        "indices" : [ "220", "243" ],
        "url" : "https://t.co/j0bSZewJiP",
        "media_url" : "http://pbs.twimg.com/media/Eum-qE7WQAAbEDn.jpg",
        "id_str" : "1362829992342732800",
        "id" : "1362829992342732800",
        "media_url_https" : "https://pbs.twimg.com/media/Eum-qE7WQAAbEDn.jpg",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "medium" : {
            "w" : "1200",
            "h" : "902",
            "resize" : "fit"
          },
          "large" : {
            "w" : "1592",
            "h" : "1196",
            "resize" : "fit"
          },
          "small" : {
            "w" : "680",
            "h" : "511",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/j0bSZewJiP"
      } ]
    }
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "Luqman",
        "screen_name" : "_MLuqman_",
        "indices" : [ "0", "10" ],
        "id_str" : "1236783741588168704",
        "id" : "1236783741588168704"
      }, {
        "name" : "Neil Cybart",
        "screen_name" : "neilcybart",
        "indices" : [ "11", "22" ],
        "id_str" : "164726768",
        "id" : "164726768"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "100" ],
    "favorite_count" : "0",
    "in_reply_to_status_id_str" : "1362818820927275009",
    "id_str" : "1362821755115569158",
    "in_reply_to_user_id" : "1236783741588168704",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1362821755115569158",
    "in_reply_to_status_id" : "1362818820927275009",
    "created_at" : "Fri Feb 19 17:50:01 +0000 2021",
    "favorited" : false,
    "full_text" : "@_MLuqman_ @neilcybart I had no idea that pinning lists made them into swipe-able tabs! Thank you! 🎉",
    "lang" : "en",
    "in_reply_to_screen_name" : "_MLuqman_",
    "in_reply_to_user_id_str" : "1236783741588168704"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/rQiNeVvOFq",
        "expanded_url" : "https://twitter.com/NASAPersevere/status/1362507436611956736",
        "display_url" : "twitter.com/NASAPersevere/…",
        "indices" : [ "33", "56" ]
      } ]
    },
    "display_text_range" : [ "0", "56" ],
    "favorite_count" : "1",
    "id_str" : "1362507656569757699",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1362507656569757699",
    "possibly_sensitive" : false,
    "created_at" : "Thu Feb 18 21:01:54 +0000 2021",
    "favorited" : false,
    "full_text" : "First pics from Perseverance ☺️👏 https://t.co/rQiNeVvOFq",
    "lang" : "en"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "cline / knilly 🎮 🇵🇭",
        "screen_name" : "clineamb",
        "indices" : [ "0", "9" ],
        "id_str" : "306022732",
        "id" : "306022732"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "37" ],
    "favorite_count" : "1",
    "in_reply_to_status_id_str" : "1362506841171906564",
    "id_str" : "1362507275081031686",
    "in_reply_to_user_id" : "306022732",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1362507275081031686",
    "in_reply_to_status_id" : "1362506841171906564",
    "created_at" : "Thu Feb 18 21:00:23 +0000 2021",
    "favorited" : false,
    "full_text" : "@clineamb I’m jumping up and done 🙌🙌🙌",
    "lang" : "en",
    "in_reply_to_screen_name" : "clineamb",
    "in_reply_to_user_id_str" : "306022732"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "NASA JPL",
        "screen_name" : "NASAJPL",
        "indices" : [ "14", "22" ],
        "id_str" : "19802879",
        "id" : "19802879"
      } ],
      "urls" : [ {
        "url" : "https://t.co/ymu08IDBEq",
        "expanded_url" : "https://twitter.com/NASAPersevere/status/1362506126839848961",
        "display_url" : "twitter.com/NASAPersevere/…",
        "indices" : [ "24", "47" ]
      } ]
    },
    "display_text_range" : [ "0", "47" ],
    "favorite_count" : "0",
    "id_str" : "1362506555367776258",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1362506555367776258",
    "possibly_sensitive" : false,
    "created_at" : "Thu Feb 18 20:57:31 +0000 2021",
    "favorited" : false,
    "full_text" : "Well done! Go @NASAJPL! https://t.co/ymu08IDBEq",
    "lang" : "en"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "NASA's Perseverance Mars Rover",
        "screen_name" : "NASAPersevere",
        "indices" : [ "3", "17" ],
        "id_str" : "1232783237623119872",
        "id" : "1232783237623119872"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "140" ],
    "favorite_count" : "0",
    "id_str" : "1362505532498731012",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1362505532498731012",
    "created_at" : "Thu Feb 18 20:53:27 +0000 2021",
    "favorited" : false,
    "full_text" : "RT @NASAPersevere: Whoosh – I’ve ditched my heat shield and am looking straight at Mars for the first time! Just over 2 mins to landing.\n\n#…",
    "lang" : "en"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "jessica griscti",
        "screen_name" : "jesslovestype",
        "indices" : [ "0", "14" ],
        "id_str" : "393547465",
        "id" : "393547465"
      }, {
        "name" : "Readwise",
        "screen_name" : "readwiseio",
        "indices" : [ "15", "26" ],
        "id_str" : "920321515077414912",
        "id" : "920321515077414912"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "215" ],
    "favorite_count" : "1",
    "in_reply_to_status_id_str" : "1362480262119120900",
    "id_str" : "1362483872211095562",
    "in_reply_to_user_id" : "393547465",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1362483872211095562",
    "in_reply_to_status_id" : "1362480262119120900",
    "created_at" : "Thu Feb 18 19:27:23 +0000 2021",
    "favorited" : false,
    "full_text" : "@jesslovestype @readwiseio The Hamlet’s Mill book was such a trip, I went back to his suggested list at some point 😄\n\nIt’s a good thought provoker! Even just reading a few pages here and there, and slowly digesting.",
    "lang" : "en",
    "in_reply_to_screen_name" : "jesslovestype",
    "in_reply_to_user_id_str" : "393547465"
  }
} ]