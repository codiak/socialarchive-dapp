export const ACCOUNT = {
  "account" : {
    "email" : "x@gmail.com",
    "createdVia" : "web",
    "username" : "cybercody",
    "accountId" : "1111111",
    "createdAt" : "2008-04-07T09:35:32.000Z",
    "accountDisplayName" : "Cody"
  }
};
