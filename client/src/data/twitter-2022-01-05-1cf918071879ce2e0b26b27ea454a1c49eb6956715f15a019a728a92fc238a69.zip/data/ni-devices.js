window.YTD.ni_devices.part0 = [
  {
    "niDeviceResponse" : {
      "messagingDevice" : {
        "deviceType" : "Full",
        "carrier" : "att",
        "phoneNumber" : "+19522906724",
        "createdDate" : "2021.10.14"
      }
    }
  }
]