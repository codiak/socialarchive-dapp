window.YTD.phone_number.part0 = [
  {
    "device" : {
      "phoneNumber" : "+19522906724"
    }
  }
]