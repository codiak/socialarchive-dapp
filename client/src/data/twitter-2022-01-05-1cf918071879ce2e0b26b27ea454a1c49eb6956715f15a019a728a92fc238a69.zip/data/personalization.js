window.YTD.personalization.part0 = [
  {
    "p13nData" : {
      "demographics" : {
        "languages" : [
          {
            "language" : "English",
            "isDisabled" : false
          }
        ],
        "genderInfo" : {
          "gender" : "male"
        }
      },
      "interests" : {
        "interests" : [
          {
            "name" : "Celebrity fan and gossip",
            "isDisabled" : false
          },
          {
            "name" : "Comedy",
            "isDisabled" : false
          },
          {
            "name" : "Comedy",
            "isDisabled" : false
          },
          {
            "name" : "Dogs",
            "isDisabled" : false
          },
          {
            "name" : "Music festivals and concerts",
            "isDisabled" : false
          },
          {
            "name" : "National parks",
            "isDisabled" : false
          },
          {
            "name" : "Online gaming",
            "isDisabled" : false
          },
          {
            "name" : "Science news",
            "isDisabled" : false
          },
          {
            "name" : "Social media",
            "isDisabled" : false
          },
          {
            "name" : "Space and astronomy",
            "isDisabled" : false
          },
          {
            "name" : "Sporting events",
            "isDisabled" : false
          },
          {
            "name" : "Sports news",
            "isDisabled" : false
          },
          {
            "name" : "Sports themed",
            "isDisabled" : false
          },
          {
            "name" : "Tech news",
            "isDisabled" : false
          },
          {
            "name" : "Technology",
            "isDisabled" : false
          },
          {
            "name" : "Twitter",
            "isDisabled" : false
          },
          {
            "name" : "Weather",
            "isDisabled" : false
          }
        ],
        "partnerInterests" : [ ],
        "audienceAndAdvertisers" : {
          "numAudiences" : "56",
          "advertisers" : [
            "@CallofDuty",
            "@HBO",
            "@WonderYearsABC",
            "@adidas",
            "@fabriik_market",
            "@fold_app",
            "@hbomax",
            "@peacockTV"
          ],
          "lookalikeAdvertisers" : [
            "@LinkedIn",
            "@BusinessInsider",
            "@CallofDuty",
            "@HBO",
            "@NintendoAmerica",
            "@PayPalUK",
            "@Spotify_PH",
            "@T2InteractiveUS",
            "@WonderYearsABC",
            "@adidas",
            "@business",
            "@fabriik_market",
            "@fold_app",
            "@hbomax",
            "@intel",
            "@peacockTV"
          ]
        },
        "shows" : [ ]
      },
      "locationHistory" : [
        "Minneapolis, MN, USA",
        "LOS ANGELES, USA"
      ],
      "inferredAgeInfo" : {
        "age" : [
          "13-54"
        ],
        "birthDate" : ""
      }
    }
  }
]