window.YTD.profile.part0 = [
  {
    "profile" : {
      "description" : {
        "bio" : "MSDS candidate at CU Boulder\nML Engineering during the day",
        "website" : "",
        "location" : ""
      },
      "avatarMediaUrl" : "https://pbs.twimg.com/profile_images/1491582785965887489/cJ2rdWiF.jpg"
    }
  }
]