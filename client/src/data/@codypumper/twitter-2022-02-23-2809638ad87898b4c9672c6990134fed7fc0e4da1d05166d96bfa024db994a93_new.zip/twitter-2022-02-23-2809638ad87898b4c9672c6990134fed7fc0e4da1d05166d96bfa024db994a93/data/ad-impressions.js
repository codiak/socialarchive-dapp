window.YTD.ad_impressions.part0 = [
  {
    "ad" : {
      "adsUserData" : {
        "adImpressions" : {
          "impressions" : [
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1491446076834029568",
                "tweetText" : "Not a rule breaker? Then maybe keep scrolling. For everyone else: Get ready for #GalaxyS22 Ultra. \n\nPre-order now to get up to $200 in Samsung Credit plus double the storage on us.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "promotedTrendInfo" : {
                "trendId" : "86103",
                "name" : "#GalaxyS22",
                "description" : "Pre-order now"
              },
              "advertiserInfo" : {
                "advertiserName" : "Samsung Mobile US",
                "screenName" : "@SamsungMobileUS"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "United States"
                }
              ],
              "impressionTime" : "2022-02-18 15:16:02"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "WtfSidebar",
              "advertiserInfo" : {
                "advertiserName" : "1inch Network",
                "screenName" : "@1inch"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "Cryptocurrencies"
                },
                {
                  "targetingType" : "Conversation topics"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "crypto"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "#ethereum"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "decentralisation"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "ethereum"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "decentralization"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "United States"
                }
              ],
              "impressionTime" : "2022-02-18 15:16:01"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "WtfSidebar",
              "advertiserInfo" : {
                "advertiserName" : "1inch Network",
                "screenName" : "@1inch"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "Cryptocurrencies"
                },
                {
                  "targetingType" : "Conversation topics"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "decentralisation"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "#ethereum"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "ethereum"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "decentralization"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "crypto"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "United States"
                }
              ],
              "impressionTime" : "2022-02-18 15:16:02"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "ProfileAccountsSidebar",
              "advertiserInfo" : {
                "advertiserName" : "1inch Network",
                "screenName" : "@1inch"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "Cryptocurrencies"
                },
                {
                  "targetingType" : "Conversation topics"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "decentralisation"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "#ethereum"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "crypto"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "decentralization"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "ethereum"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "United States"
                }
              ],
              "impressionTime" : "2022-02-18 19:06:28"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "WtfSidebar",
              "advertiserInfo" : {
                "advertiserName" : "Uniper",
                "screenName" : "@uniper_energy"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "#artificialintelligence #machinelearning"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "#technology"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "#technews"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "technology"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "business technology"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "technologies"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "#artificialintelligence"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "technology's"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "artificial intelligence"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "digital technologies"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "United States"
                }
              ],
              "impressionTime" : "2022-02-18 19:05:30"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1491109269571129350",
                "tweetText" : "RT @cryptocomnft: Newk3d is a Norwegian 3D artist with a passion for digital art.\n\nHis second collection \"CRYPTOSKELETONS\" are the skeletal…",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Crypto.com",
                "screenName" : "@cryptocom"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "blockchain application"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "how to mint nft art"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "blockchain applications"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "nft blockchain"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "nft's"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "Desktop"
                },
                {
                  "targetingType" : "Languages",
                  "targetingValue" : "English"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "California"
                }
              ],
              "impressionTime" : "2022-02-18 19:05:32"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "WtfSidebar",
              "advertiserInfo" : {
                "advertiserName" : "STL - Sterlite Technologies Limited",
                "screenName" : "@STL_Tech"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "United States"
                }
              ],
              "impressionTime" : "2022-02-18 19:05:31"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "ProfileAccountsSidebar",
              "advertiserInfo" : {
                "advertiserName" : "1inch Network",
                "screenName" : "@1inch"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "Cryptocurrencies"
                },
                {
                  "targetingType" : "Conversation topics"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "decentralization"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "crypto"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "#ethereum"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "decentralisation"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "ethereum"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "United States"
                }
              ],
              "impressionTime" : "2022-02-18 19:25:10"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "ProfileAccountsSidebar",
              "advertiserInfo" : {
                "advertiserName" : "1inch Network",
                "screenName" : "@1inch"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "#ethereum"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "decentralisation"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "crypto"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "ethereum"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "decentralization"
                },
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "Cryptocurrencies"
                },
                {
                  "targetingType" : "Conversation topics"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "United States"
                }
              ],
              "impressionTime" : "2022-02-18 19:25:12"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "ClusterFollow",
              "advertiserInfo" : {
                "advertiserName" : "1inch Network",
                "screenName" : "@1inch"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "Cryptocurrencies"
                },
                {
                  "targetingType" : "Conversation topics"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "decentralisation"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "#ethereum"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "crypto"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "decentralization"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "ethereum"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "United States"
                }
              ],
              "impressionTime" : "2022-02-18 19:25:18"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "ProfileAccountsSidebar",
              "advertiserInfo" : {
                "advertiserName" : "1inch Network",
                "screenName" : "@1inch"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "ethereum"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "decentralisation"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "#ethereum"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "crypto"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "decentralization"
                },
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "Cryptocurrencies"
                },
                {
                  "targetingType" : "Conversation topics"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "United States"
                }
              ],
              "impressionTime" : "2022-02-18 19:06:41"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "ProfileTweets",
              "promotedTweetInfo" : {
                "tweetId" : "1494691599514841097",
                "tweetText" : "#ActiveTrader: Find out if traders think these “commodity stocks” will get back in sync with their commodity’s rally.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "E*TRADE from Morgan Stanley",
                "screenName" : "@etrade"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "financial"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "$fb"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "cryptocurrency"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "finances"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "finance"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "bitcoin"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "United States"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "Desktop"
                }
              ],
              "impressionTime" : "2022-02-18 19:25:22"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "ProfileTweets",
              "promotedTweetInfo" : {
                "tweetId" : "1494691599514841097",
                "tweetText" : "#ActiveTrader: Find out if traders think these “commodity stocks” will get back in sync with their commodity’s rally.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "E*TRADE from Morgan Stanley",
                "screenName" : "@etrade"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "bitcoin"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "cryptocurrency"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "finances"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "finance"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "$fb"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "financial"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "Desktop"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "United States"
                }
              ],
              "impressionTime" : "2022-02-18 19:06:40"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "WtfSidebar",
              "advertiserInfo" : {
                "advertiserName" : "RollKall",
                "screenName" : "@RollKallOffDuty"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "police"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Los Angeles"
                },
                {
                  "targetingType" : "Languages",
                  "targetingValue" : "English"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "Desktop"
                }
              ],
              "impressionTime" : "2022-02-18 23:53:32"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1457088061003616256",
                "tweetText" : "NFTs are paving the way for mainstream blockchain adoption. Join the movement by signing up to https://t.co/GC9cXDxtMu – A curated platform for today’s most in-demand NFT projects",
                "urls" : [
                  "https://t.co/GC9cXDxtMu"
                ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Crypto.com",
                "screenName" : "@cryptocom"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "blockchain application"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "how to mint nft art"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "blockchain applications"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "nft blockchain"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "nft's"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "Desktop"
                },
                {
                  "targetingType" : "Languages",
                  "targetingValue" : "English"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "California"
                }
              ],
              "impressionTime" : "2022-02-18 23:53:32"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "WtfSidebar",
              "advertiserInfo" : {
                "advertiserName" : "Ferrovial",
                "screenName" : "@ferrovial"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "California"
                }
              ],
              "impressionTime" : "2022-02-18 23:53:30"
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adImpressions" : {
          "impressions" : [
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "WtfSidebar",
              "advertiserInfo" : {
                "advertiserName" : "Loft Labs",
                "screenName" : "@loft_sh"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@kubernetesio"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@awscloud"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "Desktop"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "California"
                },
                {
                  "targetingType" : "Languages",
                  "targetingValue" : "English"
                }
              ],
              "impressionTime" : "2022-02-20 22:08:53"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "WtfSidebar",
              "advertiserInfo" : {
                "advertiserName" : "Loft Labs",
                "screenName" : "@loft_sh"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@kubernetesio"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@awscloud"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "California"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "Desktop"
                },
                {
                  "targetingType" : "Languages",
                  "targetingValue" : "English"
                }
              ],
              "impressionTime" : "2022-02-20 22:08:52"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1495268214242115585",
                "tweetText" : "Here’s to the next generation of memories! #TeamToyota #DAYTONA500",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "promotedTrendInfo" : {
                "trendId" : "85975",
                "name" : "#ToyotaRacing20220220",
                "description" : ""
              },
              "advertiserInfo" : {
                "advertiserName" : "Toyota Racing",
                "screenName" : "@ToyotaRacing"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "United States"
                }
              ],
              "impressionTime" : "2022-02-20 22:09:25"
            }
          ]
        }
      }
    }
  }
]