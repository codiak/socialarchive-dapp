window.YTD.follower.part0 = [
  {
    "follower" : {
      "accountId" : "926859515986923520",
      "userLink" : "https://twitter.com/intent/user?user_id=926859515986923520"
    }
  }
]