window.YTD.like.part0 = [
  {
    "like" : {
      "tweetId" : "1493128741266022402",
      "fullText" : "My latest article on @hackernoon . A brief introduction of @ethswarm . https://t.co/NYKiJc3k49 #Ethereum #blockchain #IPFS #Decentralization",
      "expandedUrl" : "https://twitter.com/i/web/status/1493128741266022402"
    }
  },
  {
    "like" : {
      "tweetId" : "1492112462883262469",
      "fullText" : "@leonsp This is a very common response and it misses the point - the courts are defining legitimate purpose in ways no one on the Internet would recognise. For example, using Google fonts turns out to be an illegitimate use, because Google gets an IP address and we don't 'need' fonts",
      "expandedUrl" : "https://twitter.com/i/web/status/1492112462883262469"
    }
  },
  {
    "like" : {
      "tweetId" : "1453560083149987844",
      "fullText" : "Thanks to Clarissa Langowski for being connection number 10,000 on LinkedIn!",
      "expandedUrl" : "https://twitter.com/i/web/status/1453560083149987844"
    }
  },
  {
    "like" : {
      "tweetId" : "1493988845766905856",
      "fullText" : "Bonus points: point two of them at each other on Twitch :D",
      "expandedUrl" : "https://twitter.com/i/web/status/1493988845766905856"
    }
  },
  {
    "like" : {
      "tweetId" : "1492190628242931714",
      "fullText" : "@henriksen @leonsp The principle here is 'using assets from more than one server' not narrowly 'tracked by Google'. The same would apply if you uses a tiny font foundry.",
      "expandedUrl" : "https://twitter.com/i/web/status/1492190628242931714"
    }
  },
  {
    "like" : {
      "tweetId" : "1493633068669755392",
      "fullText" : "@DeepMind @FryRsquared @ShaneLegg Any sufficiently advanced form of humor is indistinguishable from magic. \n\nmAGIc https://t.co/SYcrw5GVc1",
      "expandedUrl" : "https://twitter.com/i/web/status/1493633068669755392"
    }
  }
]