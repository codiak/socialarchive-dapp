window.YTD.ad_engagements.part0 = [
  {
    "ad" : {
      "adsUserData" : {
        "adEngagements" : {
          "engagements" : [
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "86103",
                  "name" : "#GalaxyS22",
                  "description" : "Pre-order now"
                },
                "advertiserInfo" : {
                  "advertiserName" : "Samsung Mobile US",
                  "screenName" : "@SamsungMobileUS"
                },
                "impressionTime" : "2022-02-18 15:16:01"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-02-18 15:16:01",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1491446076834029568",
                  "tweetText" : "Not a rule breaker? Then maybe keep scrolling. For everyone else: Get ready for #GalaxyS22 Ultra. \n\nPre-order now to get up to $200 in Samsung Credit plus double the storage on us.",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "promotedTrendInfo" : {
                  "trendId" : "86103",
                  "name" : "#GalaxyS22",
                  "description" : "Pre-order now"
                },
                "advertiserInfo" : {
                  "advertiserName" : "Samsung Mobile US",
                  "screenName" : "@SamsungMobileUS"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "United States"
                  }
                ],
                "impressionTime" : "2022-02-18 15:16:00"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-02-18 15:16:08",
                  "engagementType" : "VideoSession"
                },
                {
                  "engagementTime" : "2022-02-18 15:16:06",
                  "engagementType" : "VideoContentPlayback75"
                },
                {
                  "engagementTime" : "2022-02-18 15:16:03",
                  "engagementType" : "VideoContentPlaybackStart"
                },
                {
                  "engagementTime" : "2022-02-18 15:16:03",
                  "engagementType" : "VideoContentPlayback25"
                },
                {
                  "engagementTime" : "2022-02-18 15:16:05",
                  "engagementType" : "VideoContentPlayback50"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "86103",
                  "name" : "#GalaxyS22",
                  "description" : "Pre-order now"
                },
                "advertiserInfo" : {
                  "advertiserName" : "Samsung Mobile US",
                  "screenName" : "@SamsungMobileUS"
                },
                "impressionTime" : "2022-02-18 19:05:30"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-02-18 19:05:30",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "86103",
                  "name" : "#GalaxyS22",
                  "description" : "Pre-order now"
                },
                "advertiserInfo" : {
                  "advertiserName" : "Samsung Mobile US",
                  "screenName" : "@SamsungMobileUS"
                },
                "impressionTime" : "2022-02-18 19:25:10"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-02-18 19:25:11",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "86103",
                  "name" : "#GalaxyS22",
                  "description" : "Pre-order now"
                },
                "advertiserInfo" : {
                  "advertiserName" : "Samsung Mobile US",
                  "screenName" : "@SamsungMobileUS"
                },
                "impressionTime" : "2022-02-18 23:53:30"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-02-18 23:53:31",
                  "engagementType" : "TrendView"
                }
              ]
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adEngagements" : {
          "engagements" : [
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1495268214242115585",
                  "tweetText" : "Here’s to the next generation of memories! #TeamToyota #DAYTONA500",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "promotedTrendInfo" : {
                  "trendId" : "85975",
                  "name" : "#ToyotaRacing20220220",
                  "description" : ""
                },
                "advertiserInfo" : {
                  "advertiserName" : "Toyota Racing",
                  "screenName" : "@ToyotaRacing"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "United States"
                  }
                ],
                "impressionTime" : "2022-02-20 22:08:52"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-02-20 22:09:27",
                  "engagementType" : "VideoContent1secView"
                },
                {
                  "engagementTime" : "2022-02-20 22:09:26",
                  "engagementType" : "VideoContentPlaybackStart"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "86136",
                  "name" : "#PS5TREATCODES",
                  "description" : "Spot Treat Codes to Enter"
                },
                "advertiserInfo" : {
                  "advertiserName" : "PlayStation",
                  "screenName" : "@PlayStation"
                },
                "impressionTime" : "2022-02-20 22:08:52"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-02-20 22:08:53",
                  "engagementType" : "TrendView"
                }
              ]
            }
          ]
        }
      }
    }
  }
]