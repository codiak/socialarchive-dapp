window.YTD.device_token.part0 = [
  {
    "deviceToken" : {
      "clientApplicationId" : "3033300",
      "token" : "GpUGlbrQAO8tPZUJHbqC6FFpouJUrM0sAqFLk47x",
      "createdAt" : "2022-02-10T01:19:21.629Z",
      "lastSeenAt" : "2022-02-10T01:19:21.630Z",
      "clientApplicationName" : "Twitter Web App (Twitter. Inc)"
    }
  },
  {
    "deviceToken" : {
      "clientApplicationId" : "3033300",
      "token" : "cLoUb532ge8TWE0Ol1DuPq4EF3OjVClzaDOJgu84",
      "createdAt" : "2021-10-14T23:33:50.154Z",
      "lastSeenAt" : "2022-02-10T01:22:32.674Z",
      "clientApplicationName" : "Twitter Web App (Twitter. Inc)"
    }
  },
  {
    "deviceToken" : {
      "clientApplicationId" : "49152",
      "token" : "ha1zndw51YK7J6DMuYeS9vkoWitynN7ToMXOJImk",
      "createdAt" : "2022-02-16T15:30:33.543Z",
      "lastSeenAt" : "2022-02-16T15:30:33.545Z",
      "clientApplicationName" : "Mobile Web (Twitter)"
    }
  }
]