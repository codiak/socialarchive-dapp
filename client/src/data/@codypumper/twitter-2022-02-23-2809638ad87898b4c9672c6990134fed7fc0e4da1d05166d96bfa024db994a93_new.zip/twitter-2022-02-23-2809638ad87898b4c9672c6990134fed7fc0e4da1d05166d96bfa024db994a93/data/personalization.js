window.YTD.personalization.part0 = [
  {
    "p13nData" : {
      "demographics" : {
        "languages" : [
          {
            "language" : "English",
            "isDisabled" : false
          }
        ],
        "genderInfo" : {
          "gender" : ""
        }
      },
      "interests" : {
        "interests" : [
          {
            "name" : "Artificial intelligence",
            "isDisabled" : false
          },
          {
            "name" : "Business & finance",
            "isDisabled" : false
          },
          {
            "name" : "Cryptocurrencies",
            "isDisabled" : false
          },
          {
            "name" : "Cyberpunk 2077",
            "isDisabled" : false
          },
          {
            "name" : "Digital asset industry",
            "isDisabled" : false
          },
          {
            "name" : "Entertainment",
            "isDisabled" : false
          },
          {
            "name" : "Ethereum cryptocurrency",
            "isDisabled" : false
          },
          {
            "name" : "Facebook",
            "isDisabled" : false
          },
          {
            "name" : "Gaming",
            "isDisabled" : false
          },
          {
            "name" : "Google",
            "isDisabled" : false
          },
          {
            "name" : "Google Innovation",
            "isDisabled" : false
          },
          {
            "name" : "Google brand conversation",
            "isDisabled" : false
          },
          {
            "name" : "Joe Rogan",
            "isDisabled" : false
          },
          {
            "name" : "Lex Fridman",
            "isDisabled" : false
          },
          {
            "name" : "Machine learning",
            "isDisabled" : false
          },
          {
            "name" : "Podcasts & radio",
            "isDisabled" : false
          },
          {
            "name" : "Social media",
            "isDisabled" : false
          },
          {
            "name" : "Tamagotchi",
            "isDisabled" : false
          },
          {
            "name" : "Tech personalities",
            "isDisabled" : false
          },
          {
            "name" : "The Joe Rogan Experience",
            "isDisabled" : false
          },
          {
            "name" : "Video games",
            "isDisabled" : false
          }
        ],
        "partnerInterests" : [ ],
        "audienceAndAdvertisers" : {
          "numAudiences" : "0",
          "advertisers" : [ ],
          "lookalikeAdvertisers" : [ ],
          "doNotReachAdvertisers" : [ ]
        },
        "shows" : [ ]
      },
      "locationHistory" : [
        "LOS ANGELES, USA",
        "Los Angeles, CA, USA"
      ],
      "inferredAgeInfo" : {
        "age" : [ ],
        "birthDate" : ""
      }
    }
  }
]