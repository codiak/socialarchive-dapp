window.YTD.account_timezone.part0 = [
  {
    "accountTimezone" : {
      "accountId" : "1491582370666844160"
    }
  }
]