window.YTD.account.part0 = [
  {
    "account" : {
      "email" : "codypumper+pro@gmail.com",
      "createdVia" : "oauth:3033300",
      "username" : "maryjane",
      "accountId" : "1491582370666844160",
      "createdAt" : "2022-02-10T01:19:21.471Z",
      "accountDisplayName" : "codypumper"
    }
  }
]