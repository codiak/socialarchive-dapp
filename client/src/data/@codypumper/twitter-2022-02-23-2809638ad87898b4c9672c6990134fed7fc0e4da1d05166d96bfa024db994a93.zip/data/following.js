window.YTD.following.part0 = [
  {
    "following" : {
      "accountId" : "3067132687",
      "userLink" : "https://twitter.com/intent/user?user_id=3067132687"
    }
  },
  {
    "following" : {
      "accountId" : "1076526138736951298",
      "userLink" : "https://twitter.com/intent/user?user_id=1076526138736951298"
    }
  },
  {
    "following" : {
      "accountId" : "2956121356",
      "userLink" : "https://twitter.com/intent/user?user_id=2956121356"
    }
  },
  {
    "following" : {
      "accountId" : "890454487",
      "userLink" : "https://twitter.com/intent/user?user_id=890454487"
    }
  },
  {
    "following" : {
      "accountId" : "33836629",
      "userLink" : "https://twitter.com/intent/user?user_id=33836629"
    }
  },
  {
    "following" : {
      "accountId" : "1088407134461665282",
      "userLink" : "https://twitter.com/intent/user?user_id=1088407134461665282"
    }
  },
  {
    "following" : {
      "accountId" : "3333052551",
      "userLink" : "https://twitter.com/intent/user?user_id=3333052551"
    }
  },
  {
    "following" : {
      "accountId" : "48008938",
      "userLink" : "https://twitter.com/intent/user?user_id=48008938"
    }
  },
  {
    "following" : {
      "accountId" : "427089628",
      "userLink" : "https://twitter.com/intent/user?user_id=427089628"
    }
  },
  {
    "following" : {
      "accountId" : "3442793834",
      "userLink" : "https://twitter.com/intent/user?user_id=3442793834"
    }
  },
  {
    "following" : {
      "accountId" : "788898706586275840",
      "userLink" : "https://twitter.com/intent/user?user_id=788898706586275840"
    }
  },
  {
    "following" : {
      "accountId" : "4783690002",
      "userLink" : "https://twitter.com/intent/user?user_id=4783690002"
    }
  },
  {
    "following" : {
      "accountId" : "216939636",
      "userLink" : "https://twitter.com/intent/user?user_id=216939636"
    }
  },
  {
    "following" : {
      "accountId" : "4398626122",
      "userLink" : "https://twitter.com/intent/user?user_id=4398626122"
    }
  },
  {
    "following" : {
      "accountId" : "145057047",
      "userLink" : "https://twitter.com/intent/user?user_id=145057047"
    }
  },
  {
    "following" : {
      "accountId" : "47126544",
      "userLink" : "https://twitter.com/intent/user?user_id=47126544"
    }
  },
  {
    "following" : {
      "accountId" : "771073707662073856",
      "userLink" : "https://twitter.com/intent/user?user_id=771073707662073856"
    }
  }
]