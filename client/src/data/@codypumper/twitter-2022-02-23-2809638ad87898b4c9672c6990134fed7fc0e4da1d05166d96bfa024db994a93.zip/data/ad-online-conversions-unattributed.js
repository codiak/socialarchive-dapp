window.YTD.ad_online_conversions_unattributed.part0 = [
  {
    "ad" : {
      "adsUserData" : {
        "unattributedOnlineConversions" : {
          "conversions" : [
            {
              "eventType" : "pageview",
              "conversionPlatform" : "Desktop",
              "conversionUrl" : "https://www.coursera.org/learn/probability-theory-foundation-for-data-science/lecture/ZaRNb/more-on-expectation-and-variance",
              "advertiserInfo" : {
                "advertiserName" : "Coursera",
                "screenName" : "@coursera"
              },
              "conversionValue" : "0",
              "conversionTime" : "2022-02-16 02:25:52",
              "additionalParameters" : { }
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "unattributedOnlineConversions" : {
          "conversions" : [
            {
              "eventType" : "pageview",
              "conversionPlatform" : "Desktop",
              "conversionUrl" : "https://www.coursera.org/programs/cu-on-coursera-sqyue?authProvider=uofc",
              "advertiserInfo" : {
                "advertiserName" : "Coursera",
                "screenName" : "@coursera"
              },
              "conversionValue" : "0",
              "conversionTime" : "2022-02-16 17:03:41",
              "additionalParameters" : { }
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "unattributedOnlineConversions" : {
          "conversions" : [
            {
              "eventType" : "pageview",
              "conversionPlatform" : "Desktop",
              "conversionUrl" : "https://www.coursera.org/lecture/probability-theory-foundation-for-data-science/more-on-expectation-and-variance-ZaRNb",
              "advertiserInfo" : {
                "advertiserName" : "Coursera",
                "screenName" : "@coursera"
              },
              "conversionValue" : "0",
              "conversionTime" : "2022-02-18 01:22:24",
              "additionalParameters" : { }
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "unattributedOnlineConversions" : {
          "conversions" : [
            {
              "eventType" : "pageview",
              "conversionPlatform" : "Desktop",
              "conversionUrl" : "https://www.coursera.org/lecture/probability-theory-foundation-for-data-science/more-on-expectation-and-variance-ZaRNb",
              "advertiserInfo" : {
                "advertiserName" : "Coursera",
                "screenName" : "@coursera"
              },
              "conversionValue" : "0",
              "conversionTime" : "2022-02-20 21:32:16",
              "additionalParameters" : { }
            }
          ]
        }
      }
    }
  }
]