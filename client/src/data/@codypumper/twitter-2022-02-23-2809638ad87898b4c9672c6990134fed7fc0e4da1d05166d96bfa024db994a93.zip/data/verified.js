window.YTD.verified.part0 = [
  {
    "verified" : {
      "accountId" : "1491582370666844160",
      "verified" : false
    }
  }
]