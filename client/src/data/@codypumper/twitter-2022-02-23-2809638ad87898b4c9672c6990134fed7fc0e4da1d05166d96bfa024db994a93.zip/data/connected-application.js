window.YTD.connected_application.part0 = [
  {
    "connectedApplication" : {
      "organization" : {
        "name" : "Upnext",
        "url" : "https://www.getupnext.com",
        "privacyPolicyUrl" : "https://www.getupnext.com/legal/privacy",
        "termsAndConditionsUrl" : "https://www.getupnext.com/legal/terms"
      },
      "name" : "Upnext - Save it for later!",
      "description" : "This enables Upnext users to save content directly from Twitter.",
      "permissions" : [
        "read"
      ],
      "approvedAt" : "2022-02-16T15:30:38.000Z",
      "id" : "22003398"
    }
  }
]