window.YTD.ad_impressions.part0 = [
  {
    "ad" : {
      "adsUserData" : {
        "adImpressions" : {
          "impressions" : [
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "WtfSidebar",
              "advertiserInfo" : {
                "advertiserName" : "XPENG",
                "screenName" : "@XPengMotors"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "United States"
                }
              ],
              "impressionTime" : "2021-10-24 03:29:22"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "WtfSidebar",
              "advertiserInfo" : {
                "advertiserName" : "XPENG",
                "screenName" : "@XPengMotors"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "United States"
                }
              ],
              "impressionTime" : "2021-10-24 03:29:23"
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adImpressions" : {
          "impressions" : [
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "WtfSidebar",
              "advertiserInfo" : {
                "advertiserName" : "Numbrs",
                "screenName" : "@Numbrs"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Technology"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "decentralized"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@saylor"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@Ledger"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@BinanceLabs"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@binance"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@DocumentingBTC"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@BTCTN"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@BinanceChain"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@decryptmedia"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@CoinDesk"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@TheBlock__"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@brian_armstrong"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@BitcoinMagazine"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@cryptocom"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@coinbase"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@MetaMask"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@coingecko"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@CoinbaseWallet"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@TrustWallet"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@Blockworks_"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "United States"
                }
              ],
              "impressionTime" : "2021-11-03 22:33:36"
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adImpressions" : {
          "impressions" : [
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "WtfSidebar",
              "advertiserInfo" : {
                "advertiserName" : "BlackBoxStocks",
                "screenName" : "@BlackBoxStocks"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@saylor"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@scottmelker"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@brian_armstrong"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@APompliano"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "United States"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "California"
                },
                {
                  "targetingType" : "Languages",
                  "targetingValue" : "English"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "21 and up"
                }
              ],
              "impressionTime" : "2021-11-04 00:05:43"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "WtfSidebar",
              "advertiserInfo" : {
                "advertiserName" : "BlackBoxStocks",
                "screenName" : "@BlackBoxStocks"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@saylor"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@scottmelker"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@brian_armstrong"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@APompliano"
                },
                {
                  "targetingType" : "Languages",
                  "targetingValue" : "English"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "21 and up"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "United States"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "California"
                }
              ],
              "impressionTime" : "2021-11-04 00:05:41"
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adImpressions" : {
          "impressions" : [
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "WtfSidebar",
              "advertiserInfo" : {
                "advertiserName" : "BYBIT 🦍",
                "screenName" : "@Bybit_Official"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@justinsuntron"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@wavesprotocol"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@Uniswap"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@compoundfinance"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@hitbtc"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@bscscan"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@MakerDAO"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@saylor"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@AaveAave"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@blockchain"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@Shibtoken"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@BithumbOfficial"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@Neo_Blockchain"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@FantomFDN"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@Bitstamp"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@CoinDeskMarkets"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@kucoincom"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@bsc_daily"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@crypto"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@BalancerLabs"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@Cryptopia_NZ"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@BinanceAcademy"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@CoinbaseExch"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@BinanceLabs"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@Polkadot"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@binance"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@dydxprotocol"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@Ripple"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@BTCTN"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@bitfinex"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@BinanceResearch"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@BinanceChain"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@AxieInfinity"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@BitMEX"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@CoinMarketCap"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@Poloniex"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@CoinbaseSupport"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@CoinDesk"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@CoinDeskData"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@tyler"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@trondao"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@PancakeBunnyFin"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@litecoin"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@BitcoinMagazine"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@0xPolygon"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@PancakeSwap"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@cz_binance"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@APompliano"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@InjectiveLabs"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@OKEx"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@Bancor"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@cameron"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@hedera"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@cosmos"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@coinbase"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@Okcoin"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@ForbesCrypto"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@Bitcoin"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@BinanceUS"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@krakenfx"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@BittrexExchange"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@BlockFi"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@TrustWallet"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@HuobiGlobal"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@Gemini"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@TheCryptoLark"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@ProjectSerum"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                }
              ],
              "impressionTime" : "2021-11-04 14:20:38"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "WtfSidebar",
              "advertiserInfo" : {
                "advertiserName" : "BYBIT 🦍",
                "screenName" : "@Bybit_Official"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@justinsuntron"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@wavesprotocol"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@Uniswap"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@compoundfinance"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@hitbtc"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@bscscan"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@MakerDAO"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@saylor"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@AaveAave"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@blockchain"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@Shibtoken"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@BithumbOfficial"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@Neo_Blockchain"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@FantomFDN"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@Bitstamp"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@CoinDeskMarkets"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@kucoincom"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@bsc_daily"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@crypto"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@BalancerLabs"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@Cryptopia_NZ"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@BinanceAcademy"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@CoinbaseExch"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@BinanceLabs"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@Polkadot"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@binance"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@dydxprotocol"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@Ripple"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@BTCTN"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@bitfinex"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@BinanceResearch"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@BinanceChain"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@AxieInfinity"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@BitMEX"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@CoinMarketCap"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@Poloniex"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@CoinbaseSupport"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@CoinDesk"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@CoinDeskData"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@tyler"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@trondao"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@PancakeBunnyFin"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@litecoin"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@BitcoinMagazine"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@0xPolygon"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@PancakeSwap"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@cz_binance"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@APompliano"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@InjectiveLabs"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@OKEx"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@Bancor"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@cameron"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@hedera"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@cosmos"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@coinbase"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@Okcoin"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@ForbesCrypto"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@Bitcoin"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@BinanceUS"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@krakenfx"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@BittrexExchange"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@BlockFi"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@TrustWallet"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@HuobiGlobal"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@Gemini"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@TheCryptoLark"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@ProjectSerum"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                }
              ],
              "impressionTime" : "2021-11-04 14:20:36"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "WtfSidebar",
              "advertiserInfo" : {
                "advertiserName" : "ADM Investor Services",
                "screenName" : "@TradeADMIS"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@Investingcom"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@ICE_Markets"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "United States"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "21 and up"
                }
              ],
              "impressionTime" : "2021-11-04 23:11:51"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "WtfSidebar",
              "advertiserInfo" : {
                "advertiserName" : "Saidler & Co.",
                "screenName" : "@Saidler"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@saylor"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@ftx_app"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@CoinbaseExch"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@binance"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@DocumentingBTC"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@decryptmedia"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@CoinDesk"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@100trillionUSD"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@BarrySilbert"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@woonomic"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@coinbase"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@MetaMask"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "United States"
                }
              ],
              "impressionTime" : "2021-11-04 23:15:17"
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adImpressions" : {
          "impressions" : [
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "WtfSidebar",
              "advertiserInfo" : {
                "advertiserName" : "Bank of America",
                "screenName" : "@BankofAmerica"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Science news"
                },
                {
                  "targetingType" : "List",
                  "targetingValue" : "EHL_20211213"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Minnesota"
                }
              ],
              "impressionTime" : "2021-12-21 20:06:06"
            }
          ]
        }
      }
    }
  }
]