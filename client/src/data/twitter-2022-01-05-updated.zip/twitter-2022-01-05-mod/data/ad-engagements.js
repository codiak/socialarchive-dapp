window.YTD.ad_engagements.part0 = [
  {
    "ad" : {
      "adsUserData" : {
        "adEngagements" : {
          "engagements" : [
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "83095",
                  "name" : "#WorkplacefromFB",
                  "description" : "Bring more of what makes you to work"
                },
                "advertiserInfo" : {
                  "advertiserName" : "Workplace from Meta",
                  "screenName" : "@WorkplaceMeta"
                },
                "impressionTime" : "2021-10-24 03:29:21"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2021-10-24 03:29:22",
                  "engagementType" : "TrendView"
                }
              ]
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adEngagements" : {
          "engagements" : [
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "83620",
                  "name" : "#Eternals",
                  "description" : "Now Playing Only In Theaters"
                },
                "advertiserInfo" : {
                  "advertiserName" : "Marvel Studios",
                  "screenName" : "@MarvelStudios"
                },
                "impressionTime" : "2021-11-04 14:20:36"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2021-11-04 14:20:36",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "83620",
                  "name" : "#Eternals",
                  "description" : "Now Playing Only In Theaters"
                },
                "advertiserInfo" : {
                  "advertiserName" : "Marvel Studios",
                  "screenName" : "@MarvelStudios"
                },
                "impressionTime" : "2021-11-04 23:15:16"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2021-11-04 23:15:17",
                  "engagementType" : "TrendView"
                }
              ]
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adEngagements" : {
          "engagements" : [
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "84769",
                  "name" : "#AmericanUnderdog",
                  "description" : "The incredible true story of Kurt Warner. In theaters Christmas Day."
                },
                "advertiserInfo" : {
                  "advertiserName" : "American Underdog",
                  "screenName" : "@AmericanUnderdg"
                },
                "impressionTime" : "2021-12-21 20:06:05"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2021-12-21 20:06:06",
                  "engagementType" : "TrendView"
                }
              ]
            }
          ]
        }
      }
    }
  }
]