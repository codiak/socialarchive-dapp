window.YTD.verified.part0 = [
  {
    "verified" : {
      "accountId" : "1448793710905290770",
      "verified" : false
    }
  }
]