window.YTD.screen_name_change.part0 = [
  {
    "screenNameChange" : {
      "accountId" : "1448793710905290770",
      "screenNameChange" : {
        "changedAt" : "2021-10-14T23:39:35.000Z",
        "changedFrom" : "SocialArchive2",
        "changedTo" : "SocialArchiveCo"
      }
    }
  }
]