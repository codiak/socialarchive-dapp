window.YTD.account_timezone.part0 = [
  {
    "accountTimezone" : {
      "accountId" : "1448793710905290770"
    }
  }
]