window.YTD.like.part0 = [
  {
    "like" : {
      "tweetId" : "1474183295852187651",
      "fullText" : "⟠ Latest Week in Ethereum News!\n\n⭐ @icebearhww PoW switch off consensus upgrade named Bellatrix\n💼 @SAP joins @EntEthAlliance / @baselineproto\n🎉 @Ethereum teams Q4 achievements\n\nhttps://t.co/zMF41qIpnD\n\nThanks to @kwenta_io &amp; @synthetix_io for making this issue possible 🙏",
      "expandedUrl" : "https://twitter.com/i/web/status/1474183295852187651"
    }
  },
  {
    "like" : {
      "tweetId" : "1451676767391989765",
      "fullText" : "@SocialArchiveCo https://t.co/8o8L9ARpe2",
      "expandedUrl" : "https://twitter.com/i/web/status/1451676767391989765"
    }
  },
  {
    "like" : {
      "tweetId" : "1474372496631676949",
      "fullText" : "Here's some good holiday news 🎉\n\nThe #ethswarm have reached their first milestone \n\nYou can now host unstoppable content on Swarm 🐝\n\nThis is the beginning of true unstoppable content on Swarm \n\nHappy unstoppable holidays 🎄",
      "expandedUrl" : "https://twitter.com/i/web/status/1474372496631676949"
    }
  },
  {
    "like" : {
      "tweetId" : "1474322188710916100",
      "fullText" : "The Swarm network is starting to fill up, and the price of storage is thus increasing.\nTop up your postage stamps to ensure your content is retained by Swarm! \nFind out how in the Bee Docs: https://t.co/Pf0tICDBbI",
      "expandedUrl" : "https://twitter.com/i/web/status/1474322188710916100"
    }
  },
  {
    "like" : {
      "tweetId" : "1474372498343010315",
      "fullText" : "To host your unstoppable content, you can use https://t.co/lt99pUy6xY for uploads up to 10MB. And if you want unlimited uploads/downloads, you can install your own Bee node.",
      "expandedUrl" : "https://twitter.com/i/web/status/1474372498343010315"
    }
  }
]